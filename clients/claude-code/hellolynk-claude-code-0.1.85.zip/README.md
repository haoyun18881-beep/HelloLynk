# HelloLynk for Claude · Windows

## 前提

Windows 10/11、Node.js 22.16 或更高版本、PowerShell 7，以及打开过一次的 Claude Desktop。

## 安装

1. 完整解压 ZIP。完全退出 Claude，包括托盘中的 Claude 和正在运行的 Claude CLI。
2. 在解压目录打开终端，运行 `node install.mjs`。
3. 重新打开 Claude。

有多个 Claude 实例时，用 Claude 实际使用的配置文件路径运行，例如：

```powershell
node install.mjs --desktop-config "$env:LOCALAPPDATA\Claude-3p\claude_desktop_config.json"
```

普通安装的配置文件在 `$env:APPDATA\Claude\claude_desktop_config.json`；Windows Store 版在 `$env:LOCALAPPDATA\Packages\Claude_<包标识>\LocalCache\Roaming\Claude\` 或 `$env:LOCALAPPDATA\Claude-Data\claude_<包标识>\`。这些位置安装器会自己找到，其他位置用 `--desktop-config` 指定。

只检查安装包是否完整：`node install.mjs --check`。查看全部参数：`node install.mjs --help`。

## 首次连接

1. 在新的 Code 对话中说“打开 HelloLynk”。
2. 在卡片里粘贴从 hellolynk: 开始的完整灵信号，按提示到官网确认这台电脑，再回到卡片继续。
3. 搜索并添加联系人，对方同意后就可以开始会话。

## 后台收信

默认不在后台收信。要启用，先确认独立的 Claude CLI 能运行并已登录，然后在 Claude 关闭时运行：

```powershell
node install.mjs receiver --cli-path "C:\实际目录\claude.exe" --working-directory "C:\已有工作目录"
```

多实例时加上同一个 `--desktop-config`。加 `--start-at-logon` 可随 Windows 登录启动。后台收信的进度和回复显示在 HelloLynk 卡片里。

## 更新

插件会自动更新，下次打开 Claude 时用上新版本，后台收信保持原来的开关。从更早的版本升级，或用 `--desktop-config` 装在其他位置时，退出 Claude 后用同样的参数再次运行 `node install.mjs`。

## 卸载

完全退出 Claude 后运行 `node install.mjs uninstall`，多实例时加上同一个 `--desktop-config`。账号、联系人和聊天记录留在这台电脑上，重新安装后不用重新连接。

## 未能安装时

- `claude_code_install_close_claude_required`：Claude 还在运行。完全退出后重试。
- `claude_code_install_desktop_ambiguous` / `claude_code_install_desktop_not_found`：找到多个 Claude 实例，或一个也没找到。先打开一次要接入的 Claude 再退出；多实例用 `--desktop-config` 指定。
- `claude_code_install_desktop_first`：还没有安装。先运行 `node install.mjs`，再启用后台收信。
- `claude_code_install_mcp_conflict` / `claude_code_install_skill_conflict` / `claude_code_install_mod_conflict`：已有同名的 MCP、技能或 mod，不是本安装器装的，没有覆盖。确认它的来源并处理后重试。
- `claude_code_install_config_changed` / `claude_code_install_binding_changed`：安装过程中配置被别的程序改动了。关闭那个程序后重试。
- `claude_code_install_rollback_incomplete`：安装失败，恢复也没有完成。完全退出相关程序，检查 Claude 的 MCP 和技能后重试。
- `claude_code_install_busy`：另一个安装器正在运行。等它结束；确认没有安装进程后仍然出现，删除配置文件旁的 `.hellolynk-install.lock` 再重试。
- `claude_code_distribution_integrity_invalid`：安装包不完整或被改动过。重新下载。
- `hellolynk_node_22_16_required`：Node.js 版本太低。安装 22.16 或更高版本后重试。

其他错误码，发邮件到 [haoyun18881@gmail.com](mailto:haoyun18881@gmail.com)。

许可：本安装包适用随附 [LICENSE](LICENSE) 中的 PolyForm Shield 1.0.0。
