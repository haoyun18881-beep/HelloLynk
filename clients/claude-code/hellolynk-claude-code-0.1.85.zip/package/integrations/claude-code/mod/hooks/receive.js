// Claude Code mods API. No shell, transcript scraping or model polling.
const ID = /^[A-Za-z0-9][A-Za-z0-9_.:-]{2,240}$/;
const SCOPE_HASH = /^[a-f0-9]{64}$/;
const SEND = 'mcp__hellolynk__hellolynk_send_authorized_message';
const REPLY = 'mcp__hellolynk__hellolynk_reply_authorized_message';

  let active = false, busy = false, generation = 0, timer, flight, config, prepared;
  let deliveringContext = false;
  let failureDelay = 0, nextPollAt = 0;
  let currentSessionId, sessionTitle = '', sessionCwd = '', hostSessionId;
  const reservations = new Map();
  // Batches this process already handed to Claude. A failed confirm is retried
  // here, and such a batch is never submitted again by this process.
  const handed = new Map();
  async function receiver($) {
    return config ||= JSON.parse(await $.fs.read(`${$.plugin.root}/receiver.json`));
  }
  async function helper($, request, timeoutMs = 55000) {
    await receiver($);
    const r = await $.process.run([config.command, ...config.args], {
      stdin: JSON.stringify(request), timeoutMs,
    });
    if (r.exitCode !== 0) throw new Error('hellolynk_original_receiver_unavailable');
    return JSON.parse(r.stdout);
  }
  function failed(epoch) {
    if (active && epoch === generation) {
      failureDelay = Math.min(failureDelay ? failureDelay * 2 : 5000, 60000);
      nextPollAt = Date.now() + failureDelay;
    }
  }
  async function confirm($, receipt) {
    const { batchId, scopeHash } = receipt;
    handed.set(batchId, { batchId, scopeHash });
    if (typeof scopeHash !== 'string' || !SCOPE_HASH.test(scopeHash)) throw new Error('hellolynk_original_receipt_invalid');
    const result = await helper($, { action: 'confirm', batchId, scopeHash });
    // Keep old-account acceptance evidence for when that account returns,
    // without making its confirmation block the current account's inbox.
    if (result.status === 'account_changed') return;
    if (result.status !== 'delivered') throw new Error('hellolynk_original_confirmation_unknown');
    handed.delete(batchId);
  }
  async function release($, item) {
    try { await helper($, { action: 'cancel', batchId: item.r.batchId }); }
    catch { /* The Host keeps the batch reserved for its one retry. */ }
  }
  function clearPrepared($) {
    const item = prepared; prepared = undefined;
    if (item) void release($, item);
  }
  async function tick($) {
    const now = Date.now();
    // A backward system-clock correction cannot turn a bounded pause into hours.
    if (nextPollAt - now > 60000) nextPollAt = 0;
    if (!active || flight || deliveringContext || (prepared && busy) || now < nextPollAt) return;
    const epoch = generation;
    flight = (async () => {
      const sessionId = await $.session.id();
      if (!ID.test(sessionId)) return;
      for (const receipt of handed.values()) await confirm($, receipt);
      const item = prepared; prepared = undefined;
      const r = item ? item.r : await helper($, { action: 'prepare', sessionId,
        ...(hostSessionId ? { hostSessionId } : {}), title: sessionTitle, cwd: sessionCwd });
      if (epoch === generation) { failureDelay = 0; nextPollAt = 0; }
      if (r.status !== 'reserved' || handed.has(r.batchId)) return;
      // The hook and helper ship together; never infer an old receipt's account.
      if (typeof r.scopeHash !== 'string' || !SCOPE_HASH.test(r.scopeHash)) throw new Error('hellolynk_original_receipt_invalid');
      if (!active || epoch !== generation || (item && item.epoch !== epoch)
        || r.sessionId !== sessionId || sessionId !== await $.session.id()) {
        await release($, { r }); return;
      }
      // The existing background wait also runs during a turn. Stop polling as
      // soon as one bounded batch is ready; ordinary tool calls do no I/O.
      if (busy) { prepared = { r, epoch }; return; }
      const text = r.text;
      reservations.set(text, { r, epoch });
      // An unknown outcome keeps the batch reserved: the Host allows one more
      // native try later. Never send it to a different window.
      try {
        const result = await $.prompt.submit({ text });
        if (result && !result.drop && result.origin?.kind === 'plugin'
          && result.origin.name === $.plugin.name) await confirm($, r);
        // An explicit drop proves no prompt was queued. Only this known
        // rejection may release the batch; an exception never does.
        else if (result?.drop) await helper($, { action: 'cancel', batchId: r.batchId });
      } finally { reservations.delete(text); }
    })().catch(() => {
      // Delivery stays pending; the plugin never interrupts the human's UI.
      failed(epoch);
    }).finally(() => { flight = null; });
    await flight;
  }
  async function start($, e = {}) {
    if (typeof e.session_title === 'string') sessionTitle = e.session_title;
    if (typeof e.cwd === 'string') sessionCwd = e.cwd;
    const nextSessionId = await $.session.id();
    if (active && currentSessionId === nextSessionId) return;
    generation++; timer?.cancel(); active = false; busy = false;
    clearPrepared($);
    failureDelay = 0; nextPollAt = 0;
    if (await $.env.get('HELLOLYNK_NATIVE_BACKGROUND') === '1') return;
    currentSessionId = nextSessionId;
    // The helper verifies this alias against Desktop's current cliSessionId;
    // an inherited fork environment alone can never redirect a message.
    hostSessionId = await $.env.get('CLAUDE_CODE_HOST_SESSION_ID').catch(() => undefined);
    if (!/^local_[a-f0-9-]{36}$/i.test(hostSessionId || '')) hostSessionId = undefined;
    sessionCwd = sessionCwd || await $.session.cwd().catch(() => '') || '';
    active = true;
    timer = $.clock.every(5000, () => { void tick($); });
    void tick($);
  }
export function register(on) {
  on('session.start', async ($, e, next) => { await start($, e); return next(e); });
  on('classic.SessionStart', async ($, e, next) => {
    // Compaction belongs to the running turn; it does not make the session idle.
    if (e.source !== 'compact') await start($, e);
    return next(e);
  });
  on('turn.start', ($, e, next) => { if (!e.agentId) busy = true; return next(e); });
  on('turn.complete', async ($, e, next) => {
    const result = await next(e);
    if (!e.agentId) { busy = false; void tick($); }
    return result;
  });
  on('session.end', ($, e, next) => {
    const wasActive = active, endedId = currentSessionId;
    active = false; generation++; timer?.cancel(); timer = undefined;
    clearPrepared($);
    if (wasActive && endedId) void helper($, { action: 'closed', sessionId: endedId }, 1200).catch(() => {});
    return next(e);
  });
  on('classic.UserPromptSubmit', ($, e, next) => {
    if (active && e.session_id === currentSessionId && typeof e.session_title === 'string') sessionTitle = e.session_title;
    return next(e);
  });
  on('classic.PostToolUse', async ($, e, next) => {
    const result = await next(e);
    if (!result || result.block || result.preventContinuation || e.agent_id
      || !active || !busy || flight || deliveringContext || !prepared
      || e.session_id !== prepared.r.sessionId) return result;
    const item = prepared; prepared = undefined; deliveringContext = true;
    try {
      if (item.epoch !== generation || !active || await $.session.id() !== item.r.sessionId) {
        void release($, item); return result;
      }
      // Classic hook output is model context, not prompt input or a UI notice.
      // Returning it is the host's acceptance: record delivery without waiting.
      const delivered = { ...result, additionalContext: [...(result.additionalContext || []), item.r.text] };
      void confirm($, item.r).catch(() => {});
      return delivered;
    } catch {
      failed(item.epoch);
      void release($, item);
      return result;
    } finally { deliveringContext = false; }
  });
  on('tool.call', async ($, e, next) => {
    if (!active || e.agentId || (e.tool !== SEND && e.tool !== REPLY)) return next(e);
    // Capture this exact origin before sending, then let the local registration
    // and the normal tool call proceed independently. Missing routes leave
    // replies in the inbox; neither path may retry the other on failure.
    let sessionId;
    try { sessionId = await $.session.id(); }
    catch { return next(e); }
    failureDelay = 0; nextPollAt = 0;
    const input = { action: 'remember', sessionId, clientMessageId: e.clientMessageId,
      ...(e.tool === REPLY ? { conversationKey: e.conversationKey }
        : Object.hasOwn(e, 'contact') ? { contact: e.contact } : { peerDelegateId: e.recipientDelegateId }) };
    void helper($, input).then(result => {
      if (result?.ok !== true) throw new Error('hellolynk_original_registration_failed');
    }).catch(() => { /* Missing routes leave replies in the inbox. */ });
    return next(e);
  });
  on('prompt.submit', async ($, e, next) => {
    const item = reservations.get(e.text);
    if (!item || e.origin?.kind !== 'plugin' || e.origin.name !== $.plugin.name) return next(e);
    if (!active || generation !== item.epoch || await $.session.id() !== item.r.sessionId)
      return { drop: 'HelloLynk 原对话已切换，来信保留待处理。' };
    return next(e);
  });
}
