#!/usr/bin/env node
import path from "node:path";
import { fileURLToPath } from "node:url";
import { readFile } from "node:fs/promises";
import { verifyPinnedBootstrap } from "./host-lifecycle.mjs";

export async function runClaudeCodePackage(argv = process.argv.slice(2), options = {}) {
  if (argv.length !== 5 || !["run", "run-agent", "receive", "original-session"].includes(argv[0]) || argv[1] !== "--root" || !path.isAbsolute(argv[2]) || argv[3] !== "--expected-manifest-sha256" || !/^[a-f0-9]{64}$/.test(argv[4])) throw new Error("claude_code_package_arguments_invalid");
  const root = path.resolve(argv[2]);
  const releaseRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "../../..");
  const pin = JSON.parse(await readFile(path.join(releaseRoot, "runtime/neutral-host-release-pin.json"), "utf8"));
  if (pin.manifestSha256 !== argv[4]) throw new Error("neutral_host_runner_integrity_invalid");
  await verifyPinnedBootstrap({
    adapterId: "claude-code", region: "prebind", principalId: "prebind-principal", delegateId: "prebind-delegate", hostInstallationId: "prebind-installation", profileId: "prebind-claude-code", version: 2, scopes: [],
    releaseRoot, releaseManifestSha256: argv[4], runtimeRoot: path.join(root, "runtime"), profileManifestPath: path.join(root, "profile-manifest-v1.json"), runnerRelativePath: "runtime/neutral-host-bootstrap.mjs",
  }, { storeRoot: root });
  // Claude starts this process with each session; the next start runs whatever release an update installs.
  if (argv[0] === "run" && !options.adapter) void import("../../../runtime/core/hellolynk-client-update-entry.mjs")
    .then(({ startInstalledClientUpdate }) => startInstalledClientUpdate({ client: "claude-code", packageRoot: releaseRoot, storeRoot: root })).catch(() => {});
  if (argv[0] === 'original-session') {
    const { createClaudeCodeProxyAdapter } = await import('./mcp-proxy.mjs');
    const { runClaudeOriginalSessionHelper } = await import('./original-session-bridge.mjs');
    const adapter = options.adapter || createClaudeCodeProxyAdapter({ storeRoot: root });
    try { return await runClaudeOriginalSessionHelper({ ...options, adapter }); }
    finally { await adapter.close(); }
  }
  if (argv[0] === "receive") {
    const { runClaudeNativeTaskReceiver } = await import("./native-task-service.mjs");
    const controller = new AbortController(), stop = () => controller.abort();
    process.once("SIGTERM", stop); process.once("SIGINT", stop);
    try { return await runClaudeNativeTaskReceiver({ ...options, root: releaseRoot, expectedManifestSha256: argv[4], storeRoot: root, signal: options.signal || controller.signal }); }
    finally { process.removeListener("SIGTERM", stop); process.removeListener("SIGINT", stop); }
  }
  const { runClaudeCodeMcpProxy } = await import("./mcp-proxy.mjs");
  // Model workers may use authorized messaging, but must not recursively
  // start another receiver (nor gain the human MCP App surface).
  return runClaudeCodeMcpProxy({ ...options, storeRoot: root,
    ...(argv[0] === 'run-agent' ? { nativeTasks: false, workbenchApp: false, prewarmAdapter: true } : {}) });
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) runClaudeCodePackage().catch(() => { process.stderr.write('claude_code_package_start_failed\n'); process.exitCode = 1; });
