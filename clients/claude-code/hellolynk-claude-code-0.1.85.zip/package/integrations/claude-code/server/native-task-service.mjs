import fs from "node:fs/promises";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import runtimeSafety from "../../../runtime/core/hellolynk-runtime-safety.cjs";
import { withHelloLynkLocalMutationLock } from "../../../runtime/core/hellolynk-local-messaging.mjs";
import { withLocalProcessLock } from "../../../runtime/core/hellolynk-local-process-lock.mjs";
import { clientAccountBaseRoot } from "../../../runtime/core/hellolynk-client-account.mjs";
import { verifyClaudeCodePreviousRelease } from "../install/candidate-install.mjs";
import { verifyPinnedBootstrap } from "./host-lifecycle.mjs";
import { configureClaudeNativeTaskWorker, readClaudeNativeTaskWorkerConfig, startClaudeNativeTaskWorker, writeClaudeNativeJson } from "./native-task-worker.mjs";

const execute = promisify(execFile);
const failure = code => Object.assign(new Error(code), { code });
const sameRelease = (a, b) => a.root.toLowerCase() === path.resolve(b.root).toLowerCase() && a.expectedManifestSha256 === b.expectedManifestSha256;
function validate(record) {
  if (record?.version !== 1 || !path.isAbsolute(record.root || "") || path.resolve(record.root) !== record.root || !/^[a-f0-9]{64}$/.test(record.expectedManifestSha256 || "") || !path.isAbsolute(record.nodePath || "") || !/^node(?:\.exe)?$/i.test(path.basename(record.nodePath)) || !/^HelloLynk Claude Native - [A-F0-9]{20} - [A-F0-9]{16}$/.test(record.taskName || "") || typeof record.enabled !== "boolean" || typeof record.startAtLogon !== "boolean") throw failure("claude_native_service_record_invalid");
}
async function safeParents(target) {
  let current = path.parse(target).root;
  for (const part of path.relative(current, target).split(path.sep).filter(Boolean)) {
    current = path.join(current, part);
    const stat = await fs.lstat(current);
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw failure("claude_native_service_record_invalid");
  }
}
function serviceRecordPath(storeRoot) {
  const base = clientAccountBaseRoot(storeRoot);
  if (!path.isAbsolute(storeRoot || "") || path.basename(base).toLowerCase() !== "host") throw failure("claude_native_service_store_invalid");
  return path.join(path.resolve(storeRoot), "claude-native-service.json");
}
async function readServiceRecord(filename) {
  try {
    await safeParents(path.dirname(filename));
    const stat = await fs.lstat(filename);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 || stat.size > 8192) throw failure("claude_native_service_record_invalid");
    const record = JSON.parse(await fs.readFile(filename, "utf8")); validate(record); return record;
  } catch (error) { if (error.code === "ENOENT") return null; throw error; }
}
export async function withClaudeNativeServiceRecord(storeRoot, operation) {
  const filename = serviceRecordPath(storeRoot), directory = path.dirname(filename);
  try { await safeParents(directory); } catch (error) { if (error.code === "ENOENT") return operation(null); throw error; }
  // Scheduler Verify/Start can exceed the short file transaction's wait.
  // Serialize task control and mutations outside that transaction. Read-only
  // enablement polling below observes the atomically published record instead.
  return withLocalProcessLock(filename, () => withHelloLynkLocalMutationLock(filename, async () => operation({
    read: () => readServiceRecord(filename),
    async save(record) {
      validate(record);
      await writeClaudeNativeJson(filename, record);
    },
    async remove() { await fs.rm(filename, { force: true }); },
  })), { timeoutMs: 90_000 });
}
async function verifyRelease(options, previous = false) {
  await safeParents(options.root);
  const node = await fs.lstat(options.nodePath || process.execPath);
  if (!node.isFile() || node.isSymbolicLink()) throw failure("claude_native_service_node_invalid");
  const binding = { adapterId: "claude-code", region: "prebind", principalId: "prebind-principal", delegateId: "prebind-delegate", hostInstallationId: "prebind-installation", profileId: "prebind-claude-code", version: 2, scopes: [], releaseRoot: options.root, releaseManifestSha256: options.expectedManifestSha256, runtimeRoot: path.join(options.storeRoot, "runtime"), profileManifestPath: path.join(options.storeRoot, "profile-manifest-v1.json"), runnerRelativePath: "runtime/neutral-host-bootstrap.mjs" };
  if (previous) await verifyClaudeCodePreviousRelease(binding);
  else await verifyPinnedBootstrap(binding, { storeRoot: options.storeRoot });
}
// driverRoot: a newer verified release's script may Stop/Uninstall an older
// release's task. Older scripts never receive this argument.
async function scheduledTask(options, command) {
  const { stdout } = await execute("powershell.exe", ["-NoLogo", "-NoProfile", "-NonInteractive", "-ExecutionPolicy", "Bypass", "-File", path.join(options.driverRoot || options.root, "integrations/claude-code/server/native-task-service.ps1"), "-Command", command, "-Root", options.root, "-Manifest", options.expectedManifestSha256, "-NodePath", options.nodePath || process.execPath, "-StoreRoot", options.storeRoot, "-StartAtLogon", options.startAtLogon ? "yes" : "no", ...(options.driverRoot ? ["-DriverRoot", options.driverRoot] : [])], { windowsHide: true, timeout: 30000, maxBuffer: 128 * 1024 });
  const result = JSON.parse(stdout.trim());
  if (result?.ok !== true) throw failure("claude_native_service_task_failed");
  return result;
}
// The record lock covers Verify/Start and disable/Stop together. Only explicit
// installation or Start can enable a stopped receiver; MCP never registers it.
export async function configureClaudeNativeTaskService(options, command = "Verify") {
  runtimeSafety.assertHelloLynkClientNodeVersion();
  if (!["Install", "Verify", "Start", "Stop", "Uninstall"].includes(command)) throw failure("claude_native_service_command_invalid");
  if (command === "Install") {
    const { stdout } = await execute(options.nodePath || process.execPath, ["--version"], { windowsHide: true, timeout: 10_000, maxBuffer: 256 });
    runtimeSafety.assertHelloLynkClientNodeVersion(stdout.trim().replace(/^v/, ""));
  }
  const verify = options.verifyRelease || verifyRelease, task = options.scheduledTask || scheduledTask;
  return withClaudeNativeServiceRecord(options.storeRoot, async registry => {
    if (!registry) throw failure("claude_native_service_store_missing");
    let record = await registry.read();
    if (command === "Install") {
      if (options.enabled !== true || !(await readClaudeNativeTaskWorkerConfig(options.storeRoot))) throw failure("claude_native_service_enable_required");
      const next = { version: 1, root: path.resolve(options.root), expectedManifestSha256: options.expectedManifestSha256, nodePath: options.nodePath || process.execPath, enabled: true, startAtLogon: options.startAtLogon === true };
      await verify({ ...next, storeRoot: options.storeRoot });
      if (record && (!sameRelease(record, next) || record.startAtLogon !== next.startAtLogon || record.nodePath !== next.nodePath)) {
        await registry.save({ ...record, enabled: false });
        await verify({ ...record, storeRoot: options.storeRoot }, true);
        await task({ ...record, storeRoot: options.storeRoot }, "Uninstall");
      }
      const result = await task({ ...next, storeRoot: options.storeRoot }, "Install");
      record = { ...next, taskName: result.taskName }; validate(record); await registry.save(record);
      return result;
    }
    if (!record || !sameRelease(record, options)) throw failure("claude_native_service_not_installed");
    if (command === "Stop" || command === "Uninstall") {
      // Withdraw before stopping even when verification later fails. A damaged
      // old package cannot be resurrected automatically by MCP or logon.
      await registry.save({ ...record, enabled: false });
      if (command === "Uninstall") await configureClaudeNativeTaskWorker({ storeRoot: options.storeRoot, enabled: false });
    }
    await verify({ ...record, storeRoot: options.storeRoot });
    if (command === "Start") {
      const { stdout } = await execute(record.nodePath, ["--version"], { windowsHide: true, timeout: 10_000, maxBuffer: 256 });
      runtimeSafety.assertHelloLynkClientNodeVersion(stdout.trim().replace(/^v/, ""));
      if (options.enabled !== true || !(await readClaudeNativeTaskWorkerConfig(options.storeRoot))) throw failure("claude_native_service_enable_required");
      await task({ ...record, storeRoot: options.storeRoot }, "Verify");
      await registry.save({ ...record, enabled: true });
    }
    const result = await task({ ...record, storeRoot: options.storeRoot }, command);
    if (result.taskName !== record.taskName) throw failure("claude_native_service_record_mismatch");
    if (command === "Uninstall") await registry.remove();
    return result;
  });
}
// Package updates move an existing receiver to the new release and keep its
// on/off state. Never creates a registration or enables a stopped one. Nothing
// is started here; the installer starts an enabled receiver after its final
// closed-Claude check, because the receiver itself may launch the Claude CLI.
export async function switchClaudeNativeTaskService({ storeRoot, root, expectedManifestSha256, nodePath = process.execPath, verifyRelease: verify = verifyRelease, scheduledTask: task = scheduledTask }) {
  runtimeSafety.assertHelloLynkClientNodeVersion();
  return withClaudeNativeServiceRecord(storeRoot, async registry => {
    const record = await registry?.read();
    if (!record) return { changed: false, status: "not_installed" };
    const target = { root: path.resolve(root), expectedManifestSha256, nodePath };
    if (sameRelease(record, target)) return { changed: false, status: "current" };
    const enabled = record.enabled && Boolean(await readClaudeNativeTaskWorkerConfig(storeRoot));
    const service = release => ({ version: 1, root: release.root, expectedManifestSha256: release.expectedManifestSha256,
      nodePath: release.nodePath, enabled: false, startAtLogon: record.startAtLogon });
    // A missing old node.exe (Node moved or reinstalled) must not block updates.
    // The old release is still fully verified; restoring it uses the current node.
    // Its task, whose definition names the missing node, is withdrawn by the new
    // release's script.
    const nodeMissing = !(await fs.stat(record.nodePath).then(stat => stat.isFile(), () => false));
    const old = service(record), current = service(target), previous = nodeMissing ? { ...old, nodePath } : old;
    await verify({ ...current, storeRoot });
    await verify({ ...previous, storeRoot }, true);
    const move = async (from, to, on) => {
      // Withdraw first: a running receiver sees this and exits on its own.
      await registry.save({ ...record, enabled: false });
      await task({ ...from, storeRoot, ...(from === old && nodeMissing ? { driverRoot: current.root } : {}) }, "Uninstall");
      const installed = await task({ ...to, storeRoot }, "Install");
      if (!on && (await task({ ...to, storeRoot }, "Stop")).taskName !== installed.taskName) throw failure("claude_native_service_record_mismatch");
      const saved = { ...to, enabled: on, taskName: installed.taskName }; validate(saved); await registry.save(saved);
    };
    try { await move(old, current, enabled); }
    catch (error) {
      // Put the previous release back exactly as it was, then report the failure.
      try { await move(current, previous, record.enabled); }
      catch { throw failure("claude_native_service_switch_rollback_incomplete"); }
      throw error;
    }
    return { changed: true, status: "switched", enabled };
  });
}
export async function startRecordedClaudeNativeTaskService({ storeRoot, verifyRelease: verify = verifyRelease, scheduledTask: task = scheduledTask } = {}) {
  return withClaudeNativeServiceRecord(storeRoot, async registry => {
    const record = await registry?.read();
    if (!record) return { configured: false, status: "not_installed" };
    if (!record.enabled || !(await readClaudeNativeTaskWorkerConfig(storeRoot))) return { configured: true, status: "disabled" };
    const options = { ...record, storeRoot };
    await verify(options);
    for (const command of ["Verify", "Start"]) {
      const result = await task(options, command);
      if (result.taskName !== record.taskName) throw failure("claude_native_service_record_mismatch");
    }
    return { configured: true, status: "service_started" };
  });
}
export async function runClaudeNativeTaskReceiver(options) {
  // save() publishes complete JSON with one rename. Reading it needs no write
  // lock, so idle polling does not change directory identity or wait for the
  // Scheduler. Stop's published enabled=false is visible immediately.
  const allowed = async () => {
    const record = await readServiceRecord(serviceRecordPath(options.storeRoot));
    return Boolean(record?.enabled && sameRelease(record, options) && await readClaudeNativeTaskWorkerConfig(options.storeRoot));
  };
  if (options.signal?.aborted || !(await allowed())) return { status: "disabled" };
  const createAdapter = options.createAdapter || (await import("./mcp-proxy.mjs")).createClaudeCodeProxyAdapter;
  const adapter = options.adapter || createAdapter({ storeRoot: options.storeRoot });
  let worker, timer, checking = false, finish;
  const stopped = new Promise(resolve => { finish = resolve; });
  const stop = () => finish();
  options.signal?.addEventListener("abort", stop, { once: true });
  try {
    worker = await (options.startNativeWorker || startClaudeNativeTaskWorker)({ adapter, storeRoot: options.storeRoot });
    void worker.ready?.catch(stop);
    // Referenced timer keeps Node alive even when worker recovery timers are
    // unref'ed. It checks only local enablement; no Host/model empty turns.
    timer = setInterval(async () => {
      if (checking) return;
      checking = true;
      try { if (!(await allowed())) stop(); } catch { stop(); }
      finally { checking = false; }
    }, options.controlIntervalMs || 500);
    if (options.signal?.aborted) stop();
    await stopped;
    return { status: "stopped" };
  } finally {
    clearInterval(timer); options.signal?.removeEventListener("abort", stop);
    try { await worker?.stop?.(); } finally { await adapter.close?.(); }
  }
}
