import crypto from 'node:crypto';
import { readNativeReplyRoute } from '../../../runtime/core/hellolynk-native-reply-routes.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { tryAcquireNativeWorkerLease } from '../../../runtime/core/hellolynk-native-worker-lease.mjs';
import { createNativeDirectoryPublisher } from '../../../runtime/core/hellolynk-native-conversations.mjs';
import { listClaudeConversations } from './native-conversation-directory.mjs';
import { readNativeNoticeLocale, nativeNoticeText } from '../../../runtime/core/hellolynk-native-notice.mjs';
import { collectInboxBatch, inboxBatchNotice, pendingByTarget, pendingInboxAttempt, attemptInboxBatch, retainInboxAttempt } from './inbox-batch.mjs';

const TARGET = /^claude-conv:[a-f0-9]{64}$/;
const HASH = /^[a-f0-9]{64}$/;
const hash = v => crypto.createHash('sha256').update(JSON.stringify(v)).digest('hex');
const fail = code => Object.assign(new Error(code), { code });
const scopeKey = s => hash([path.resolve(s.runtimeRoot).toLowerCase(), s.adapterId, s.region, s.principalId, s.delegateId]);
const safeCode = e => /^claude_[a-z0-9_]{1,100}$/.test(e?.code || '') ? e.code : 'claude_native_unavailable';
const CONFIG = 'claude-native-uia.json';

async function safeDirectory(directory, create = false) {
  if (!path.isAbsolute(directory)) throw fail('claude_native_path_invalid');
  for (let current = path.resolve(directory); ; current = path.dirname(current)) {
    const stat = await fs.lstat(current).catch(e => { if (e.code === 'ENOENT') return null; throw e; });
    if (stat && (!stat.isDirectory() || stat.isSymbolicLink())) throw fail('claude_native_path_invalid');
    if (path.dirname(current) === current) break;
  }
  if (create) await fs.mkdir(directory, { recursive: true, mode: 0o700 });
}
async function jsonFile(filename, limit) {
  const stat = await fs.lstat(filename);
  if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 || stat.size > limit) throw fail('claude_native_state_invalid');
  return JSON.parse(await fs.readFile(filename, 'utf8'));
}
export async function writeClaudeNativeJson(filename, value) {
  const temporary = `${filename}.${crypto.randomUUID()}.tmp`;
  try {
    await fs.writeFile(temporary, `${JSON.stringify(value, null, 2)}\n`, { flag: 'wx', mode: 0o600 });
    for (let attempt = 0; ; attempt++) {
      try { await fs.rename(temporary, filename); break; }
      catch (error) {
        // A read-only poll can briefly hold the old file open on Windows.
        // Retry only local publication; permanent failures retain the old file.
        if (process.platform !== 'win32' || !['EPERM', 'EACCES', 'EBUSY'].includes(error.code) || attempt >= 5) throw error;
        await new Promise(resolve => setTimeout(resolve, 10 * (attempt + 1)));
      }
    }
  }
  finally { await fs.unlink(temporary).catch(e => { if (e.code !== 'ENOENT') throw e; }); }
}
function configDirectory(storeRoot) {
  if (typeof storeRoot !== 'string' || !path.isAbsolute(storeRoot)) throw fail('claude_native_path_invalid');
  return path.join(storeRoot, 'runtime', 'native-tasks');
}
// Only the background CLI route is supported. An old UIA config is ignored.
function validateConfig(value) {
  if (value?.contract === 'hellolynk-claude-native-uia-v1') return null;
  if (value?.contract !== 'hellolynk-claude-background-v1'
    || Object.keys(value).sort().join(',') !== 'cliPath,contract,executionMode,workingDirectory'
    || value.executionMode !== 'background-cli' || !path.isAbsolute(value.cliPath || '')
    || !path.isAbsolute(value.workingDirectory || '') || !/^claude(?:\.exe)?$/i.test(path.basename(value.cliPath))) throw fail('claude_native_config_invalid');
  return value;
}
export async function configureClaudeNativeTaskWorker({ storeRoot, enabled, executionMode, cliPath, workingDirectory } = {}) {
  const directory = configDirectory(storeRoot);
  await safeDirectory(directory, enabled === true);
  const filename = path.join(directory, CONFIG);
  if (enabled === false) { await fs.unlink(filename).catch(e => { if (e.code !== 'ENOENT') throw e; }); return { enabled: false }; }
  if (enabled !== true || executionMode !== 'background-cli') throw fail('claude_native_config_invalid');
  const value = validateConfig({ contract: 'hellolynk-claude-background-v1', executionMode, cliPath, workingDirectory });
  const executable = await fs.lstat(cliPath);
  if (!executable.isFile() || executable.isSymbolicLink()) throw fail('claude_native_config_invalid');
  await safeDirectory(workingDirectory);
  if (!(await fs.lstat(workingDirectory)).isDirectory()) throw fail('claude_native_config_invalid');
  await writeClaudeNativeJson(filename, value);
  return { enabled: true, executionMode };
}
export async function readClaudeNativeTaskWorkerConfig(storeRoot) {
  const directory = configDirectory(storeRoot);
  await safeDirectory(directory);
  try { return validateConfig(await jsonFile(path.join(directory, CONFIG), 2048)); }
  catch (e) { if (e.code === 'ENOENT') return null; throw e; }
}

export function claudeNativeTaskPrompt(count, batchId, locale = 'en') {
  return `${inboxBatchNotice(count, batchId, '来信', locale)}\n${nativeNoticeText(locale, 'claudeTask', { batchId })}`;
}

// One background Claude session (title) per HelloLynk conversation, and one
// Host batch target per session. A resident CLI takes new letters while it
// runs. Delivery is the model's receipt of the prompt, never completion.
export function startClaudeNativeTaskWorker({ adapter, storeRoot, config, recoveryMs = 5000,
  acquireLease = tryAcquireNativeWorkerLease, clientFactory = createClaudeTaskClient, readConfig = readClaudeNativeTaskWorkerConfig,
  readNoticeLocale = readNativeNoticeLocale } = {}) {
  if (!adapter || typeof adapter.getNativeTaskScope !== 'function' || typeof adapter.listPendingMessages !== 'function'
    || !Number.isSafeInteger(recoveryMs) || recoveryMs < 100) throw fail('claude_native_worker_options_invalid');
  let closed = false, flight, lease, key, ui, clientConfigKey;
  let directoryFlight;
  const publishDirectory = createNativeDirectoryPublisher({ listConversations: (query, scope) => listClaudeConversations(scope, query) });
  let status = { status: 'starting' };
  const retire = async () => { await ui?.close?.(); await lease?.release(); lease = null; key = null; ui = null; };
  const markerOf = batch => `hellolynk-${hash([key, batch.batchId, batch.attempts])}`;
  async function submit(batch, title, scope) {
    const locale = await readNoticeLocale();
    if (closed) return;
    if (scopeKey(await adapter.getNativeTaskScope()) !== scopeKey(scope)) return;
    const tried = await attemptInboxBatch(adapter, scope, batch);
    if (!tried.attempted) return;
    if (closed) {
      if (tried.attempts > 1) await retainInboxAttempt(scope, tried);
      else await adapter.cancelInboxBatch(tried.batchId);
      return;
    }
    const sent = await ui.submit({ title, text: claudeNativeTaskPrompt(tried.count, tried.batchId, locale), marker: markerOf(tried),
      // The CLI names the session that will read this batch before writing
      // its prompt; reposting the same attempt pins it without a new try.
      pin: sessionId => adapter.attemptInboxBatch(tried.batchId, tried.attemptId, sessionId) });
    // The session lock proves nothing started; the Host returns the letters
    // only after a first try.
    if (sent.submissionAttempted === false) await adapter.cancelInboxBatch(tried.batchId);
    else status = { status: 'submitted' };
  }
  async function settle(batch, scope) {
    const title = titleOf(batch.target);
    if (await pendingInboxAttempt(scope, batch)) {
      if ((await ui.ready({ title })).ready) await submit(batch, title, scope);
      return;
    }
    const proof = await ui.confirm({ title, marker: markerOf(batch) }).catch(() => null);
    if (proof?.confirmed === true) return adapter.confirmInboxBatch(batch.batchId);
    // Only a first try is decided here; the Host never returns a batch after
    // an unknown first try, so it cannot wake the session a third time.
    if (batch.attempts !== 1) return;
    // The CLI records each try before spawning, so no record means no spawn.
    if (proof?.definitelyNotSubmitted === true || proof?.status === 'not_submitted') return adapter.cancelInboxBatch(batch.batchId);
    // A run that ended without accepting its prompt gets one more try. A
    // running or unreadable one keeps waiting.
    if (['failed', 'cancelled'].includes(proof?.status) && (await ui.ready({ title })).ready) await submit(batch, title, scope);
  }
  async function tickImpl() {
    try {
      const currentConfig = config ?? await readConfig(storeRoot);
      const scope = await adapter.getNativeTaskScope(), nextKey = scopeKey(scope);
      if (key !== nextKey || clientConfigKey !== hash(currentConfig ?? null)) await retire();
      if (!lease) {
        lease = await acquireLease(scope);
        if (!lease) { status = { status: 'another_process_receiving' }; return; }
        key = nextKey;
        clientConfigKey = hash(currentConfig ?? null);
      }
      await directoryTick();
      if (!currentConfig) { status = { status: 'disabled' }; return; }
      if (!ui) try { ui = await clientFactory({ ...currentConfig, scope, storeRoot }); }
      catch (error) { await retire(); throw error; }
      if (closed) return;
      status = { status: 'listening' };
      const reserved = (await adapter.openInboxBatches({ state: 'reserved' })).filter(batch => TARGET.test(batch.target || ''));
      for (const batch of reserved) if (batch.attempts > 0 && !closed) await settle(batch, scope);
      // Replies resume only the exact session that sent them; others stay pending.
      const replies = new Set();
      const pending = await pendingByTarget(adapter, async item => {
        const target = `claude-conv:${hash(item.conversationKey)}`;
        if (item.targetConversationId) return null;
        if (item.replyToClientMessageId == null) return target;
        const origin = await readNativeReplyRoute(scope, item);
        if (!origin || !await ui.ownsSession({ title: titleOf(target), threadId: origin.threadId })) return null;
        replies.add(item.localMessageId);
        return target;
      });
      const resume = new Map(reserved.filter(batch => batch.attempts === 0).map(batch => [batch.target, batch]));
      for (const target of new Set([...resume.keys(), ...pending.keys()])) {
        if (closed) return;
        const title = titleOf(target), ready = await ui.ready({ title });
        if (!ready.ready) continue;
        let ids = pending.get(target) || [];
        if (ready.replacesSession) {
          // CLI history can disappear without a human closing or reading it.
          // Preserve delivered batches and human unread; replies to the old
          // session stay in HelloLynk while new letters may start a new UUID.
          ids = ids.filter(id => !replies.has(id));
        }
        const batch = await collectInboxBatch(adapter, target, ids, resume.get(target) || null);
        if (batch) await submit(batch, title, scope);
      }
    } catch (error) { status = { status: 'unavailable', errorCode: safeCode(error) }; }
  }
  function directoryTick() {
    // Metadata discovery is also available with only the desktop Mod installed.
    // Use the existing timer, independently of background model delivery.
    if (closed || !lease) return Promise.resolve();
    return directoryFlight ||= (async () => {
      const scope = await adapter.getNativeTaskScope(), currentKey = scopeKey(scope);
      if (currentKey !== key) return;
      await publishDirectory(scope, async () => !closed && Boolean(lease) && scopeKey(await adapter.getNativeTaskScope()) === currentKey);
    })().catch(() => {}).finally(() => { directoryFlight = null; });
  }
  function tick() {
    if (closed) return Promise.resolve();
    if (flight) { void directoryTick(); return flight; }
    flight = tickImpl().finally(() => { flight = null; });
    return flight;
  }
  const ready = tick();
  const timer = setInterval(() => { void tick(); }, recoveryMs); timer.unref?.();
  return Object.freeze({ ready, tick, getStatus: () => ({ ...status }),
    async stop() { closed = true; clearInterval(timer); await flight; await directoryFlight; await retire(); },
  });
}

function titleOf(target) {
  if (!TARGET.test(target)) throw fail('claude_native_pending_invalid');
  return `HelloLynk · ${target.slice('claude-conv:'.length, 'claude-conv:'.length + 16)}`;
}

async function createClaudeTaskClient(config) {
  const { createClaudeNativeTaskCli } = await import('./native-task-cli.mjs');
  const pin = JSON.parse(await fs.readFile(new URL('../../../runtime/neutral-host-release-pin.json', import.meta.url), 'utf8'));
  if (!HASH.test(pin.manifestSha256 || '')) throw fail('claude_native_config_invalid');
  return createClaudeNativeTaskCli({ ...config, mcpServer: { command: process.execPath,
    args: [fileURLToPath(new URL('./package-bootstrap.mjs', import.meta.url)), 'run-agent', '--root', config.storeRoot,
      '--expected-manifest-sha256', pin.manifestSha256] } });
}
