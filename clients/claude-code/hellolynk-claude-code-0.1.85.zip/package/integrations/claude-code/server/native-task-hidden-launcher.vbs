Option Explicit
Dim args, fso, shell, node, entry, root, manifest, store, expression, command
Set args = WScript.Arguments
If args.Count <> 5 Then WScript.Quit 1
Set fso = CreateObject("Scripting.FileSystemObject")
node = args(0): entry = args(1): root = args(2): manifest = args(3): store = args(4)
Set expression = New RegExp
expression.Pattern = "^[a-f0-9]{64}$"
If Not expression.Test(manifest) Then WScript.Quit 1
If LCase(fso.GetAbsolutePathName(root)) <> LCase(root) Or LCase(fso.GetAbsolutePathName(store)) <> LCase(store) Then WScript.Quit 1
If LCase(fso.GetFileName(node)) <> "node.exe" Or LCase(fso.GetFileName(store)) <> "host" Then WScript.Quit 1
If LCase(entry) <> LCase(fso.BuildPath(root, "integrations\claude-code\server\package-bootstrap.mjs")) Then WScript.Quit 1
If LCase(WScript.ScriptFullName) <> LCase(fso.BuildPath(root, "integrations\claude-code\server\native-task-hidden-launcher.vbs")) Then WScript.Quit 1
If Not fso.FileExists(node) Or Not fso.FileExists(entry) Then WScript.Quit 1
Set shell = CreateObject("WScript.Shell")
shell.CurrentDirectory = root
command = Quote(node) & " " & Quote(entry) & " receive --root " & Quote(store) & " --expected-manifest-sha256 " & manifest
WScript.Quit shell.Run(command, 0, True)
Function Quote(value)
  If InStr(value, Chr(34)) > 0 Or InStr(value, vbCr) > 0 Or InStr(value, vbLf) > 0 Then WScript.Quit 1
  Quote = Chr(34) & value & Chr(34)
End Function
