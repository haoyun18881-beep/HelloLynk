import { createHash } from "node:crypto";
import { composeWorkbenchMcpAppHtml } from "../../../runtime/workbench/mcp-app-bundle.mjs";
import { validateWorkbenchSnapshot, validateWorkbenchReadRequest, validateWorkbenchCommand, validateWorkbenchCommandResult,
  HELLOLYNK_WORKBENCH_COMMAND_TYPES, HELLOLYNK_WORKBENCH_COMMAND_CONTRACT, HELLOLYNK_WORKBENCH_SCHEMA_VERSION } from "../../../runtime/workbench/contract.mjs";
import { workbenchConnectionError } from "../../../runtime/core/hellolynk-workbench-connection.mjs";

export const CLAUDE_WORKBENCH_MIME = "text/html;profile=mcp-app";
const RESOURCE_META = Object.freeze({ ui: Object.freeze({ prefersBorder: true,
  csp: Object.freeze({ connectDomains: Object.freeze([]), resourceDomains: Object.freeze([]) }) }) });
export function supportsClaudeWorkbenchApp(capabilities) {
  const mimeTypes = capabilities?.extensions?.["io.modelcontextprotocol/ui"]?.mimeTypes;
  return Array.isArray(mimeTypes) && mimeTypes.includes(CLAUDE_WORKBENCH_MIME);
}

const PREFIX = "hellolynk_workbench_";
const REVISION = { type: "string", pattern: "^(initial|[a-f0-9]{32})$" };
const GRANT = { type: "string", pattern: "^[A-Za-z0-9][A-Za-z0-9._:-]{31,511}$" };
const COMMAND = { type: "object", additionalProperties: false,
  required: ["contractId", "schemaVersion", "command", "requestId", "idempotencyKey", "expectedRevision", "payload"],
  properties: { contractId: { const: HELLOLYNK_WORKBENCH_COMMAND_CONTRACT }, schemaVersion: { const: HELLOLYNK_WORKBENCH_SCHEMA_VERSION },
    command: { enum: Object.values(HELLOLYNK_WORKBENCH_COMMAND_TYPES) }, requestId: { type: "string" }, idempotencyKey: { type: "string" },
    expectedRevision: { type: ["string", "null"] }, payload: { type: "object" } } };
const READ_FIELDS = { threadId: { type: "string" }, threadCursor: { type: "string" }, messageCursor: { type: "string" },
  contactRequestCursor: { type: ["string", "null"] }, historyBefore: { type: ["string", "null"] },
  query: { type: "string" }, filter: { enum: ["all", "unread", "archived"] } };
const PUBLIC_ERRORS = new Set(["workbench_connection_required", "workbench_account_changed", "workbench_account_disconnect_incomplete",
  "workbench_connect_busy", "powershell7_missing", "credential_helper_unavailable", "hellolynk_node_22_16_required",
  "device_enrollment_name_invalid", "device_enrollment_hellolynk_id_invalid", "device_enrollment_existing_profile_requires_setup",
  "agent_instance_name_invalid", "agent_instance_name_conflict", "device_enrollment_busy",
  "device_enrollment_request_timeout", "device_enrollment_request_failed",
  "device_enrollment_intent_conflict", "device_enrollment_authorization_expired", "device_enrollment_owner_conflict",
  "workbench_connect_id_invalid", "workbench_connect_name_invalid", "workbench_connect_failed", "workbench_connect_pending",
  "workbench_action_grant_invalid", "workbench_command_invalid", "workbench_snapshot_invalid", "workbench_changes_invalid",
  "host_app_authorization_required", "host_app_state_conflict", "host_request_unauthorized", "invalid_params"]);

// This transport is offered only after the host advertises MCP Apps. Claude's
// host must enforce app-only tool visibility; do not expose these tools to a
// plain CLI connection. The browser route keeps its own session/CSRF boundary.
export async function createClaudeWorkbenchApp({ adapter, connectAccount }) {
  const bundle = await composeWorkbenchMcpAppHtml({ withManifest: true, title: "HelloLynk · Claude" });
  const resourceHash = createHash("sha256").update(JSON.stringify({ html: bundle.manifest.outputSha256, meta: RESOURCE_META })).digest("hex");
  const resourceUri = `ui://hellolynk/workbench-claude-${resourceHash}.html`;
  const resource = { uri: resourceUri, name: "HelloLynk 通讯", mimeType: CLAUDE_WORKBENCH_MIME };
  const scoped = (properties) => ({ ...properties, _hellolynkAccountRevision: REVISION });
  const definitions = [
    definition("account", {}, [], true),
    definition("disconnect", { revision: REVISION }, ["revision"]),
    definition("connect", scoped({ hellolynkId: { type: "string" }, instanceName: { type: "string" } }), ["hellolynkId", "instanceName", "_hellolynkAccountRevision"]),
    definition("snapshot", scoped(READ_FIELDS), ["_hellolynkAccountRevision"], true),
    definition("changes", scoped({ afterCursor: { type: "integer", minimum: 0 } }), ["afterCursor", "_hellolynkAccountRevision"], true),
    definition("action_grant", scoped({ command: COMMAND }), ["command", "_hellolynkAccountRevision"]),
    definition("command", scoped({ command: COMMAND, _hellolynkUiActionGrant: GRANT }), ["command", "_hellolynkAccountRevision"]),
  ];
  function definition(suffix, properties, required, readOnly = false) {
    return { name: PREFIX + suffix, description: "仅供 HelloLynk 交互卡片使用；账号、正文和授权结果只进入应用私有数据。",
      inputSchema: { type: "object", additionalProperties: false, properties, required },
      annotations: { readOnlyHint: readOnly, openWorldHint: !readOnly, destructiveHint: !readOnly, idempotentHint: readOnly },
      _meta: { ui: { resourceUri, visibility: ["app"] } } };
  }
  const names = new Set(definitions.map((item) => item.name));
  return Object.freeze({
    resourceUri, tools: definitions, resource,
    readResource(uri) {
      // Serve this installed UI for retained invocations, never an old bundle.
      if (!/^ui:\/\/hellolynk\/workbench-claude-[a-f0-9]{64}\.html$/.test(uri)) throw failure("resource_not_found");
      return { contents: [{ uri, mimeType: CLAUDE_WORKBENCH_MIME, text: bundle.html,
        _meta: RESOURCE_META }] };
    },
    async callTool(name, args = {}) {
      if (!names.has(name)) return null;
      try {
        if (!plain(args)) throw failure("invalid_params");
        if (name === PREFIX + "account") { exact(args, []); return privateResult("account", connectAccount.readAccountState()); }
        if (name === PREFIX + "disconnect") {
          exact(args, ["revision"]); checkRevision(args.revision);
          return privateResult("disconnection", await connectAccount.disconnectAccount(args));
        }
        const { _hellolynkAccountRevision: revision, ...input } = args;
        checkRevision(revision); connectAccount.assertRevision(revision);
        const operation = async () => {
          if (name === PREFIX + "connect") {
            exact(input, ["hellolynkId", "instanceName"]);
            return privateResult("connection", await connectAccount(input, revision));
          }
          if (name === PREFIX + "snapshot") {
            const snapshot = validateWorkbenchSnapshot(await adapter.readWorkbenchSnapshot(validateWorkbenchReadRequest(input)));
            if (snapshot.source.mode !== "neutral-host" || snapshot.source.clientId !== "claude-code"
              || snapshot.source.transport !== "loopback-http") throw failure("workbench_snapshot_invalid");
            // Host describes its loopback route; this projection is delivered
            // over MCP Apps, while identity, capabilities and contents are kept.
            return privateResult("snapshot", { ...snapshot, source: { ...snapshot.source, transport: "mcp-app-rpc", clientLabel: "Claude Code" } });
          }
          if (name === PREFIX + "changes") {
            exact(input, ["afterCursor"]);
            if (!Number.isSafeInteger(input.afterCursor) || input.afterCursor < 0) throw failure("invalid_params");
            const batch = await adapter.readWorkbenchChanges(input);
            if (!Number.isSafeInteger(batch?.cursor) || batch.cursor < 0 || !/^[a-f0-9]{48}$/.test(batch.hostGeneration)
              || typeof batch.snapshotRequired !== "boolean" || !Array.isArray(batch.events) || batch.events.length > 256) throw failure("workbench_changes_invalid");
            return privateResult("changes", { cursor: batch.cursor, hostGeneration: batch.hostGeneration, snapshotRequired: batch.snapshotRequired, changed: batch.events.length > 0 });
          }
          const command = validateWorkbenchCommand(input.command);
          const statusRead = command.command === "message.send-status";
          if (name === PREFIX + "action_grant") {
            exact(input, ["command"]);
            if (statusRead) throw failure("workbench_action_grant_invalid");
            const issued = await adapter.issueWorkbenchActionGrant(command);
            exact(issued, ["actionGrant"]); checkGrant(issued.actionGrant);
            return privateResult("actionGrant", issued.actionGrant);
          }
          exact(input, statusRead ? ["command"] : ["command", "_hellolynkUiActionGrant"]);
          if (!statusRead) checkGrant(input._hellolynkUiActionGrant);
          const result = validateWorkbenchCommandResult(await adapter.executeWorkbenchCommand(command,
            statusRead ? {} : { actionGrant: input._hellolynkUiActionGrant }), command.command);
          if (result.requestId !== command.requestId) throw failure("workbench_command_invalid");
          return privateResult("commandResult", result);
        };
        // Connection establishes a new account generation using its own CAS.
        if (name === PREFIX + "connect") return await operation();
        if ([PREFIX + "command", PREFIX + "action_grant"].includes(name)) return await connectAccount.runForAccount(revision, operation);
        const result = await operation(); connectAccount.assertRevision(revision); return result;
      } catch (error) {
        const code = workbenchConnectionError(error)?.code;
        const publicCode = PUBLIC_ERRORS.has(code) ? code : "workbench_operation_failed";
        if (name === PREFIX + "changes") return { ...privateResult("changeError", { code: publicCode }), isError: true };
        return { content: [], structuredContent: { ok: false, errorCode: publicCode }, isError: true };
      }
    },
  });
}

function privateResult(field, value) { return { content: [], structuredContent: { ok: true }, _meta: { hellolynkWorkbench: { [field]: value } }, isError: false }; }
function plain(value) { return value && typeof value === "object" && !Array.isArray(value); }
function exact(value, keys) { if (!plain(value) || Object.keys(value).sort().join(",") !== [...keys].sort().join(",")) throw failure("invalid_params"); }
function checkRevision(value) { if (typeof value !== "string" || !new RegExp(REVISION.pattern).test(value)) throw failure("invalid_params"); }
function checkGrant(value) { if (typeof value !== "string" || !new RegExp(GRANT.pattern).test(value)) throw failure("workbench_action_grant_invalid"); }
function failure(code) { return Object.assign(new Error(code), { code }); }
