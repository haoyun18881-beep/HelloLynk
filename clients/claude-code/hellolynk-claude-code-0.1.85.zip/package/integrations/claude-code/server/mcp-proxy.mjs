#!/usr/bin/env node
import path from "node:path";
import { pathToFileURL, fileURLToPath } from "node:url";
import { createClaudeCodeNeutralHostAdapter, createClaudeCodeProtectedBindingProvider } from "./neutral-host-adapter.mjs";
import { launchClaudeCodeNeutralHost } from "./host-lifecycle.mjs";
import { runClaudeCodeStdioMcpServer, toClaudeCodePublicErrorCode } from "./mcp-server.mjs";
import { bootstrapWorkbenchCandidate } from "../../../runtime/workbench/candidate-bootstrap.mjs";
import { readClientAccount, clientAccountBaseRoot } from "../../../runtime/core/hellolynk-client-account.mjs";
import { defaultClaudeCodeStoreRoot } from "../../../runtime/core/hellolynk-host-protected-store.mjs";
import { createWorkbenchConnection, createWorkbenchAccountOpener, workbenchConnectionError } from "../../../runtime/core/hellolynk-workbench-connection.mjs";
import { startClaudeNativeTaskWorker } from "./native-task-worker.mjs";
import { startRecordedClaudeNativeTaskService } from "./native-task-service.mjs";
import { createClaudeWorkbenchApp } from "./workbench-app.mjs";
import { createClaudeInboxCard } from "./inbox-card.mjs";
import { rememberNativeReplyRoute } from "../../../runtime/core/hellolynk-native-reply-routes.mjs";

// A failed logical write is never retried. Reconnection only happens before the
// next explicitly requested operation; account generations retire old adapters.
export function createClaudeCodeProxyAdapter(options = {}) {
  options = { ...options, storeRoot: options.storeRoot || defaultClaudeCodeStoreRoot(options.env) };
  assertStoreRoot(options.storeRoot);
  let current = null, flight = null, closed = false, resetting = null;
  const revision = () => readClientAccount("claude-code", options.storeRoot).revision;
  let generation = revision();
  async function connect() {
    if (closed) throw failure("neutral_host_adapter_closed");
    const next = revision();
    if (!resetting && generation !== next) {
      const old = current, previousFlight = flight;
      generation = next;
      current = null; flight = null;
      resetting = Promise.resolve().then(async () => {
        const previous = await previousFlight?.catch(() => null);
        await (previous || old)?.close?.();
      }).finally(() => { resetting = null; });
    }
    if (resetting) await resetting;
    if (generation !== revision()) throw failure("workbench_account_changed");
    if (current?.state === "attached") return current;
    if (current) { await current.close(); current = null; }
    if (!flight) {
      const expected = generation;
      flight = Promise.resolve().then(() => (options.createAdapter || createClaudeCodeNeutralHostAdapter)({
        ...options,
        capabilityProvider: options.capabilityProvider || createClaudeCodeProtectedBindingProvider(options),
        hostLauncher: options.hostLauncher || ((binding) => launchClaudeCodeNeutralHost(binding, { storeRoot: path.dirname(binding.runtimeRoot) })),
      })).then(async (value) => {
        if (closed || expected !== revision()) { await value.close(); throw failure("workbench_account_changed"); }
        current = value; return value;
      }).finally(() => { flight = null; });
    }
    return flight;
  }
  const methods = ["hostStatus", "getNativeTaskScope", "readUnreadCount", "readRecentUnreadMetadata", "readWorkbenchSnapshot", "readWorkbenchChanges", "issueWorkbenchActionGrant", "executeWorkbenchCommand", "listAuthorizedContacts", "listAuthorizedInboxMessages", "listPendingMessages", "claimMessage", "claimInboxBatch", "reserveInboxBatch", "expireInboxBatch", "openInboxBatches", "attemptInboxBatch", "confirmInboxBatch", "cancelInboxBatch", "closeInboxBatch", "readAuthorizedInboxMessage", "listAuthorizedContactRequests", "readAuthorizedContactRequest", "sendAuthorizedMessage", "replyAuthorizedMessage", "modelInbox"];
  return Object.freeze({
    ...Object.fromEntries(methods.map((name) => [name, async (...args) => (await connect())[name](...args)])),
    prewarm: () => connect().then(() => undefined, () => undefined),
    async close() { closed = true; const pending = await flight?.catch(() => null); await (pending || current)?.close?.(); current = null; },
  });
}

export async function runClaudeCodeMcpProxy(options = {}) {
  options = { ...options, storeRoot: options.storeRoot || defaultClaudeCodeStoreRoot(options.env) };
  assertStoreRoot(options.storeRoot);
  const adapter = options.adapter || createClaudeCodeProxyAdapter(options);
  const connectAccount = options.connectAccount || createWorkbenchConnection({ client: "claude-code", storeRoot: options.storeRoot,
    releaseRoot: path.resolve(fileURLToPath(new URL("../../../", import.meta.url))) });
  // A model worker is already driven by the receiver. Not starting another
  // receiver in this MCP connection is ownership, not disabled mail handling.
  const managedByReceiver = options.nativeTasks === false && (options.env || process.env).HELLOLYNK_NATIVE_BACKGROUND === "1";
  const env = options.env || process.env;
  const backgroundSessionId = env.HELLOLYNK_NATIVE_BACKGROUND === '1' ? env.HELLOLYNK_NATIVE_BACKGROUND_SESSION_ID : undefined;
  if (env.HELLOLYNK_NATIVE_BACKGROUND === '1' && !/^[a-f0-9-]{36}$/.test(backgroundSessionId || '')) throw failure('claude_native_origin_missing');
  let candidate = null, worker = null, closed = false, nativeStatus = { status: managedByReceiver ? "managed_by_receiver" : "disabled" };
  const openLocalWeb = options.openLocalWeb || (async () => {
    if (candidate) { candidate.surface.armNavigation(); return candidate; }
    candidate = await bootstrapWorkbenchCandidate("claude-code", {
      adapter: {
        readSnapshot: (input) => Promise.resolve().then(() => adapter.readWorkbenchSnapshot(input)).catch((error) => { throw workbenchConnectionError(error); }),
        readChanges: (input) => adapter.readWorkbenchChanges(input),
        issueActionGrant: (command) => adapter.issueWorkbenchActionGrant(command),
        executeCommand: (command, context) => adapter.executeWorkbenchCommand(command, context),
      },
      connectAccount,
      openAccount: options.openAccount || createWorkbenchAccountOpener(),
    });
    return candidate;
  });
  try {
    // A started message worker will use Host tools. Connect while its model is
    // preparing, without delaying initialize or waking ordinary conversations.
    if (options.prewarmAdapter === true) void Promise.resolve().then(() => adapter.prewarm?.()).catch(() => {});
    if (options.nativeTasks !== false) {
      nativeStatus = { status: "starting" };
      // Scheduler handoff must not delay MCP initialize. A registered receiver
      // outlives this MCP process; only an unregistered local fallback is owned
      // here. A disabled or broken registration must never become a fallback.
      void (async () => {
        const status = await (options.startRecordedNativeService || startRecordedClaudeNativeTaskService)({ storeRoot: options.storeRoot });
        nativeStatus = status;
        if (closed || status.configured) return;
        const started = await (options.startNativeWorker || startClaudeNativeTaskWorker)({ adapter, storeRoot: options.storeRoot });
        if (closed) { await started.stop?.(); return; }
        worker = started;
        void worker.ready?.catch(() => {});
      })().catch((error) => {
        const code = String(error?.code || "");
        const errorCode = /^(?:claude_native_service_[a-z_]+|local_message_store_busy|hellolynk_local_process_lock_[a-z_]+|neutral_host_runner_integrity_invalid)$/.test(code)
          ? code : "claude_native_service_start_failed";
        nativeStatus = { status: "service_unavailable", configured: true, errorCode };
      });
    }
    return await (options.runServer || runClaudeCodeStdioMcpServer)({
      input: options.input, output: options.output, adapter,
      nativeTaskStatus: () => worker?.getStatus?.() || nativeStatus,
      backgroundSessionId,
      // Foreground send AND reply origins belong to the native mod. Only the
      // dedicated background process uses its fixed launch-time session here.
      prepareAuthorizedWrite: backgroundSessionId ? async message => {
        await rememberNativeReplyRoute(await adapter.getNativeTaskScope(), { ...message, threadId: backgroundSessionId });
      } : undefined,
      createWorkbenchApp: options.workbenchApp === false ? undefined : () => createClaudeWorkbenchApp({ adapter, connectAccount }),
      inboxCard: createClaudeInboxCard({ adapter, connectAccount, openLocalWeb, enableUi: options.workbenchApp !== false }),
      openLocalWeb,
    });
  } finally {
    closed = true;
    try { await worker?.stop?.(); }
    finally { try { await candidate?.close(); } finally { await adapter.close(); } }
  }
}
function failure(code) { return Object.assign(new Error(code), { code }); }
function assertStoreRoot(root) {
  const base = clientAccountBaseRoot(root);
  if (path.basename(base).toLowerCase() !== "host") throw failure("neutral_claude_code_store_root_invalid");
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  runClaudeCodeMcpProxy().catch((error) => { process.stderr.write(`${JSON.stringify({ ok: false, code: toClaudeCodePublicErrorCode(error) })}\n`); process.exitCode = 1; });
}
