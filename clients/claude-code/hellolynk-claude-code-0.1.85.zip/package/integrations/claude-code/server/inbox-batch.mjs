import fs from 'node:fs/promises';
import path from 'node:path';
import { nativeReplyRouteLocation } from '../../../runtime/core/hellolynk-native-reply-routes.mjs';
import { withLocalProcessLock } from '../../../runtime/core/hellolynk-local-process-lock.mjs';
import { nativeNoticeText } from '../../../runtime/core/hellolynk-native-notice.mjs';

// Shared by the original-session mod helper and the background worker. The
// Host owns selection, the 20,000-character window and the one-retry budget.
const ID = /^[A-Za-z0-9][A-Za-z0-9_.:-]{2,198}$/;
export const INBOX_BATCH_ID = /^inbatch_[a-f0-9]{48}$/;
const fail = () => Object.assign(new Error('claude_inbox_batch_invalid'), { code: 'claude_inbox_batch_invalid' });

// Groups every pending letter by its native destination, oldest first.
// targetOf returns a target string, or null to leave the letter pending.
export async function pendingByTarget(adapter, targetOf) {
  const groups = new Map();
  for (let cursor = 0; ;) {
    const inbox = await adapter.listPendingMessages({ cursor });
    if (!Array.isArray(inbox?.messages) || inbox.messages.length > 1000) throw fail();
    for (const item of inbox.messages) {
      if (item?.wakeEligible !== true || !ID.test(item.localMessageId || '') || !ID.test(item.conversationKey || '')) continue;
      const target = await targetOf(item);
      if (!target) continue;
      if (!groups.has(target)) groups.set(target, []);
      groups.get(target).push(item.localMessageId);
    }
    if (inbox.nextCursor == null) return groups;
    // A broken page chain must not end the scan and send a partial batch.
    if (!Number.isSafeInteger(inbox.nextCursor) || inbox.nextCursor <= cursor) throw fail();
    cursor = inbox.nextCursor;
  }
}

// Sends the newest candidates first. Once the batch is full, the Host marks
// every older candidate expired: kept for the human, never auto-delivered.
// Resuming an interrupted collection replays the same steps idempotently.
export async function collectInboxBatch(adapter, target, ids, batch = null) {
  for (let end = ids.length; end > 0; end -= 1000) {
    const candidates = ids.slice(Math.max(0, end - 1000), end);
    const next = batch?.full ? await adapter.expireInboxBatch(batch.batchId, candidates)
      : await adapter.reserveInboxBatch({ target, candidates, ...(batch ? { batchId: batch.batchId } : {}) });
    if (next?.status !== 'empty') batch = checked(next);
  }
  return batch;
}

export function checked(batch) {
  if (!INBOX_BATCH_ID.test(batch?.batchId || '') || !Number.isSafeInteger(batch.count) || !Number.isSafeInteger(batch.attempts)) throw fail();
  return batch;
}

function ticketPath(scope, batch, attempt) {
  checked(batch);
  return path.join(nativeReplyRouteLocation(scope).directory, `${batch.batchId}.attempt-${attempt}`);
}

// An empty marker remembers an unacknowledged registration or a retry stopped
// before native submission, not a model task. Its name is the stable ticket.
export async function pendingInboxAttempt(scope, batch) {
  for (const attempt of [1, 2]) {
    try {
      if (!(await fs.stat(ticketPath(scope, batch, attempt))).isFile()) throw fail();
      return attempt;
    } catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
  return null;
}

// A graceful stop before the native call must not spend the remaining try.
// Keep the same Host ticket; a prior uncertain submission is not cancelled.
export async function retainInboxAttempt(scope, batch) {
  await fs.writeFile(ticketPath(scope, batch, batch.attempts), '', { flag: 'a' });
}

// nativeThreadId, when the reading session is already known, pins the batch to
// it; otherwise the caller pins it later by reposting the returned attemptId.
export async function attemptInboxBatch(adapter, scope, batch, nativeThreadId) {
  const guard = ticketPath(scope, batch, 'lock');
  await fs.mkdir(path.dirname(guard), { recursive: true });
  return withLocalProcessLock(guard, async () => {
    const attempt = await pendingInboxAttempt(scope, batch) ?? batch.attempts + 1;
    if (attempt > 2) return { ...batch, attempted: false };
    const filename = ticketPath(scope, batch, attempt), attemptId = `${batch.batchId}:${attempt}`;
    // Keep the marker across helper/worker restarts if the Host committed but
    // its response was lost. Reposting this ID cannot consume another chance.
    const handle = await fs.open(filename, 'a');
    await handle.close();
    const result = await adapter.attemptInboxBatch(batch.batchId, attemptId, nativeThreadId);
    await fs.unlink(filename);
    return { ...result, attemptId };
  });
}

export function inboxBatchNotice(count, batchId, kind = '回信', locale = 'en') {
  if (!Number.isSafeInteger(count) || count < 1 || !INBOX_BATCH_ID.test(batchId || '')) throw fail();
  return nativeNoticeText(locale, kind === '来信' ? 'claudeIncoming' : 'claudeReply',
    { source: nativeNoticeText(locale, 'source'), count, batchId });
}
