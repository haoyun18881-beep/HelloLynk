import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';

const FORMAT = 'hellolynk-claude-cli-index-v1';
const HASH = /^[a-f0-9]{64}$/;
const MARKER = /^hellolynk-[a-f0-9]{64}$/;
const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const fail = () => Object.assign(new Error('claude_native_cli_state_invalid'), { code: 'claude_native_cli_state_invalid' });
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const object = value => value && typeof value === 'object' && !Array.isArray(value);
const ROW_BYTES = 2048;

export async function claudeTaskDirectorySafe(directory, create = false) {
  if (!path.isAbsolute(directory)) throw fail();
  for (let current = directory; ; current = path.dirname(current)) {
    const stat = await fs.lstat(current).catch(e => { if (e.code === 'ENOENT') return null; throw e; });
    if (stat && (!stat.isDirectory() || stat.isSymbolicLink())) throw fail();
    if (path.dirname(current) === current) break;
  }
  if (create) { await fs.mkdir(directory, { recursive: true, mode: 0o700 }); await claudeTaskDirectorySafe(directory); }
}
async function safeFile(filename) {
  const stat = await fs.lstat(filename).catch(e => { if (e.code === 'ENOENT') return null; throw e; });
  if (stat && (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1)) throw fail();
  return stat;
}
async function boundedFile(filename, limit) {
  const before = await safeFile(filename);
  if (!before) return null;
  if (before.size > limit) throw fail();
  const file = await fs.open(filename, 'r');
  try {
    const opened = await file.stat();
    if (opened.dev !== before.dev || opened.ino !== before.ino || opened.size > limit) throw fail();
    const bytes = Buffer.alloc(limit + 1);
    let length = 0;
    while (length < bytes.length) {
      const read = await file.read(bytes, length, bytes.length - length, null);
      if (!read.bytesRead) break;
      length += read.bytesRead;
    }
    const after = await file.stat();
    if (length > limit || after.size !== before.size || after.mtimeMs !== before.mtimeMs) throw fail();
    return bytes.subarray(0, length);
  } finally { await file.close(); }
}
async function atomicWrite(filename, content) {
  const temporary = `${filename}.${crypto.randomUUID()}.tmp`;
  let handle;
  try {
    handle = await fs.open(temporary, 'wx', 0o600);
    await handle.writeFile(content); await handle.sync(); await handle.close(); handle = null;
    await fs.rename(temporary, filename);
  } finally { await handle?.close(); await fs.rm(temporary, { force: true }); }
}
function currentState(value, title, cwdHash) {
  if (!object(value) || value.version !== 1 || value.title !== title || value.cwdHash !== cwdHash
    || !UUID.test(value.sessionId || '') || typeof value.sessionStarted !== 'boolean'
    || !['idle', 'active', 'blocked'].includes(value.phase)) throw fail();
  return { version: 1, title, cwdHash, sessionId: value.sessionId, sessionStarted: value.sessionStarted, phase: value.phase };
}
function deliveryEntry(marker, value, sessionId) {
  if (!MARKER.test(marker) || !object(value) || !UUID.test(value.inputId || '') || !HASH.test(value.inputHash || '')
    || !UUID.test(value.sessionId ?? sessionId ?? '') || typeof value.accepted !== 'boolean'
    || typeof value.result !== 'boolean' || typeof value.definitelyNotSubmitted !== 'boolean'
    || !['unknown', 'accepted', 'completed', 'failed', 'cancelled'].includes(value.status)
    || value.errorCode != null && !/^claude_native_cli_[a-z_]{1,60}$/.test(value.errorCode)) throw fail();
  return { sessionId: value.sessionId ?? sessionId, inputId: value.inputId, inputHash: value.inputHash,
    accepted: value.accepted, result: value.result, definitelyNotSubmitted: value.definitelyNotSubmitted, status: value.status,
    ...(value.errorCode ? { errorCode: value.errorCode } : {}) };
}
const parseRow = value => {
  if (typeof value !== 'string' || Buffer.byteLength(value) > ROW_BYTES) throw fail();
  try { return JSON.parse(value); } catch { throw fail(); }
};
function context(filename, title, cwdHash) {
  const scope = path.basename(path.dirname(filename));
  if (!path.isAbsolute(filename) || !HASH.test(scope) || !HASH.test(cwdHash || '')
    || typeof title !== 'string' || !title.trim() || title.length > 200 || /[\r\n\0]/.test(title)
    || path.basename(filename) !== `${hash(title)}.json`) throw fail();
  const database = filename.replace(/\.json$/, '.sqlite');
  return { database, scope, title, cwdHash, marker: JSON.stringify([FORMAT, path.basename(database), scope]) };
}
async function sourceState(filename, ctx) {
  const stat = await safeFile(filename);
  if (!stat) return { bytes: null, state: null, indexed: false };
  if (stat.size <= 300) {
    const small = await boundedFile(filename, 300);
    if (small?.toString('utf8').trim() === ctx.marker) return { bytes: small, indexed: true };
  }
  // Only the current installed format is imported. Its writer could produce at
  // most 5000 entries. This bounded legacy read is not a lifetime index quota.
  const bytes = await boundedFile(filename, 4 * 1024 * 1024);
  let legacy;
  try { legacy = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)); } catch { throw fail(); }
  const state = currentState(legacy, ctx.title, ctx.cwdHash);
  if (!object(legacy.deliveries) || Object.keys(legacy.deliveries).length > 5000) throw fail();
  const entries = Object.entries(legacy.deliveries).map(([marker, entry]) => [marker, deliveryEntry(marker, entry, state.sessionId)]);
  return { bytes, state, entries, indexed: false };
}
async function databaseFiles(database) {
  for (const suffix of ['', '-journal', '-wal', '-shm']) await safeFile(`${database}${suffix}`);
}
function checkedDatabase(database, readOnly = false) {
  const db = new DatabaseSync(database, { readOnly });
  try {
    db.exec('PRAGMA busy_timeout=0; PRAGMA trusted_schema=OFF;');
    if (!readOnly) db.exec('PRAGMA synchronous=FULL;');
    return db;
  } catch (error) { db.close(); throw error; }
}
function metadata(db, ctx) {
  const get = db.prepare('SELECT substr(value,1,2049) AS value FROM metadata WHERE key = ?');
  for (const [key, expected] of [['format', FORMAT], ['scope', ctx.scope], ['title', ctx.title], ['cwdHash', ctx.cwdHash]]) {
    if (get.get(key)?.value !== expected) throw fail();
  }
  const sourceHash = get.get('sourceHash')?.value;
  if (sourceHash !== 'absent' && !HASH.test(sourceHash || '')) throw fail();
  return sourceHash;
}
function snapshot(db, ctx, marker) {
  if (!MARKER.test(marker || '')) throw fail();
  const stateRow = db.prepare('SELECT substr(body,1,2049) AS body FROM current_state WHERE id = 1').get();
  const entryRow = db.prepare('SELECT substr(body,1,2049) AS body FROM deliveries WHERE marker = ?').get(marker);
  const state = stateRow ? currentState(parseRow(stateRow.body), ctx.title, ctx.cwdHash) : null;
  if (!state && (entryRow || db.prepare('SELECT 1 FROM deliveries LIMIT 1').get())) throw fail();
  return { state, entry: entryRow ? deliveryEntry(marker, parseRow(entryRow.body)) : undefined };
}

// Read-only APIs never import, create files, acquire a receiver lock or run CLI.
export async function readClaudeCliSnapshot(filename, title, cwdHash, marker) {
  const ctx = context(filename, title, cwdHash);
  await claudeTaskDirectorySafe(path.dirname(filename));
  const source = await sourceState(filename, ctx);
  if (!MARKER.test(marker || '')) throw fail();
  const databaseExists = await safeFile(ctx.database);
  if (!source.indexed && !databaseExists) {
    return { state: source.state, entry: source.entries?.find(([id]) => id === marker)?.[1] };
  }
  await databaseFiles(ctx.database);
  if (!databaseExists) throw fail();
  const db = checkedDatabase(ctx.database, true);
  try {
    const sourceHash = metadata(db, ctx);
    // A prepared conversion is readable only against its original source; the
    // subsequent submit can finish publication while holding the existing lock.
    if (!source.indexed && sourceHash !== (source.bytes ? hash(source.bytes) : 'absent')) throw fail();
    return snapshot(db, ctx, marker);
  }
  catch { throw fail(); }
  finally { db.close(); }
}

// Call only while holding the caller's existing per-conversation CLI lock.
export async function openClaudeCliStore(filename, title, cwdHash) {
  const ctx = context(filename, title, cwdHash);
  await claudeTaskDirectorySafe(path.dirname(filename));
  const source = await sourceState(filename, ctx);
  await databaseFiles(ctx.database);
  if (!await safeFile(ctx.database)) {
    if (source.indexed) throw fail();
    const file = await fs.open(ctx.database, 'wx', 0o600); await file.close();
  }
  const db = checkedDatabase(ctx.database);
  try {
    if (db.prepare("SELECT count(*) AS n FROM sqlite_master WHERE type='table'").get().n === 0) {
      if (source.indexed) throw fail();
      db.exec('BEGIN IMMEDIATE');
      try {
        db.exec('CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL) WITHOUT ROWID; CREATE TABLE current_state (id INTEGER PRIMARY KEY CHECK(id=1), body TEXT NOT NULL); CREATE TABLE deliveries (marker TEXT PRIMARY KEY, body TEXT NOT NULL) WITHOUT ROWID;');
        const putMeta = db.prepare('INSERT INTO metadata VALUES (?, ?)');
        for (const [key, value] of [['format', FORMAT], ['scope', ctx.scope], ['title', title], ['cwdHash', cwdHash], ['sourceHash', source.bytes ? hash(source.bytes) : 'absent']]) putMeta.run(key, value);
        if (source.state) db.prepare('INSERT INTO current_state VALUES (1, ?)').run(JSON.stringify(source.state));
        const put = db.prepare('INSERT INTO deliveries VALUES (?, ?)');
        for (const [id, entry] of source.entries || []) put.run(id, JSON.stringify(entry));
        db.exec('COMMIT');
      } catch (error) { db.exec('ROLLBACK'); throw error; }
    }
    const sourceHash = metadata(db, ctx);
    if (!source.indexed) {
      if (sourceHash !== (source.bytes ? hash(source.bytes) : 'absent')) throw fail();
      if (source.bytes) {
        const backup = `${filename}.before-indexed`, saved = await boundedFile(backup, 4 * 1024 * 1024);
        if (saved && !saved.equals(source.bytes)) throw fail();
        if (!saved) await atomicWrite(backup, source.bytes);
      }
      const latest = await boundedFile(filename, 4 * 1024 * 1024);
      if ((latest ? hash(latest) : 'absent') !== sourceHash) throw fail();
      await atomicWrite(filename, `${ctx.marker}\n`);
    }
    const identity = await safeFile(ctx.database);
    let closed = false;
    const assertOpen = () => { if (closed) throw fail(); };
    const putState = db.prepare('INSERT INTO current_state VALUES (1, ?) ON CONFLICT(id) DO UPDATE SET body=excluded.body');
    const putEntry = db.prepare('INSERT INTO deliveries VALUES (?, ?) ON CONFLICT(marker) DO UPDATE SET body=excluded.body');
    return Object.freeze({
      getSnapshot(marker) { assertOpen(); return snapshot(db, ctx, marker); },
      async save(value, marker, valueEntry) {
        const state = currentState(value, title, cwdHash), entry = deliveryEntry(marker, valueEntry);
        if (entry.sessionId !== state.sessionId) throw fail();
        assertOpen(); await claudeTaskDirectorySafe(path.dirname(filename)); await databaseFiles(ctx.database);
        const stat = await safeFile(ctx.database), header = await boundedFile(filename, 300);
        if (!stat || stat.ino !== identity.ino || stat.dev !== identity.dev || header?.toString('utf8').trim() !== ctx.marker) throw fail();
        db.exec('BEGIN IMMEDIATE');
        try {
          const existing = snapshot(db, ctx, marker).entry;
          if (existing && ['sessionId', 'inputId', 'inputHash'].some(key => existing[key] !== entry[key])) throw fail();
          putState.run(JSON.stringify(state)); putEntry.run(marker, JSON.stringify(entry)); db.exec('COMMIT');
        } catch (error) { db.exec('ROLLBACK'); throw error; }
      },
      close() { if (!closed) { closed = true; db.close(); } },
    });
  } catch { db.close(); throw fail(); }
}
