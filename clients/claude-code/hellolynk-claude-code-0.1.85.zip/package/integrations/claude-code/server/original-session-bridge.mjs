import { nativeReplyRouteLocation, rememberNativeReplyRoute, readNativeReplyRoute } from '../../../runtime/core/hellolynk-native-reply-routes.mjs';
import { INBOX_BATCH_ID, collectInboxBatch, inboxBatchNotice, pendingByTarget, pendingInboxAttempt, attemptInboxBatch } from './inbox-batch.mjs';
import { recordClaudeConversation, registeredClaudeConversationAlias, verifiedClaudeConversationAlias } from './native-conversation-directory.mjs';
import { readNativeNoticeLocale } from '../../../runtime/core/hellolynk-native-notice.mjs';
import { sendRecipient } from '../../../runtime/core/hellolynk-native-addressing-tools.cjs';

const ID = /^[A-Za-z0-9][A-Za-z0-9_.:-]{2,240}$/;
const SCOPE_HASH = /^[a-f0-9]{64}$/;
const fail = () => { throw new Error('claude_original_session_invalid'); };
const id = value => { if (typeof value !== 'string' || !ID.test(value)) fail(); return value; };
const batchId = value => { if (typeof value !== 'string' || !INBOX_BATCH_ID.test(value)) fail(); return value; };
export const claudeOriginalTarget = sessionId => `claude-original:${id(sessionId)}`;

// Called only by the local mods helper, never exposed as an MCP/model tool.
// One short notice per batch; the model reads the bodies with the claim tool.
export function createClaudeOriginalSessionBridge({ adapter, directoryOptions, readNoticeLocale = readNativeNoticeLocale }) {
  let announcedKey, registration;
  async function scope() {
    const value = await adapter.getNativeTaskScope();
    if (value?.adapterId !== 'claude-code') fail();
    return { value, ...nativeReplyRouteLocation(value) };
  }
  async function reserved(target) {
    const batches = await adapter.openInboxBatches({ target, state: 'reserved' });
    return batches.filter(batch => batch.target === target && batch.state === 'reserved');
  }
  return {
    async remember(input) {
      const s = await scope();
      let peerDelegateId = input.peerDelegateId;
      if (!input.conversationKey && Object.hasOwn(input, 'contact')) {
        // Match the existing send-by-name path. This helper runs alongside the
        // send; an ambiguous name or failed lookup only leaves no reply route.
        peerDelegateId = (await sendRecipient({ contact: input.contact }, query => adapter.listAuthorizedContacts(query))).recipientDelegateId;
        if ((await scope()).scopeHash !== s.scopeHash) return { ok: false };
      }
      await rememberNativeReplyRoute(s.value, { threadId: id(input.sessionId), clientMessageId: input.clientMessageId,
        conversationKey: input.conversationKey, peerDelegateId });
      return { ok: true };
    },
    async prepare(input) {
      const s = await scope(), sessionId = id(input.sessionId);
      const key = `${s.scopeHash}:${sessionId}`;
      if (announcedKey !== key) {
        // Discovery failures never suppress the established original receiver.
        registration = await recordClaudeConversation(s.value, input, directoryOptions).catch(() => null);
        announcedKey = key;
      }
      if ((await scope()).scopeHash !== s.scopeHash) return { status: 'account_changed' };
      if (registration?.state === 'archived') return { status: 'empty' };
      const targetId = registration?.targetConversationId || sessionId;
      // New letters to either verified alias share this live CLI's batch.
      // Once attempted it remains bound to that CLI, including across /clear.
      const originalTarget = claudeOriginalTarget(sessionId);
      const open = await reserved(originalTarget);
      // A batch whose last native submission was unknown gets one more try.
      // attempts=2 is left alone; a new letter then starts the next batch.
      let batch;
      for (const item of open) {
        if (await pendingInboxAttempt(s.value, item)) { batch = item; break; }
      }
      batch ||= open.find(item => item.attempts === 1);
      if (!batch) {
        const desktopAlias = registration?.desktopFile
          ? await verifiedClaudeConversationAlias(s.value, sessionId).catch(() => null) : null;
        // Collection interrupted before any attempt resumes in place.
        const pending = await pendingByTarget(adapter, async item => {
          if (item.targetConversationId) return [sessionId, targetId].includes(item.targetConversationId) ? originalTarget : null;
          if (item.replyToClientMessageId == null) return null;
          const origin = await readNativeReplyRoute(s.value, item);
          if (origin?.threadId === sessionId) return originalTarget;
          if (!origin || !desktopAlias) return null;
          // Only unassigned replies follow the verified Desktop across CLI rollover.
          // Existing batches remain owned by the CLI that first attempted them.
          return await registeredClaudeConversationAlias(s.value, origin.threadId).catch(() => null) === desktopAlias ? originalTarget : null;
        });
        batch = await collectInboxBatch(adapter, originalTarget, pending.get(originalTarget) || [], open.find(item => item.attempts === 0) || null);
      }
      if ((await scope()).scopeHash !== s.scopeHash) return { status: 'account_changed' };
      if (!batch) return { status: 'empty' };
      const locale = await readNoticeLocale();
      if ((await scope()).scopeHash !== s.scopeHash) return { status: 'account_changed' };
      // A batch with no deliverable letter is closed here by the Host. This
      // CLI session reads the batch, so it owns it from the first attempt.
      const tried = await attemptInboxBatch(adapter, s.value, batch, sessionId);
      if (!tried.attempted) return { status: 'empty' };
      return { status: 'reserved', sessionId: input.sessionId, scopeHash: s.scopeHash, batchId: tried.batchId,
        text: inboxBatchNotice(tried.count, tried.batchId, '来信', locale) };
    },
    async closed(input) {
      const s = await scope();
      await recordClaudeConversation(s.value, { sessionId: id(input.sessionId), closed: true }, directoryOptions);
      return { ok: true };
    },
    // The host accepted the notice: delivered. Never waits for the model.
    async confirm(input) {
      if (typeof input.scopeHash !== 'string' || !SCOPE_HASH.test(input.scopeHash)) fail();
      const s = await scope();
      if (input.scopeHash !== s.scopeHash) return { status: 'account_changed' };
      await adapter.confirmInboxBatch(batchId(input.batchId));
      return { status: 'delivered' };
    },
    // Only before submission or after an explicit native drop. The Host keeps
    // a retried batch: its unsent retry cannot disprove the first try.
    async cancel(input) {
      const result = await adapter.cancelInboxBatch(batchId(input.batchId));
      return { status: result.cancelled ? 'cancelled' : 'kept' };
    },
  };
}

export async function runClaudeOriginalSessionHelper({ adapter, input = process.stdin, output = process.stdout, waitMs = 40000, pollMs = 3000,
  readNoticeLocale = readNativeNoticeLocale }) {
  let data = '';
  for await (const chunk of input) { data += chunk; if (Buffer.byteLength(data) > 32768) fail(); }
  const request = JSON.parse(data);
  const bridge = createClaudeOriginalSessionBridge({ adapter, readNoticeLocale });
  if (!['remember', 'prepare', 'confirm', 'cancel', 'closed'].includes(request.action)) fail();
  let result;
  const deadline = Date.now() + waitMs;
  do {
    result = await bridge[request.action](request);
    // The waiting process reserves the batch using its existing connection;
    // the mod cancels it if its session changed before native submission.
    if (request.action !== 'prepare' || result.status !== 'empty' || Date.now() >= deadline) break;
    await new Promise(resolve => setTimeout(resolve, Math.min(pollMs, deadline - Date.now())));
  } while (Date.now() <= deadline);
  output.write(`${JSON.stringify(result)}\n`);
  return result;
}
