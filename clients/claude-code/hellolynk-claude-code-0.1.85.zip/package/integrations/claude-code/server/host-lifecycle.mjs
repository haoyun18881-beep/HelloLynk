import { launchPinnedNeutralHost, verifyPinnedNeutralHostRuntime } from "../../../runtime/core/hellolynk-neutral-host-launcher.mjs";

function check(binding) {
  if (binding?.adapterId !== "claude-code") throw Object.assign(new Error("neutral_claude_code_binding_invalid"), { code: "neutral_claude_code_binding_invalid" });
}
export async function verifyPinnedBootstrap(binding, options = {}) {
  check(binding);
  return verifyPinnedNeutralHostRuntime(binding, options);
}
export async function launchClaudeCodeNeutralHost(binding, options = {}) {
  check(binding);
  return launchPinnedNeutralHost(binding, options);
}
