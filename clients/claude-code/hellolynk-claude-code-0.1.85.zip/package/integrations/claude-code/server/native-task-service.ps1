param(
  [Parameter(Mandatory=$true)][ValidateSet('Install','Verify','Start','Stop','Uninstall')][string]$Command,
  [Parameter(Mandatory=$true)][string]$Root,
  [Parameter(Mandatory=$true)][ValidatePattern('^[a-f0-9]{64}$')][string]$Manifest,
  [Parameter(Mandatory=$true)][string]$NodePath,
  [Parameter(Mandatory=$true)][string]$StoreRoot,
  [ValidateSet('yes','no')][string]$StartAtLogon = 'no',
  [string]$DriverRoot = ''
)
$ErrorActionPreference = 'Stop'
try {
  if (-not $DriverRoot) { $DriverRoot = $Root }
  # A newer verified release may withdraw an older release's task, including one
  # whose recorded node.exe is gone. Only Stop/Uninstall run through another driver.
  $withdrawing = $Command -eq 'Stop' -or $Command -eq 'Uninstall'
  if ($DriverRoot -ne $Root -and -not $withdrawing) { throw 'claude_native_service_path_invalid' }
  foreach ($value in @($Root,$NodePath,$StoreRoot,$DriverRoot)) {
    if (-not [IO.Path]::IsPathRooted($value) -or $value -match '["\r\n]' -or [IO.Path]::GetFullPath($value) -ne $value) { throw 'claude_native_service_path_invalid' }
  }
  if ([IO.Path]::GetFileName($StoreRoot) -ne 'host' -or [IO.Path]::GetFileName($NodePath) -ne 'node.exe') { throw 'claude_native_service_path_invalid' }
  $entry = Join-Path $Root 'integrations\claude-code\server\package-bootstrap.mjs'
  $script = Join-Path $DriverRoot 'integrations\claude-code\server\native-task-service.ps1'
  $launcher = Join-Path $Root 'integrations\claude-code\server\native-task-hidden-launcher.vbs'
  $wscript = Join-Path $env:SystemRoot 'System32\wscript.exe'
  $required = @($entry,$launcher,$wscript); if (-not $withdrawing) { $required += $NodePath }
  foreach ($file in $required) { if (-not (Test-Path -LiteralPath $file -PathType Leaf)) { throw 'claude_native_service_entry_invalid' } }
  if ([IO.Path]::GetFullPath($PSCommandPath) -ne $script) { throw 'claude_native_service_entry_invalid' }
  $sid = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
  $hash = [Security.Cryptography.SHA256]::Create()
  try {
    $suffix = ([BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($sid + '|' + $StoreRoot.ToLowerInvariant())))).Replace('-','').Substring(0,20)
    $releaseSuffix = ([BitConverter]::ToString($hash.ComputeHash([Text.Encoding]::UTF8.GetBytes($Root.ToLowerInvariant() + '|' + $Manifest)))).Replace('-','').Substring(0,16)
  } finally { $hash.Dispose() }
  $taskName = "HelloLynk Claude Native - $suffix - $releaseSuffix"
  $description = 'HelloLynk Claude Code native inbox receiver; explicitly enabled; no model polling.'
  $arguments = '//B //NoLogo "{0}" "{1}" "{2}" "{3}" {4} "{5}"' -f $launcher,$NodePath,$entry,$Root,$Manifest,$StoreRoot
  # Talk to the Scheduler directly. The ScheduledTasks cmdlets add a CIM
  # provider round trip which can stall even when this exact task is healthy.
  $scheduler = New-Object -ComObject 'Schedule.Service'
  $scheduler.Connect()
  $folder = $scheduler.GetFolder('\')
  $task = $null
  try { $task = $folder.GetTask($taskName) }
  catch { if ($_.Exception.HResult -ne -2147024894) { throw } }
  if ($task) {
    $definition = $task.Definition
    $taskSid = [string]$definition.Principal.UserId
    if ($taskSid -notmatch '^S-1-') { $taskSid = (New-Object Security.Principal.NTAccount($taskSid)).Translate([Security.Principal.SecurityIdentifier]).Value }
    $triggers = @($definition.Triggers | Where-Object { $null -ne $_ })
    $triggerValid = $triggers.Count -eq 0
    if ($StartAtLogon -eq 'yes') {
      $triggerSid = ''
      if ($triggers.Count -eq 1) {
        $triggerSid = [string]$triggers[0].UserId
        if ($triggerSid -and $triggerSid -notmatch '^S-1-') { $triggerSid = (New-Object Security.Principal.NTAccount($triggerSid)).Translate([Security.Principal.SecurityIdentifier]).Value }
      }
      $triggerValid = $triggers.Count -eq 1 -and $triggers[0].Type -eq 9 -and $triggerSid -eq $sid -and $triggers[0].Enabled
    }
    if ($definition.RegistrationInfo.Description -ne $description -or $taskSid -ne $sid -or $definition.Actions.Count -ne 1 -or
      $definition.Actions.Item(1).Type -ne 0 -or $definition.Actions.Item(1).Path -ne $wscript -or $definition.Actions.Item(1).Arguments -ne $arguments -or $definition.Actions.Item(1).WorkingDirectory -ne $Root -or
      $definition.Principal.RunLevel -ne 0 -or $definition.Principal.LogonType -ne 3 -or
      $definition.Settings.MultipleInstances -ne 2 -or $definition.Settings.ExecutionTimeLimit -ne 'PT0S' -or ($Command -ne 'Stop' -and $Command -ne 'Uninstall' -and -not $definition.Settings.AllowDemandStart) -or -not $triggerValid) { throw 'claude_native_service_task_conflict' }
  }
  function Stop-OwnedProcesses {
    # Withdrawn receivers normally exit on their local enablement check. If one
    # is stuck, stop its own workers without killing a shared Host it launched.
    $tail = '"{0}" receive --root "{1}" --expected-manifest-sha256 {2}' -f $entry,$StoreRoot,$Manifest
    $nodePattern = '^(?:"' + [regex]::Escape($NodePath) + '"|' + [regex]::Escape($NodePath) + ')[ \t]+' + [regex]::Escape($tail) + '$'
    $helperPattern = '^(?:"' + [regex]::Escape($wscript) + '"|' + [regex]::Escape($wscript) + ')[ \t]+' + [regex]::Escape($arguments) + '$'
    foreach ($observed in @(Get-CimInstance Win32_Process -Filter "Name = 'node.exe' OR Name = 'wscript.exe'")) {
      if (-not (($observed.ExecutablePath -eq $NodePath -and ([string]$observed.CommandLine).Trim() -match $nodePattern) -or ($observed.ExecutablePath -eq $wscript -and ([string]$observed.CommandLine).Trim() -match $helperPattern))) { continue }
      $process = $null
      try {
        $process = Get-Process -Id $observed.ProcessId -ErrorAction SilentlyContinue
        if (-not $process) { continue }
        $openedHandle = $process.Handle
        $current = Get-CimInstance Win32_Process -Filter "ProcessId = $($observed.ProcessId)"
        if (-not $current -or $current.CreationDate -ne $observed.CreationDate -or $current.CommandLine -ne $observed.CommandLine -or $current.ExecutablePath -ne $observed.ExecutablePath) { continue }
        try { if ((Invoke-CimMethod -InputObject $current -MethodName GetOwnerSid).Sid -ne $sid) { continue } }
        catch { if ($process.HasExited) { continue }; throw }
        if ($process.WaitForExit(1500)) { continue }
        $snapshot = @(Get-CimInstance Win32_Process)
        $owned = [Collections.Generic.List[object]]::new()
        $owned.Add($current)
        for ($index = 0; $index -lt $owned.Count; $index += 1) {
          $parent = $owned[$index]
          foreach ($child in $snapshot) {
            if ($child.ParentProcessId -ne $parent.ProcessId -or $child.CreationDate -lt $parent.CreationDate) { continue }
            # The shared Host has a separate lifetime, including its children.
            if ($child.Name -eq 'node.exe' -and $child.CommandLine -match '[\\/]neutral-host-bootstrap\.mjs"?[ \t]+run[ \t]+--root[ \t]+') { continue }
            $owned.Add($child)
          }
        }
        # Stop parents first so a stuck receiver cannot replace a worker while
        # the captured descendants are being stopped.
        for ($index = 0; $index -lt $owned.Count; $index += 1) {
          $member = $owned[$index]; $handle = $null
          try {
            $handle = Get-Process -Id $member.ProcessId -ErrorAction SilentlyContinue
            if (-not $handle) { continue }
            $null = $handle.Handle
            $live = Get-CimInstance Win32_Process -Filter "ProcessId = $($member.ProcessId)"
            if (-not $live -or $live.CreationDate -ne $member.CreationDate -or $live.CommandLine -ne $member.CommandLine -or $live.ExecutablePath -ne $member.ExecutablePath) { continue }
            if ((Invoke-CimMethod -InputObject $live -MethodName GetOwnerSid).Sid -ne $sid) { continue }
            if (-not $handle.HasExited) { $handle.Kill() }
          } catch { if (-not $handle -or -not $handle.HasExited) { throw } }
          finally { if ($handle) { $handle.Dispose() } }
        }
        if (-not $process.WaitForExit(5000)) { throw 'claude_native_service_stop_timeout' }
      } finally { if ($process) { $process.Dispose() } }
    }
  }
  if ($Command -eq 'Install') {
    if (-not $task) {
      $definition = $scheduler.NewTask(0)
      $definition.RegistrationInfo.Description = $description
      $definition.Principal.UserId = $sid; $definition.Principal.LogonType = 3; $definition.Principal.RunLevel = 0
      $definition.Settings.MultipleInstances = 2; $definition.Settings.ExecutionTimeLimit = 'PT0S'; $definition.Settings.AllowDemandStart = $true
      $definition.Settings.DisallowStartIfOnBatteries = $false; $definition.Settings.StopIfGoingOnBatteries = $false
      $action = $definition.Actions.Create(0)
      $action.Path = $wscript; $action.Arguments = $arguments; $action.WorkingDirectory = $Root
      if ($StartAtLogon -eq 'yes') { $trigger = $definition.Triggers.Create(9); $trigger.UserId = $sid; $trigger.Enabled = $true }
      $null = $folder.RegisterTaskDefinition($taskName, $definition, 2, $sid, $null, 3)
    }
  } elseif ($Command -eq 'Stop' -or $Command -eq 'Uninstall') {
    if ($task) {
      # Disable the trigger before process cleanup; explicit Start reenables it.
      $task.Enabled = $false
      Stop-OwnedProcesses
      # Scheduler tree termination would also stop the shared Host. The exact
      # receiver/helper processes above own this task's lifetime instead.
      if ($Command -eq 'Uninstall') { $folder.DeleteTask($taskName, 0) }
    }
  } else {
    if (-not $task) { throw 'claude_native_service_task_missing' }
    if ($Command -eq 'Start') {
      $task.Enabled = $true
      if ($task.State -ne 4) { $null = $task.Run($null) }
    }
  }
  [pscustomobject]@{ok=$true;operation=$Command;taskName=$taskName} | ConvertTo-Json -Compress
} catch {
  $code = [string]$_.Exception.Message
  if ($code -notmatch '^claude_native_service_[a-z_]+$') { $code = 'claude_native_service_task_failed' }
  [Console]::Error.WriteLine($code); exit 1
}
