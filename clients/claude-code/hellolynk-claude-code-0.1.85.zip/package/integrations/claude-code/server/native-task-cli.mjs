import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { claudeTaskDirectorySafe as directorySafe, readClaudeCliSnapshot, openClaudeCliStore } from './native-task-cli-store.mjs';

const ID = /^[A-Za-z0-9][A-Za-z0-9_.:-]{2,198}$/;
const MARKER = /^hellolynk-[a-f0-9]{64}$/;
const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/;
const ZERO_MARKER = `hellolynk-${'0'.repeat(64)}`;
// A resident CLI with nothing queued exits after IDLE_MS; the next batch
// resumes the same session. After the CLI could not reach the model (for
// example it is logged out) nothing is submitted for API_RETRY_MS.
const IDLE_MS = 10 * 60_000, API_RETRY_MS = 60_000, EXIT_WAIT_MS = 5_000;
// A lock names the receiver process holding it. The nonce lets a restarted
// receiver that was given its predecessor's PID tell that lock from its own.
const PROCESS_NONCE = crypto.randomUUID();
// These existing Host tools enforce message/contact authorization themselves.
// Do not grant generic execution/write tools or open human workbench UI here.
const AUTHORIZED_TOOLS = ['reply_authorized_message', 'list_pending_messages', 'claim_message',
  'host_status', 'get_unread_count', 'list_authorized_contacts', 'send_authorized_message',
  'list_authorized_inbox_messages', 'read_authorized_inbox_message', 'list_authorized_contact_requests',
  'read_authorized_contact_request'].map(name => `mcp__hellolynk__hellolynk_${name}`);
const digest = value => crypto.createHash('sha256').update(value).digest('hex');
const fail = code => Object.assign(new Error(code), { code });
const validTitle = title => typeof title === 'string' && title.trim() && title.length <= 200 && !/[\r\n\0]/.test(title);
const validMs = (value, max) => Number.isSafeInteger(value) && value >= 1 && value <= max;
const validPid = pid => Number.isSafeInteger(pid) && pid > 0;
// Signal 0 only probes. A process this one may not inspect counts as alive.
const alive = pid => { try { process.kill(pid, 0); return true; } catch (error) { return error.code !== 'ESRCH'; } };
// The model never ran: the CLI could not call the API (logged out, offline).
const unreachable = event => event.is_error === true && (event.terminal_reason === 'api_error'
  || event.api_error_status != null || event.api_error_code != null || event.api_error != null);

// This facade intentionally proves receipt, not business completion. Receipt
// confirms the Host inbox batch as delivered; the model never marks a finish.
// Evidence is local metadata; prompts, output, stderr and credentials are never
// copied here. Claude itself retains its normal resumable conversation history.
// One CLI process stays resident per session: later batches are written to its
// stdin even while it runs, and the CLI folds them into the current turn.
export function createClaudeNativeTaskCli({ scope, cliPath, workingDirectory, mcpServer,
  spawnImpl = spawn, readSessionState, maxFrameBytes = 1024 * 1024, closeTimeoutMs = 2000,
  idleMs = IDLE_MS, apiRetryMs = API_RETRY_MS, now = Date.now } = {}) {
  if (!scope || scope.adapterId !== 'claude-code' || !path.isAbsolute(scope.runtimeRoot || '')
    || !['cn', 'intl', 'china', 'international'].includes(scope.region) || [scope.principalId, scope.delegateId].some(v => !ID.test(v || '')))
    throw fail('claude_native_cli_scope_invalid');
  if (!path.isAbsolute(cliPath || '') || !path.isAbsolute(workingDirectory || '')
    || !mcpServer || Object.keys(mcpServer).some(k => !['type', 'command', 'args'].includes(k))
    || mcpServer.type != null && mcpServer.type !== 'stdio'
    || typeof mcpServer.command !== 'string' || !mcpServer.command.trim() || /[\r\n\0]/.test(mcpServer.command)
    || !Array.isArray(mcpServer.args) || mcpServer.args.length > 64
    || mcpServer.args.some(v => typeof v !== 'string' || v.length > 8192 || /[\r\n\0]/.test(v))
    || !Number.isSafeInteger(maxFrameBytes) || maxFrameBytes < 1024 || maxFrameBytes > 4 * 1024 * 1024
    || !validMs(closeTimeoutMs, 10000) || !validMs(idleMs, 3_600_000) || !validMs(apiRetryMs, 3_600_000) || typeof now !== 'function')
    throw fail('claude_native_cli_options_invalid');
  const root = path.join(path.resolve(scope.runtimeRoot), 'native-tasks-cli', digest(JSON.stringify([
    scope.adapterId, scope.region, scope.principalId, scope.delegateId,
  ])));
  const cwd = path.resolve(workingDirectory), cwdHash = digest(cwd);
  const inspectSession = readSessionState || createClaudeSessionStateReader(cwd);
  const mcpConfig = JSON.stringify({ mcpServers: { hellolynk: { type: 'stdio', command: mcpServer.command, args: [...mcpServer.args] } } });
  const runners = new Map();
  let closed = false, apiRetryAt = 0;
  const filenameFor = title => path.join(root, `${digest(title)}.json`);
  function validate({ title, marker, text }, prompt = false) {
    if (!validTitle(title) || !MARKER.test(marker || '') || prompt && (typeof text !== 'string'
      || !text || Buffer.byteLength(text) > 16 * 1024)) throw fail('claude_native_cli_prompt_invalid');
  }
  const load = (title, marker) => readClaudeCliSnapshot(filenameFor(title), title, cwdHash, marker);
  const newEntry = (state, text) => ({ sessionId: state.sessionId, inputId: crypto.randomUUID(), inputHash: digest(text),
    accepted: false, result: false, definitelyNotSubmitted: false, status: 'unknown' });
  const busy = title => ({ submissionAttempted: false, nativeTaskTitle: title, errorCode: 'claude_native_cli_busy' });
  const lockBody = childPid => JSON.stringify({ pid: process.pid, nonce: PROCESS_NONCE, ...(validPid(childPid) ? { childPid } : {}) });
  // A receiver that no longer runs owns no session, unless the CLI it spawned
  // is still finishing a turn: two processes must never resume one session.
  // An unreadable lock stays fenced.
  async function lockOwnerAlive(lockname) {
    let lock;
    try { lock = JSON.parse(await fs.readFile(lockname, 'utf8')); } catch (error) { return error.code !== 'ENOENT'; }
    if (!validPid(lock?.pid)) return true;
    const receiver = lock.pid === process.pid ? lock.nonce === PROCESS_NONCE : alive(lock.pid);
    return receiver || validPid(lock.childPid) && alive(lock.childPid);
  }
  async function acquireLock(lockname) {
    for (let attempt = 0; attempt < 2; attempt += 1) {
      let lock;
      try { lock = await fs.open(lockname, 'wx', 0o600); }
      catch (error) {
        if (error.code !== 'EEXIST') throw fail('claude_native_cli_state_unavailable');
        if (attempt > 0 || await lockOwnerAlive(lockname)) return null;
        await fs.unlink(lockname).catch(() => {});
        continue;
      }
      try { await lock.writeFile(lockBody(), 'utf8'); return lock; }
      catch { await lock.close().catch(() => {}); throw fail('claude_native_cli_state_unavailable'); }
    }
    return null;
  }
  // replacesSession: the history is missing; this is not proof of human action.
  async function replacedSession(state) {
    if (!state?.sessionStarted) return false;
    const lifecycle = await inspectSession(state.sessionId);
    if (lifecycle === 'deleted' || lifecycle === 'archived') return true;
    if (lifecycle !== 'present') throw fail('claude_native_cli_session_unavailable');
    return false;
  }
  async function statusFor({ title, marker }) {
    validate({ title, marker });
    await runners.get(title)?.writes;
    const { entry } = await load(title, marker);
    const status = { confirmed: entry?.accepted === true || entry?.result === true, nativeTaskTitle: title,
      nativeSessionId: entry?.sessionId ?? null,
      definitelyNotSubmitted: entry?.definitelyNotSubmitted === true,
      status: entry?.status || 'not_submitted', ...(entry?.errorCode ? { errorCode: entry.errorCode } : {}) };
    // A try whose receiver died before the CLI answered: no process tracks it
    // any more, so it would stay unknown for ever. Reported failed, the Host
    // spends the batch's one retry on it; the stored record keeps its evidence.
    const runner = runners.get(title);
    if (status.status === 'unknown' && (runner ? !runner.tracks(entry.inputId) : !(await lockOwnerAlive(`${filenameFor(title)}.lock`))))
      return { ...status, status: 'failed', errorCode: 'claude_native_cli_owner_lost' };
    return status;
  }
  async function start(title, marker, text, pin) {
    await directorySafe(root, true);
    const filename = filenameFor(title), lockname = `${filename}.lock`;
    const lock = await acquireLock(lockname);
    if (!lock) return busy(title);
    let transferred = false, store;
    const release = async () => { store?.close(); await lock.close(); await fs.unlink(lockname); };
    try {
      store = await openClaudeCliStore(filename, title, cwdHash);
      let { state, entry: existing } = store.getSnapshot(marker);
      if (existing) return { submissionAttempted: true, nativeTaskTitle: title };
      if (await replacedSession(state)) {
        state.sessionId = crypto.randomUUID(); state.sessionStarted = false; state.phase = 'idle';
      }
      const resume = state?.sessionStarted === true;
      state ||= { version: 1, title, cwdHash, sessionId: crypto.randomUUID(), sessionStarted: false, phase: 'idle' };
      const entry = newEntry(state, text);
      const writeState = () => store.save(state, marker, entry);
      state.phase = 'active';
      state.sessionStarted = true;
      // Durable unknown MUST precede any spawn, even one which throws. A
      // process crash leaves the lock/state untouched for a live receiver:
      // no speculative resume and no automatic retransmission.
      await writeState();
      if (closed) {
        state.phase = 'idle'; state.sessionStarted = resume; entry.definitelyNotSubmitted = true; entry.status = 'cancelled'; entry.errorCode = 'claude_native_cli_cancelled';
        await writeState();
        return { submissionAttempted: true, nativeTaskTitle: title };
      }
      // The Host learns which UUID reads this batch before any process can.
      if (pin) try { await pin(state.sessionId); }
      catch {
        state.phase = 'idle'; state.sessionStarted = resume; entry.definitelyNotSubmitted = true; entry.status = 'failed'; entry.errorCode = 'claude_native_cli_pin_failed';
        await writeState();
        return { submissionAttempted: true, nativeTaskTitle: title };
      }
      // Resume the same conversation, but load current MCP definitions. The CLI
      // persists both deferred schemas and upfront tool snapshots; disabling only
      // one cache can still expose an obsolete contract after a later upgrade.
      // Keep both disabled throughout this UUID's lifetime. Launch settings also
      // override ordinary user/project env settings; managed policy still wins.
      const args = ['--print', '--input-format', 'stream-json', '--output-format', 'stream-json', '--verbose', '--system-prompt-snapshot', 'off',
        '--settings', JSON.stringify({ env: { ENABLE_TOOL_SEARCH: 'false' } }),
        '--replay-user-messages', '--permission-prompts', 'none', '--allowedTools', AUTHORIZED_TOOLS.join(','), '--mcp-config', mcpConfig,
        resume ? '--resume' : '--session-id', state.sessionId];
      let child;
      try { child = spawnImpl(cliPath, args, { cwd, windowsHide: true, shell: false, detached: false,
        env: { ...process.env, ENABLE_TOOL_SEARCH: 'false', HELLOLYNK_NATIVE_BACKGROUND: '1', HELLOLYNK_NATIVE_BACKGROUND_SESSION_ID: state.sessionId }, stdio: ['pipe', 'pipe', 'ignore'] }); }
      catch {
        state.phase = 'idle'; state.sessionStarted = resume; entry.definitelyNotSubmitted = true; entry.status = 'failed'; entry.errorCode = 'claude_native_cli_spawn_failed';
        await writeState();
        return { submissionAttempted: true, nativeTaskTitle: title };
      }
      runners.set(title, resident({ title, child, store, state, lock, lockname, release, resume, first: { marker, entry, text } }));
      transferred = true;
      return { submissionAttempted: true, nativeTaskTitle: title };
    } finally { if (!transferred) await release(); }
  }
  function resident({ title, child, store, state, lock, lockname, release, resume, first }) {
    let resolveFinished;
    const runner = { child, writes: Promise.resolve(), closing: false, finished: new Promise(resolve => { resolveFinished = resolve; }) };
    const inputs = new Map();
    let last = first, stopped = false, ended = false, sawResult = false, buffer = '', fatalCode, idleTimer, exitTimer;
    runner.active = () => !runner.closing && !stopped && !ended;
    const kill = () => { try { child.kill(); } catch { /* Own child only; unknown remains fenced. */ } };
    const queue = operation => {
      runner.writes = runner.writes.then(operation).catch(() => { fatalCode = 'claude_native_cli_state_unavailable'; stopped = true; kill(); });
    };
    const persist = (input, change) => queue(async () => { change(input.entry); await store.save(state, input.marker, input.entry); });
    const accept = input => {
      if (input.accepted) return;
      input.accepted = true;
      persist(input, entry => { entry.accepted = true; if (entry.status === 'unknown') entry.status = 'accepted'; });
    };
    const settle = (input, change) => { inputs.delete(input.entry.inputId); persist(input, change); };
    const abort = code => {
      if (stopped || ended) return;
      fatalCode = code; stopped = true; buffer = ''; kill();
      queue(async () => {
        state.phase = 'blocked';
        for (const input of inputs.values()) {
          input.entry.status = code === 'claude_native_cli_cancelled' ? 'cancelled' : 'failed'; input.entry.errorCode = code;
          await store.save(state, input.marker, input.entry);
        }
        if (!inputs.size) await store.save(state, last.marker, last.entry);
      });
    };
    const recycle = () => {
      if (!runner.active()) return;
      runner.closing = true; clearTimeout(idleTimer);
      // An idle CLI ends at stdin EOF; one that lingers is killed.
      try { child.stdin.end(); } catch { kill(); }
      exitTimer = setTimeout(kill, EXIT_WAIT_MS); exitTimer.unref?.();
    };
    const armIdle = () => { clearTimeout(idleTimer); idleTimer = setTimeout(recycle, idleMs); idleTimer.unref?.(); };
    const write = (marker, entry, text) => {
      const input = { marker, entry, written: false, echoed: false, accepted: false };
      inputs.set(entry.inputId, input); last = input;
      clearTimeout(idleTimer);
      try {
        child.stdin.write(`${JSON.stringify({ type: 'user', session_id: state.sessionId, uuid: entry.inputId,
          parent_tool_use_id: null, message: { role: 'user', content: text } })}\n`, 'utf8');
        input.written = true;
      } catch { abort('claude_native_cli_input_unknown'); }
    };
    // Later batches join the running process. The durable unknown precedes the
    // stdin write, in the same order as the first batch precedes its spawn.
    runner.enqueue = (marker, text, pin) => new Promise((resolve, reject) => queue(async () => {
      try {
        if (!runner.active()) { resolve(null); return; }
        if (store.getSnapshot(marker).entry) { resolve({ submissionAttempted: true, nativeTaskTitle: title }); return; }
        const entry = newEntry(state, text);
        await store.save(state, marker, entry);
        if (!runner.active()) {
          // The process went away while the record was written: proven
          // unsubmitted, so the Host returns the letters at once.
          entry.definitelyNotSubmitted = true; entry.status = 'cancelled'; entry.errorCode = 'claude_native_cli_cancelled';
          await store.save(state, marker, entry);
          resolve(null); return;
        }
        if (pin) try { await pin(state.sessionId); }
        catch {
          // Unpinned, the prompt is never written: the Host returns the letters.
          entry.definitelyNotSubmitted = true; entry.status = 'failed'; entry.errorCode = 'claude_native_cli_pin_failed';
          await store.save(state, marker, entry);
          resolve(null); return;
        }
        write(marker, entry, text);
        resolve({ submissionAttempted: true, nativeTaskTitle: title });
      } catch (error) { reject(fail('claude_native_cli_state_unavailable')); throw error; }
    }));
    runner.cancel = () => abort('claude_native_cli_cancelled');
    runner.tracks = inputId => inputs.has(inputId);
    // The human may delete the session while its process idles. Checked only
    // between turns, once a result proves the transcript existed.
    runner.replaced = () => sawResult && !inputs.size ? replacedSession(state) : Promise.resolve(false);
    runner.retire = recycle;
    function frame(line) {
      if (stopped || ended || !line.trim()) return;
      let event;
      try { event = JSON.parse(line); } catch { abort('claude_native_cli_frame_invalid'); return; }
      if (!event || typeof event !== 'object' || Array.isArray(event)) { abort('claude_native_cli_frame_invalid'); return; }
      // Init, hook output, other sessions and subagent tool data cannot
      // establish receipt of a particular input.
      if (event.session_id !== state.sessionId || event.parent_tool_use_id != null) return;
      if (event.type === 'user') {
        // The CLI replays an input once it folds it into the conversation. A
        // logged-out CLI replays too, so the echo alone proves nothing.
        const input = inputs.get(event.uuid);
        if (input) input.echoed = true;
        return;
      }
      if (event.type === 'assistant') {
        // A model frame proves the model ran with every input replayed before
        // it. One carrying an API error proves the model never ran.
        if (event.error != null || event.is_api_error_message === true) return;
        for (const input of inputs.values()) if (input.echoed || input.entry.inputId === event.user_message_uuid) accept(input);
        return;
      }
      if (event.type !== 'result') return;
      sawResult = true;
      if (unreachable(event)) {
        // The model never ran this call: nothing unaccepted was processed, and
        // nothing queued can run. The Host keeps those letters; this process
        // ends, and a fresh one starts once the retry window passes.
        for (const input of inputs.values()) settle(input, entry => {
          entry.status = 'failed'; entry.errorCode = 'claude_native_cli_api_error';
          if (!input.accepted) entry.definitelyNotSubmitted = true;
        });
        apiRetryAt = now() + apiRetryMs;
        runner.closing = true; clearTimeout(idleTimer); kill();
        return;
      }
      // A result names every input its turn consumed, including ones folded
      // in while it ran. Unnamed, it still closes the inputs the model has
      // answered: those belong to this turn.
      const named = Array.isArray(event.user_message_uuids) ? event.user_message_uuids : null;
      const turn = named ? named.map(id => inputs.get(id)).filter(Boolean) : [...inputs.values()].filter(input => input.accepted);
      const succeeded = event.subtype === 'success' && event.is_error === false && Number.isSafeInteger(event.num_turns) && event.num_turns >= 1;
      for (const input of turn) {
        if (succeeded) { accept(input); settle(input, entry => { entry.result = true; entry.status = 'completed'; }); }
        else settle(input, entry => { entry.status = 'failed'; entry.errorCode = 'claude_native_cli_result_failed'; });
      }
      if (!inputs.size) armIdle();
    }
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', part => {
      if (stopped || ended) return;
      // Limit each NDJSON frame before concatenation, rather than retaining
      // a whole transcript or accepting an unbounded unterminated line.
      let offset = 0;
      for (;;) {
        const end = part.indexOf('\n', offset), fragment = part.slice(offset, end < 0 ? undefined : end);
        if (Buffer.byteLength(buffer) + Buffer.byteLength(fragment) > maxFrameBytes) { abort('claude_native_cli_frame_too_large'); return; }
        buffer += fragment;
        if (end < 0) return;
        frame(buffer); buffer = '';
        if (stopped) return;
        offset = end + 1;
      }
    });
    const finish = (code, signal) => {
      if (ended) return;
      if (buffer && !stopped) frame(buffer);
      ended = true; clearTimeout(idleTimer); clearTimeout(exitTimer);
      queue(async () => {
        // Our process has exited, so no orphan can resume this session. Inputs
        // it never answered are failed, not received; one never written is
        // proven unsubmitted. Whether the Host retries is the batch's call.
        state.phase = 'idle';
        const spawnFailed = fatalCode === 'claude_native_cli_spawn_failed' && !child.pid;
        if (spawnFailed) state.sessionStarted = resume;
        for (const input of inputs.values()) {
          input.entry.status = fatalCode === 'claude_native_cli_cancelled' ? 'cancelled' : 'failed';
          input.entry.errorCode = fatalCode || 'claude_native_cli_exit_unknown';
          if (!input.written || spawnFailed) input.entry.definitelyNotSubmitted = true;
          await store.save(state, input.marker, input.entry);
        }
        if (!inputs.size) await store.save(state, last.marker, last.entry);
        inputs.clear();
      });
      // Releasing the lock and forgetting the runner end the write chain, so
      // close() and status reads observe them. Failed durable writes keep the
      // lock as an additional fail-closed fence; a foreign lock is never removed.
      runner.writes = runner.writes.finally(async () => {
        if (fatalCode === 'claude_native_cli_state_unavailable') {
          store.close(); await lock.close().catch(() => {});
        }
        else await release().catch(() => {});
        runners.delete(title); resolveFinished();
      });
    };
    child.on('error', () => { abort('claude_native_cli_spawn_failed'); if (!child.pid) finish(null, null); });
    child.on('close', finish);
    child.stdin.on('error', () => abort('claude_native_cli_input_unknown'));
    // Name the child in the lock: a crashed receiver's CLI may still be
    // finishing a turn. Written inside the chain, so release always follows.
    if (validPid(child.pid)) queue(() => fs.writeFile(lockname, lockBody(child.pid), 'utf8').catch(() => {}));
    write(first.marker, first.entry, first.text);
    return runner;
  }
  return Object.freeze({
    async ownsSession({ title, threadId }) {
      if (!validTitle(title) || !UUID.test(threadId || '')) return false;
      const state = (await load(title, ZERO_MARKER)).state;
      return state?.sessionId === threadId && state.sessionStarted === true;
    },
    // ready=false while this process is exiting, another live receiver holds
    // the session, the model is known unreachable, or the session cannot be
    // read. A resident process takes the next batch at once, busy or not; an
    // idle one whose session history is missing ends, and the next tick starts
    // the replacement.
    async ready({ title }) {
      if (closed || !validTitle(title)) return { ready: false };
      const runner = runners.get(title);
      try {
        if (runner) {
          if (!runner.active()) return { ready: false };
          if (!(await runner.replaced())) return { ready: true, replacesSession: false };
          runner.retire();
          return { ready: false };
        }
        if (now() < apiRetryAt || await lockOwnerAlive(`${filenameFor(title)}.lock`)) return { ready: false };
        return { ready: true, replacesSession: await replacedSession((await load(title, ZERO_MARKER)).state) };
      } catch { return { ready: false }; }
    },
    async submit(params) {
      validate(params, true);
      if (closed) throw fail('claude_native_cli_closed');
      const { title, marker, text, pin } = params;
      if (pin != null && typeof pin !== 'function') throw fail('claude_native_cli_prompt_invalid');
      const runner = runners.get(title);
      if (!runner) return now() < apiRetryAt ? busy(title) : start(title, marker, text, pin);
      // An exiting process proves nothing started: the Host returns the
      // letters and the next tick starts a fresh process.
      return (runner.active() && await runner.enqueue(marker, text, pin)) || busy(title);
    },
    confirm: statusFor,
    getStatus: statusFor,
    async close() {
      closed = true;
      const active = [...runners.values()];
      for (const runner of active) runner.cancel();
      let timer;
      await Promise.race([Promise.all(active.map(runner => runner.finished)), new Promise(resolve => { timer = setTimeout(resolve, closeTimeoutMs); })]);
      clearTimeout(timer);
      await Promise.all(active.map(runner => runner.writes));
      if (active.some(runner => [...runners.values()].includes(runner))) throw fail('claude_native_cli_stop_unconfirmed');
    },
  });
}

export function createClaudeSessionStateReader(workingDirectory, { configDirectory = process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude'),
  projectDirectoryName = process.env.CLAUDE_CONFIG_DIR ? process.env.CLAUDE_CODE_PROJECT_DIR_NAME : undefined, missingProjectState = 'deleted' } = {}) {
  // Current CLI 2.1.281 uses this project path encoding. Only stat the exact
  // owned UUID; no transcript body or other user's session is read. Missing
  // configuration is unavailable. The owned background session can recover
  // a removed project; catalog callers keep missing project storage unknown.
  return async sessionId => {
    if (!UUID.test(sessionId) || !path.isAbsolute(configDirectory || '')) return 'unknown';
    try {
      // Windows short names are retained by the CLI, but directory junctions
      // can become their resolved target. Prefer the launch spelling, then
      // inspect only this UUID under the resolved spelling when it is absent.
      const cwd = path.resolve(workingDirectory).normalize('NFC');
      if (!(await fs.stat(cwd)).isDirectory()) return 'unknown';
      if (projectDirectoryName !== undefined) {
        if (!/^[A-Za-z0-9_-]{1,64}$/.test(projectDirectoryName) || /^(?:con|prn|aux|nul|com[0-9]|lpt[0-9])$/i.test(projectDirectoryName)) return 'unknown';
      }
      const projects = path.join(configDirectory.normalize('NFC'), 'projects');
      await directorySafe(projects);
      if (!(await fs.lstat(projects)).isDirectory()) return 'unknown';
      async function inspectProject(projectCwd) {
        let project = projectCwd.replace(/[^a-zA-Z0-9]/g, '-');
        if (project.length > 200) {
          let hash = 0;
          for (let index = 0; index < projectCwd.length; index++) hash = ((hash << 5) - hash + projectCwd.charCodeAt(index)) | 0;
          project = `${project.slice(0, 200)}-${Math.abs(hash).toString(36)}`;
        }
        const directory = path.join(projects, projectDirectoryName ?? project);
        await directorySafe(directory);
        const projectStat = await fs.lstat(directory).catch(error => { if (error.code === 'ENOENT') return null; throw error; });
        if (!projectStat) return null;
        if (!projectStat.isDirectory()) return 'unknown';
        const stat = await fs.lstat(path.join(directory, `${sessionId}.jsonl`)).catch(error => {
          if (error.code === 'ENOENT') return null;
          throw error;
        });
        return stat === null ? 'deleted' : stat.isFile() && !stat.isSymbolicLink() && stat.nlink === 1 && stat.size > 0 ? 'present' : 'unknown';
      }
      const status = await inspectProject(cwd);
      if (status === 'present' || status === 'unknown' || projectDirectoryName !== undefined) return status ?? missingProjectState;
      const resolved = (await fs.realpath(cwd)).normalize('NFC');
      if (resolved !== cwd) {
        const resolvedStatus = await inspectProject(resolved);
        if (resolvedStatus !== null) return resolvedStatus;
      }
      return status ?? missingProjectState;
    } catch { return 'unknown'; }
  };
}
