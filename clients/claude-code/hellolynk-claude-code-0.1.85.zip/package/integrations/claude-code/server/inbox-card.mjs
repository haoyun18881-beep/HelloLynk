import { createHash } from "node:crypto";
import { readFile } from "node:fs/promises";
import { createStandardMcpAppClient } from "../../../runtime/workbench/ui/mcp-app-client.mjs";

export const CLAUDE_INBOX_CARD_TOOL = "hellolynk_show_inbox_card";
const MIME = "text/html;profile=mcp-app";
const META = { ui: { prefersBorder: true, csp: { connectDomains: [], resourceDomains: [] } } };
const REVISION = { type: "string", pattern: "^(initial|[a-f0-9]{32})$" };
const EMPTY = { type: "object", additionalProperties: false, properties: {} };
const READ = { readOnlyHint: true, destructiveHint: false, openWorldHint: false, idempotentHint: true };
export const CLAUDE_INBOX_CARD_DEFINITION = Object.freeze({
  name: CLAUDE_INBOX_CARD_TOOL, title: "来信概况",
  description: "显示 HelloLynk 来信概况卡片。",
  inputSchema: EMPTY, annotations: READ,
});

// Shares the existing MCP Apps bridge; no SDK/runtime or network dependency.
// The notification needs a scoped count and at most three metadata records,
// never a full inbox/outbox bundle or a second contact-list read.
export function createClaudeInboxCard({ adapter, connectAccount, openLocalWeb, enableUi = true }) {
  let resourcePromise;
  const publicErrors = new Set(["workbench_account_changed", "workbench_connection_required",
    "host_app_authorization_required", "invalid_params", "inbox_card_data_invalid"]);
  async function resources() {
    if (!resourcePromise) resourcePromise = composeClaudeInboxCardHtml().then((html) => {
      const digest = createHash("sha256").update(html).update(JSON.stringify(META)).digest("hex");
      const uri = `ui://hellolynk/inbox-claude-${digest}.html`;
      return { resource: { uri, name: "HelloLynk 来信概况", mimeType: MIME }, html };
    });
    return resourcePromise;
  }
  return {
    async app() {
      if (!enableUi) return null;
      const { resource, html } = await resources();
      return {
        resource,
        tools: ["refresh", "open"].map((action) => ({
          name: `hellolynk_inbox_card_${action}`,
          description: action === "refresh" ? "仅供来信卡片刷新元数据。" : "仅供来信卡片打开 HelloLynk 通讯。",
          inputSchema: { ...EMPTY, required: ["_hellolynkAccountRevision"], properties: { _hellolynkAccountRevision: REVISION } },
          annotations: READ, _meta: { ui: { resourceUri: resource.uri, visibility: ["app"] } },
        })),
        readResource(uri) {
          if (!/^ui:\/\/hellolynk\/inbox-claude-[a-f0-9]{64}\.html$/.test(uri)) throw error("resource_not_found");
          return { contents: [{ uri, mimeType: MIME, text: html, _meta: META }] };
        },
      };
    },
    async callTool(name, args = {}, appEnabled = false) {
      const show = name === CLAUDE_INBOX_CARD_TOOL;
      const open = name === "hellolynk_inbox_card_open";
      if (!show && (!appEnabled || (!open && name !== "hellolynk_inbox_card_refresh"))) return null;
      let revision;
      try {
        const keys = show ? [] : ["_hellolynkAccountRevision"];
        if (!args || typeof args !== "object" || Array.isArray(args) || Object.keys(args).sort().join() !== keys.join()) throw error("invalid_params");
        revision = show ? connectAccount.readAccountState().revision : args._hellolynkAccountRevision;
        if (typeof revision !== "string" || !/^(initial|[a-f0-9]{32})$/.test(revision)) throw error("invalid_params");
        connectAccount.assertRevision(revision);
        const value = await connectAccount.runForAccount(revision, async () => {
          if (open) {
            const entry = await openLocalWeb();
            const url = entry?.cleanUrl || entry?.url;
            if (typeof url !== "string" || !/^http:\/\/127\.0\.0\.1:\d{1,5}\/inbox$/.test(url)) throw error("inbox_card_data_invalid");
            return { url };
          }
          const [unread, inbox] = await Promise.all([
            adapter.readUnreadCount(), adapter.readRecentUnreadMetadata(),
          ]);
          return projectInboxCard(unread, inbox);
        });
        // The read and browser bootstrap can span an account switch.
        connectAccount.assertRevision(revision);
        if (open) return { content: [], structuredContent: { ok: true }, _meta: { hellolynkInboxCard: { revision, ...value } }, isError: false };
        const result = { ok: true, ...value };
        return { content: show ? [{ type: "text", text: summary(value) }] : [], structuredContent: result,
          _meta: { hellolynkInboxCard: { revision } }, isError: false };
      } catch (cause) {
        const code = publicErrors.has(cause?.code) ? cause.code : "inbox_card_unavailable";
        return { content: show ? [{ type: "text", text: "HelloLynk 来信概况暂时无法读取；未读数量未知。" }] : [],
          structuredContent: { ok: false, errorCode: code }, isError: true,
          ...(revision && code !== "workbench_account_changed" ? { _meta: { hellolynkInboxCard: { revision } } } : {}) };
      }
    },
  };
}

export function projectInboxCard(unread, inbox) {
  if (!Number.isSafeInteger(unread?.unreadCount) || unread.unreadCount < 0
    || !Array.isArray(inbox?.messages) || inbox.messages.length > 3) throw error("inbox_card_data_invalid");
  const recent = inbox.messages.filter((item) => item?.unread === true)
    .map((item) => {
      if (!Number.isFinite(Date.parse(item.createdAt))) throw error("inbox_card_data_invalid");
      return { sender: label(item.displayName, "联系人"),
        agent: label(item.peerInstanceDisplayName, "AI"),
        createdAt: new Date(item.createdAt).toISOString() };
    }).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 3);
  return { unreadCount: unread.unreadCount, recent: unread.unreadCount === 0 ? [] : recent, scope: "authorized_unread_metadata" };
}
function label(value, fallback) {
  return typeof value === "string" && value.trim() ? [...value.replace(/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/g, " ")].slice(0, 160).join("") : fallback;
}
function summary(value) {
  return [`HelloLynk：${value.unreadCount} 条未读。`, ...value.recent.map((item) => `${item.sender} · ${item.agent} · ${item.createdAt}`)].join("\n");
}
function error(code) { return Object.assign(new Error(code), { code }); }

export async function composeClaudeInboxCardHtml() {
  const logo = (await readFile(new URL("../../../runtime/workbench/ui/hellolynk-mark.png", import.meta.url))).toString("base64");
  const script = `(${mountInboxCard.toString()})(${createStandardMcpAppClient.toString()});`.replaceAll("</script", "<\\/script");
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>HelloLynk 来信概况</title>
<style>
:root{color-scheme:light dark;--card-bg:#fff;--card-fg:#202020;--card-muted:#696969;--card-border:#ddd}
:root[data-theme="dark"]{--card-bg:#242424;--card-fg:#ececec;--card-muted:#aaa;--card-border:#484848}
*{box-sizing:border-box}body{margin:0;padding:16px;background:var(--color-background-primary,var(--card-bg));color:var(--color-text-primary,var(--card-fg));font:14px/1.5 var(--font-sans,system-ui,sans-serif)}
header,.buttons{display:flex;align-items:center;gap:10px;flex-wrap:wrap}header img{width:28px;height:28px}h1{font-size:16px;margin:0}#count{margin-left:auto;color:var(--color-text-secondary,var(--card-muted))}
ul{padding:0;margin:14px 0;list-style:none}li{padding:8px 0;border-top:1px solid var(--color-border-primary,var(--card-border));overflow-wrap:anywhere}li small{display:block;color:var(--color-text-secondary,var(--card-muted))}
button{font:inherit;color:inherit;background:var(--color-background-secondary,var(--card-bg));border:1px solid var(--color-border-primary,var(--card-border));border-radius:var(--border-radius-md,8px);padding:7px 13px;cursor:pointer}button:disabled{opacity:.55;cursor:wait}button:focus-visible{outline:2px solid var(--color-border-info,#438cff);outline-offset:2px}
#status,#scope{color:var(--color-text-secondary,var(--card-muted));font-size:12px}#status:empty{display:none}#empty{margin:16px 0}
</style></head><body><header><img alt="" src="data:image/png;base64,${logo}"><h1>HelloLynk</h1><span id="count">读取中…</span></header>
<p id="empty">正在读取来信概况…</p><ul id="recent"></ul><p id="scope" hidden>最近三条已授权未读来信</p>
<div class="buttons"><button id="open" disabled>打开 HelloLynk 通讯</button><button id="refresh" disabled>刷新</button></div><p id="status" role="status" aria-live="polite"></p>
<script>${script}</script></body></html>`;
}

// Serialized into the self-contained resource. All remote strings use
// textContent; no body read, polling, sendMessage or updateModelContext exists.
function mountInboxCard(createClient) {
  const byId = (id) => document.getElementById(id);
  const client = createClient(window, { appInfo: { name: "HelloLynk Inbox Card", version: "1" } });
  let revision = null, invalidated = false, refreshing = false, opening = false, connected = false, resultSeen = false, resultTimer;
  const themeKeys = new Set();
  function theme(context = {}) {
    if (["light", "dark"].includes(context.theme)) document.documentElement.dataset.theme = context.theme;
    if (context.styles?.variables) {
      for (const key of themeKeys) document.documentElement.style.removeProperty(key);
      themeKeys.clear();
      for (const [key, value] of Object.entries(context.styles.variables)) {
        if (/^--(?:color-|font-|border-radius-)[\w-]+$/.test(key) && typeof value === "string") {
          document.documentElement.style.setProperty(key, value); themeKeys.add(key);
        }
      }
    }
  }
  function resize() {
    if (connected) client.notify("ui/notifications/size-changed", { height: Math.ceil(document.body.scrollHeight) });
  }
  function controls() {
    byId("refresh").disabled = !connected || !revision || refreshing;
    byId("open").disabled = !connected || !revision || opening;
    byId("refresh").textContent = refreshing ? "刷新中…" : "刷新";
    byId("open").textContent = opening ? "打开中…" : "打开 HelloLynk 通讯";
  }
  function failure(message, clear = true) {
    byId("status").textContent = message;
    if (clear) { byId("recent").replaceChildren(); byId("count").textContent = "未读数未知"; byId("empty").hidden = true; byId("scope").hidden = true; }
    controls(); resize();
  }
  function accept(result) {
    // Once invalidated, this resource must be reopened. Older async responses
    // cannot restore its revision or bring back metadata from the old view.
    if (invalidated) return;
    resultSeen = true;
    clearTimeout(resultTimer);
    const incoming = result?._meta?.hellolynkInboxCard?.revision;
    const value = result?.structuredContent;
    if (value?.errorCode === "workbench_account_changed") {
      invalidated = true; revision = null; failure("连接已变化，请重新打开来信卡片。"); return;
    }
    if (typeof incoming !== "string" || !/^(initial|[a-f0-9]{32})$/.test(incoming)) {
      failure(revision ? "暂时无法读取，点击刷新重试。" : "连接已变化，请重新打开来信卡片。"); return;
    }
    if (revision && revision !== incoming) { invalidated = true; revision = null; failure("账号已切换，请重新打开来信卡片。"); return; }
    revision = incoming;
    if (result?.isError || value?.ok !== true || !Number.isSafeInteger(value.unreadCount) || value.unreadCount < 0 || !Array.isArray(value.recent) || value.recent.length > 3
      || value.recent.some((item) => !item || typeof item.sender !== "string" || typeof item.agent !== "string" || !Number.isFinite(Date.parse(item.createdAt)))) {
      failure(revision ? "暂时无法读取，点击刷新重试。" : "连接已变化，请重新打开来信卡片。"); return;
    }
    byId("recent").replaceChildren();
    for (const item of value.recent) {
      const row = document.createElement("li"), detail = document.createElement("small");
      row.textContent = String(item.sender || "联系人");
      const date = new Date(item.createdAt);
      detail.textContent = `${item.agent || "AI"} · ${Number.isFinite(date.getTime()) ? date.toLocaleString() : "时间未知"}`;
      row.append(detail); byId("recent").append(row);
    }
    byId("count").textContent = `${value.unreadCount} 条未读`;
    byId("empty").hidden = value.recent.length > 0;
    byId("empty").textContent = value.unreadCount === 0 ? "没有未读来信。" : "更多来信请在 HelloLynk 通讯里查看。";
    byId("scope").hidden = value.recent.length === 0;
    byId("status").textContent = ""; controls(); resize();
  }
  client.onToolResult(accept);
  client.onHostContextChanged(theme);
  byId("refresh").addEventListener("click", async () => {
    if (!revision || refreshing || !connected) return;
    refreshing = true; controls(); byId("status").textContent = "";
    try { accept(await client.callTool("hellolynk_inbox_card_refresh", { _hellolynkAccountRevision: revision })); }
    catch { if (!invalidated) failure("刷新失败，未读数未知。请稍后重试。"); }
    finally { refreshing = false; controls(); }
  });
  byId("open").addEventListener("click", async () => {
    if (!revision || opening || !connected) return;
    opening = true; controls(); byId("status").textContent = "";
    try {
      const result = await client.callTool("hellolynk_inbox_card_open", { _hellolynkAccountRevision: revision });
      if (invalidated) return;
      if (result?.structuredContent?.errorCode === "workbench_account_changed") {
        invalidated = true; revision = null; failure("账号已切换，请重新打开来信卡片。"); return;
      }
      const data = result?._meta?.hellolynkInboxCard;
      if (result?.isError || data?.revision !== revision || !/^http:\/\/127\.0\.0\.1:\d{1,5}\/inbox$/.test(data?.url || "")) throw new Error("open_failed");
      const opened = await client.openLink(data.url);
      if (opened?.isError) throw new Error("open_failed");
    } catch { if (!invalidated) failure("暂时无法打开 HelloLynk 通讯，请重试。", false); }
    finally { opening = false; controls(); }
  });
  client.connect().then((session) => { if (invalidated) return; connected = true; theme(session.hostContext); controls(); resize();
    if (!resultSeen) resultTimer = setTimeout(() => failure("未收到来信概况，请重新打开卡片。"), 10_000);
  }).catch(() => { if (!invalidated) failure("客户端未能连接卡片，请直接打开 HelloLynk 通讯。"); });
  window.addEventListener("resize", resize);
  window.addEventListener("pagehide", () => { connected = false; clearTimeout(resultTimer); client.close(); }, { once: true });
}
