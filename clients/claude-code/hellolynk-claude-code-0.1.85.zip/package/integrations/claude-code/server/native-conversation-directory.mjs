import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { nativeReplyRouteLocation } from '../../../runtime/core/hellolynk-native-reply-routes.mjs';
import { nativeConversationId, nativeTitleMatchKey } from '../../../runtime/core/hellolynk-native-conversations.mjs';
import { createClaudeSessionStateReader } from './native-task-cli.mjs';

const UUID = '[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}';
const CLI = new RegExp(`^${UUID}$`, 'i'), DESKTOP = new RegExp(`^local_${UUID}$`, 'i');
const basename = value => (value || '').includes('\\') ? path.win32.basename(value) : path.basename(value || '');
const directory = scope => path.join(scope.runtimeRoot, 'native-conversations', 'claude', nativeReplyRouteLocation(scope).scopeHash);
async function json(file) {
  try { return JSON.parse(await fs.readFile(file, 'utf8')); }
  catch (error) { if (['ENOENT', 'ENOTDIR'].includes(error.code)) return null; throw error; }
}
async function entries(dir) { return fs.readdir(dir, { withFileTypes: true }).catch(e => { if (e.code === 'ENOENT') return []; throw e; }); }
async function roots() {
  const result = [];
  if (process.env.LOCALAPPDATA) {
    const dataRoot = path.join(process.env.LOCALAPPDATA, 'Claude-Data');
    for (const item of await entries(dataRoot)) if (item.isDirectory() && /^claude_[a-z0-9]+$/i.test(item.name))
      result.push(path.join(dataRoot, item.name, 'claude-code-sessions'));
    result.push(path.join(process.env.LOCALAPPDATA, 'Claude-3p', 'claude-code-sessions'));
    const packages = path.join(process.env.LOCALAPPDATA, 'Packages');
    for (const item of await entries(packages)) if (item.isDirectory() && item.name.startsWith('Claude_'))
      result.push(path.join(packages, item.name, 'LocalCache', 'Roaming', 'Claude', 'claude-code-sessions'));
  }
  if (process.env.APPDATA) result.push(path.join(process.env.APPDATA, 'Claude', 'claude-code-sessions'));
  if (process.platform === 'darwin') result.push(path.join(os.homedir(), 'Library', 'Application Support', 'Claude', 'claude-code-sessions'));
  return [...new Set(result)];
}
async function metadata(file) {
  if (!DESKTOP.test(path.basename(file, '.json'))) return null;
  let value;
  try { value = await json(file); } catch { return null; } // A partial native write is unknown, never deletion.
  if (!value || value.sessionId !== path.basename(file, '.json') || !CLI.test(value.cliSessionId || '')
    || typeof value.isArchived !== 'boolean') return null;
  // Desktop JSON also contains summaries and prompts. Only this projection
  // survives the read; .key and transcript files are never opened here.
  return { sessionId: value.sessionId, cliSessionId: value.cliSessionId, title: typeof value.title === 'string' ? value.title : '',
    cwd: typeof value.cwd === 'string' ? value.cwd : '', archived: value.isArchived, file };
}
async function findDesktop(sessionId, hostSessionId, previous, options) {
  if (!CLI.test(sessionId)) return null;
  if (previous?.desktopFile) {
    const cached = await metadata(previous.desktopFile);
    if (!cached) return null; // Native file temporarily unavailable: keep the verified alias.
    return cached.cliSessionId === sessionId ? cached : false; // /clear invalidated it.
  }
  if (!hostSessionId && previous?.desktopChecked && previous.hostSessionId === null) return false;
  const matches = [];
  const checkedRoots = new Set();
  for (const candidate of options.roots ?? await roots()) {
    const root = await fs.realpath(candidate).catch(() => null);
    if (!root || checkedRoots.has(root)) continue;
    checkedRoots.add(root);
    for (const account of await entries(root)) if (account.isDirectory()) {
      const accountDir = path.join(root, account.name);
      for (const org of await entries(accountDir)) if (org.isDirectory()) {
        const orgDir = path.join(accountDir, org.name);
        for (const item of await entries(orgDir)) if (item.isFile() && /^local_.*\.json$/.test(item.name)) {
          if (hostSessionId && DESKTOP.test(hostSessionId) && item.name !== `${hostSessionId}.json`) continue;
          const value = await metadata(path.join(orgDir, item.name));
          if (value?.cliSessionId === sessionId) matches.push(value);
        }
      }
    }
  }
  // Never guess between accounts or inherited fork identifiers.
  const identities = new Set(matches.map(v => [path.basename(path.dirname(path.dirname(v.file))), path.basename(path.dirname(v.file)), v.sessionId].join('/')));
  return identities.size === 1 ? matches[0] : false;
}
async function save(file, value) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const temporary = `${file}.${crypto.randomUUID()}.tmp`;
  try { await fs.writeFile(temporary, JSON.stringify(value), { flag: 'wx' }); await fs.rename(temporary, file); }
  finally { await fs.rm(temporary, { force: true }).catch(() => {}); }
}
export async function recordClaudeConversation(scope, input, options = {}) {
  const sessionId = nativeConversationId(input.sessionId), file = path.join(directory(scope), `${sessionId}.json`);
  const previous = await json(file);
  if (input.closed) {
    if (previous) await save(file, { ...previous, state: 'notLoaded', seenAt: Date.now() });
    return previous;
  }
  const desktop = await findDesktop(sessionId, input.hostSessionId, previous, options);
  const cached = desktop === null && input.hostSessionId === previous?.targetConversationId ? previous : null;
  const cwd = desktop?.cwd || (typeof input.cwd === 'string' && path.isAbsolute(input.cwd) ? input.cwd : previous?.cwd || '');
  const value = { sessionId, targetConversationId: desktop?.sessionId || cached?.targetConversationId || sessionId,
    desktopFile: desktop?.file || cached?.desktopFile || null, desktopChecked: desktop !== null,
    hostSessionId: input.hostSessionId || null, cwd, project: basename(cwd),
    title: desktop?.title || (typeof input.title === 'string' ? input.title : previous?.title || ''),
    state: desktop?.archived || cached?.state === 'archived' ? 'archived' : 'idle', seenAt: Date.now() };
  await save(file, value);
  return value;
}
// A past sender can still belong to the same Desktop after its CLI ID changes.
// This is historical registration only; the receiving CLI must verify its live alias.
export async function registeredClaudeConversationAlias(scope, sessionId) {
  const value = await json(path.join(directory(scope), `${nativeConversationId(sessionId)}.json`));
  return value?.desktopFile && DESKTOP.test(value.targetConversationId || '') ? value.targetConversationId : null;
}
// The Desktop alias this CLI session holds now, as prepare verified it. After a
// /clear the Desktop row names the new CLI session, so the old one has none.
export async function verifiedClaudeConversationAlias(scope, sessionId) {
  const value = await json(path.join(directory(scope), `${nativeConversationId(sessionId)}.json`));
  if (!value?.desktopFile || !DESKTOP.test(value.targetConversationId || '')) return null;
  const desktop = await metadata(value.desktopFile);
  return desktop?.sessionId === value.targetConversationId && desktop.cliSessionId === sessionId ? desktop.sessionId : null;
}
export async function listClaudeConversations(scope, query = {}, options = {}) {
  const registered = [];
  for (const item of await entries(directory(scope))) if (item.isFile() && item.name.endsWith('.json')) {
    const value = await json(path.join(directory(scope), item.name));
    if (value?.sessionId) registered.push(value);
  }
  registered.sort((a, b) => b.seenAt - a.seenAt);
  const desktopDirectory = registered.find(r => r.desktopFile)?.desktopFile;
  const rows = new Map();
  let exactTitleSupported = registered.length > 0;
  if (desktopDirectory) {
    for (const item of await entries(path.dirname(desktopDirectory))) if (item.isFile() && /^local_.*\.json$/.test(item.name)) {
      const value = await metadata(path.join(path.dirname(desktopDirectory), item.name));
      if (!value) { exactTitleSupported = false; continue; }
      const online = registered.find(r => r.sessionId === value.cliSessionId && r.state === 'idle' && Date.now() - r.seenAt < 90_000);
      rows.set(value.sessionId, { targetConversationId: value.sessionId, title: value.title,
        project: basename(value.cwd), state: value.archived ? 'archived' : online ? 'idle' : 'notLoaded' });
      // Known current CLI UUID remains usable; never advertise old /clear IDs.
      if (query.targetConversationId === value.cliSessionId) rows.set(value.cliSessionId,
        { ...rows.get(value.sessionId), targetConversationId: value.cliSessionId });
    }
    if (DESKTOP.test(query.targetConversationId || '') && !rows.has(query.targetConversationId)) {
      const parent = path.dirname(desktopDirectory), file = path.join(parent, query.targetConversationId + '.json');
      // Missing native storage or a partial write is unavailable. Only absence
      // of the exact file in the known account/org directory proves deletion.
      const parentExists = await fs.stat(parent).then(value => value.isDirectory()).catch(() => false);
      let state = 'unavailable';
      const registeredElsewhere = registered.some(r => r.desktopFile && r.targetConversationId === query.targetConversationId
        && path.dirname(r.desktopFile) !== parent);
      if (parentExists && !registeredElsewhere) try { await fs.stat(file); } catch (error) { if (error.code === 'ENOENT') state = 'deleted'; }
      rows.set(query.targetConversationId, { targetConversationId: query.targetConversationId, title: query.targetConversationId, project: '', state });
    }
  }
  for (const value of registered) {
    if (value.desktopFile) continue; // A removed desktop row is not a CLI fallback.
    // Older CLI registrations clipped titles to 256 UTF-16 units. A lookup
    // at that boundary cannot tell a complete title from a matching prefix.
    if (query.exactTitle && value.title?.length === 256
      && nativeTitleMatchKey(value.title) === nativeTitleMatchKey(query.title)) exactTitleSupported = false;
    const fresh = Date.now() - value.seenAt < 90_000;
    let state = fresh ? value.state : 'notLoaded';
    if (!fresh && query.targetConversationId === value.sessionId && value.cwd) {
      const exists = await createClaudeSessionStateReader(value.cwd, { missingProjectState: 'unknown' })(value.sessionId).catch(() => 'unknown');
      if (exists === 'deleted') state = 'deleted';
    }
    rows.set(value.sessionId, { targetConversationId: value.sessionId, title: value.title,
      project: value.project, state });
  }
  // CLI history without a Mod registration is not a complete native catalog.
  return { conversations: [...rows.values()], coverage: 'partial', exactTargetSupported: registered.length > 0,
    ...(query.exactTitle ? { exactTitleSupported } : {}) };
}
