#!/usr/bin/env node
// The distribution builder replaces this anchor. No candidate module is loaded
// until the complete pinned file list has been checked using Node built-ins.
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const expected = 'dfe8e10b47a4a5e967943cc2523b1daba7c8de118b3c834ff18921e5d5a58e34';
const root = path.join(path.dirname(fileURLToPath(import.meta.url)), 'package');
const fail = () => { throw new Error('claude_code_distribution_integrity_invalid'); };
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const say = (zh, en) => /^zh\b/i.test(Intl.DateTimeFormat().resolvedOptions().locale) ? zh : en;
async function regular(relative) {
  let current = root;
  const parts = relative.split('/');
  for (let index = 0; index < parts.length; index++) {
    current = path.join(current, parts[index]);
    const stat = await fs.lstat(current);
    if (stat.isSymbolicLink() || (index < parts.length - 1 ? !stat.isDirectory() : !stat.isFile() || stat.nlink !== 1)) fail();
  }
  return fs.readFile(current);
}
try {
  for (let current = root; ; current = path.dirname(current)) {
    const stat = await fs.lstat(current);
    if (!stat.isDirectory() || stat.isSymbolicLink()) fail();
    if (path.dirname(current) === current) break;
  }
  const bytes = await regular('runtime/neutral-host-release-manifest.json');
  if (!/^[a-f0-9]{64}$/.test(expected) || hash(bytes) !== expected) fail();
  const manifest = JSON.parse(bytes);
  if (manifest.contract !== 'hellolynk-neutral-host-release-manifest-v1' || !Array.isArray(manifest.files)) fail();
  const seen = new Set();
  for (const record of manifest.files) {
    if (!/^(?:[A-Za-z0-9][A-Za-z0-9._-]*\/)*[A-Za-z0-9][A-Za-z0-9._-]*$/.test(record.path) || !/^[a-f0-9]{64}$/.test(record.sha256)) fail();
    const relative = record.path.startsWith('release/') ? record.path.slice(8) : `runtime/${record.path}`;
    if (seen.has(relative) || hash(await regular(relative)) !== record.sha256) fail();
    seen.add(relative);
  }
  // Shared UI images/styles use their existing asset manifest. The candidate
  // manifest above pins that manifest, completing the chain for binary assets.
  if (!seen.has('runtime/workbench/hellolynk-workbench-build.json')) fail();
  const workbench = JSON.parse(await regular('runtime/workbench/hellolynk-workbench-build.json'));
  if (workbench.contract !== 'hellolynk-shared-workbench-build-v1' || !Array.isArray(workbench.files)) fail();
  for (const record of workbench.files) {
    if (!/^(?:[A-Za-z0-9][A-Za-z0-9._-]*\/)*[A-Za-z0-9][A-Za-z0-9._-]*$/.test(record.path) || !/^[a-f0-9]{64}$/.test(record.sha256)) fail();
    const relative = `runtime/workbench/${record.path}`;
    if (hash(await regular(relative)) !== record.sha256) fail();
    seen.add(relative);
  }
  const pin = JSON.parse(await regular('runtime/neutral-host-release-pin.json'));
  if (pin.contract !== 'hellolynk-neutral-host-release-pin-v1' || pin.manifestSha256 !== expected) fail();
  seen.add('runtime/neutral-host-release-manifest.json'); seen.add('runtime/neutral-host-release-pin.json');
  // The updater's package manifest must pin exactly this verified tree.
  const packBytes = await regular('hellolynk-client-pack-manifest.json');
  const pack = JSON.parse(packBytes), packPin = JSON.parse(await regular('hellolynk-client-pack-pin.json'));
  const metadata = JSON.parse(await regular('package.json'));
  const packPaths = new Set(Array.isArray(pack.files) ? pack.files.map(record => record.path) : []);
  if (pack.contract !== 'hellolynk-client-npm-pack-manifest-v1' || pack.client !== 'claude-code'
    || pack.packageName !== metadata.name || pack.version !== metadata.version
    || packPin.contract !== 'hellolynk-client-npm-pack-pin-v1' || packPin.manifestSha256 !== hash(packBytes)
    || packPaths.size !== pack.files.length || packPaths.size !== seen.size || [...seen].some(relative => !packPaths.has(relative))) fail();
  for (const record of pack.files) if (hash(await regular(record.path)) !== record.sha256) fail();
  seen.add('hellolynk-client-pack-manifest.json'); seen.add('hellolynk-client-pack-pin.json');
  async function walk(directory, prefix = '') {
    for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
      const relative = prefix + entry.name;
      if (entry.isDirectory()) await walk(path.join(directory, entry.name), `${relative}/`);
      else if (!entry.isFile() || !seen.delete(relative)) fail();
    }
  }
  await walk(root);
  if (seen.size) fail();
  if (process.argv.slice(2).join(' ') === '--check') {
    process.stdout.write(`${say('安装包校验通过，没有改动任何设置。', 'Package verified. No settings changed.')}\n`);
  } else {
    const { runClaudeCodeSetup } = await import(pathToFileURL(path.join(root, 'integrations/claude-code/install/setup.mjs')));
    await runClaudeCodeSetup(process.argv.slice(2), { candidateRoot: root, expectedManifestSha256: expected });
  }
} catch (error) {
  const code = /^(?:claude|hellolynk)_[a-z0-9_]+$/.test(error?.code || error?.message || '') ? error.code || error.message : 'claude_code_install_failed';
  const uninstall = process.argv[2] === 'uninstall';
  process.stderr.write(`${code}\n${uninstall ? say('卸载没有完成。处理方法见 README.md。', 'Uninstall did not complete. See README.md.')
    : say('安装没有完成。处理方法见 README.md。', 'Installation did not complete. See README.md.')}\n`);
  process.exitCode = 1;
}
