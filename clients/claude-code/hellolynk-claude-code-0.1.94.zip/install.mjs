#!/usr/bin/env node
// The distribution builder replaces this anchor. No candidate module is loaded
// until the complete pinned file list has been checked using Node built-ins.
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const expected = '51ae8081568b7520cc0f5e695d3c03aeb540dd7bd7a793a5b7aaeb4c49e5d607';
const root = path.join(path.dirname(fileURLToPath(import.meta.url)), 'package');
const fail = () => { throw new Error('claude_code_distribution_integrity_invalid'); };
const hash = bytes => crypto.createHash('sha256').update(bytes).digest('hex');
const say = (zh, en) => /^zh\b/i.test(Intl.DateTimeFormat().resolvedOptions().locale) ? zh : en;
// One plain sentence for the errors people can fix themselves. Any other code keeps the pointer to README.md.
const POWERSHELL7_URL = 'https://learn.microsoft.com/powershell/scripting/install/install-powershell-on-windows';
const hint = code => ({
  claude_code_install_close_claude_required: say('Claude 还在运行。请完全退出（包括托盘里的 Claude 和正在运行的 Claude CLI），再重新运行刚才的命令。',
    'Claude is still running. Quit it completely (including Claude in the tray and any running Claude CLI), then run the same command again.'),
  claude_code_install_desktop_not_found: say('没有找到 Claude 桌面版或它的配置。请打开一次 Claude 桌面版，退出后重试。如果 Claude 装在别处，加上 --desktop-config "<claude_desktop_config.json 的完整路径>"。',
    'Claude desktop or its configuration was not found. Open Claude desktop once, quit it, and try again. If Claude is installed elsewhere, add --desktop-config "<full path to claude_desktop_config.json>".'),
  claude_code_install_desktop_ambiguous: say('找到了多个 Claude。请加上 --desktop-config "<要接入的 claude_desktop_config.json 的完整路径>" 后重试。',
    'More than one Claude was found. Add --desktop-config "<full path to the claude_desktop_config.json to use>" and try again.'),
  claude_code_install_desktop_path_invalid: say('--desktop-config 给的路径不对。请写 claude_desktop_config.json 的完整路径（含文件名），并确认它所在的文件夹存在。',
    'The --desktop-config path is not valid. Give the full path to claude_desktop_config.json, file name included, and make sure its folder exists.'),
  claude_code_install_config_invalid: say('Claude 的配置文件（claude_desktop_config.json 或用户文件夹里的 .claude.json）含无效的 JSON，原文件已保留。请修正格式或恢复一份可用的备份，再重试。',
    'A Claude configuration file (claude_desktop_config.json or .claude.json in your user folder) contains invalid JSON. The installer kept the file. Fix the JSON or restore a working backup, then try again.'),
  claude_code_install_process_check_failed: say('没能检查 Claude 是否已经退出。请确认 Claude 已完全退出、系统的 PowerShell 能正常运行，然后重试。',
    'Could not check whether Claude has quit. Make sure Claude is fully closed and Windows PowerShell works, then try again.'),
  claude_code_install_desktop_first: say('还没有安装。请先运行 node install.mjs，再启用后台收信。',
    'HelloLynk is not installed yet. Run node install.mjs first, then enable background receiving.'),
  claude_code_install_busy: say('另一个安装器正在运行。等它结束后重试。', 'Another installer is running. Wait for it to finish, then try again.'),
  hellolynk_node_22_16_required: say('Node.js 版本太低。请安装 22.16 或更高版本后重试。', 'Node.js is too old. Install version 22.16 or later and try again.'),
  powershell7_missing: say(`找不到 PowerShell 7。按微软说明安装后，新开终端运行 pwsh -v 确认，再运行刚才的命令。${POWERSHELL7_URL}`,
    `PowerShell 7 could not be found. Install it, open a new terminal, and run pwsh -v before retrying the same command. Microsoft’s instructions are at ${POWERSHELL7_URL}`),
})[code];
async function regular(relative) {
  let current = root;
  const parts = relative.split('/');
  for (let index = 0; index < parts.length; index++) {
    current = path.join(current, parts[index]);
    const stat = await fs.lstat(current);
    if (stat.isSymbolicLink() || (index < parts.length - 1 ? !stat.isDirectory() : !stat.isFile() || stat.nlink !== 1)) fail();
  }
  return fs.readFile(current);
}
try {
  for (let current = root; ; current = path.dirname(current)) {
    const stat = await fs.lstat(current);
    if (!stat.isDirectory() || stat.isSymbolicLink()) fail();
    if (path.dirname(current) === current) break;
  }
  const bytes = await regular('runtime/neutral-host-release-manifest.json');
  if (!/^[a-f0-9]{64}$/.test(expected) || hash(bytes) !== expected) fail();
  const manifest = JSON.parse(bytes);
  if (manifest.contract !== 'hellolynk-neutral-host-release-manifest-v1' || !Array.isArray(manifest.files)) fail();
  const seen = new Set();
  for (const record of manifest.files) {
    if (!/^(?:[A-Za-z0-9][A-Za-z0-9._-]*\/)*[A-Za-z0-9][A-Za-z0-9._-]*$/.test(record.path) || !/^[a-f0-9]{64}$/.test(record.sha256)) fail();
    const relative = record.path.startsWith('release/') ? record.path.slice(8) : `runtime/${record.path}`;
    if (seen.has(relative) || hash(await regular(relative)) !== record.sha256) fail();
    seen.add(relative);
  }
  // Shared UI images/styles use their existing asset manifest. The candidate
  // manifest above pins that manifest, completing the chain for binary assets.
  if (!seen.has('runtime/workbench/hellolynk-workbench-build.json')) fail();
  const workbench = JSON.parse(await regular('runtime/workbench/hellolynk-workbench-build.json'));
  if (workbench.contract !== 'hellolynk-shared-workbench-build-v1' || !Array.isArray(workbench.files)) fail();
  for (const record of workbench.files) {
    if (!/^(?:[A-Za-z0-9][A-Za-z0-9._-]*\/)*[A-Za-z0-9][A-Za-z0-9._-]*$/.test(record.path) || !/^[a-f0-9]{64}$/.test(record.sha256)) fail();
    const relative = `runtime/workbench/${record.path}`;
    if (hash(await regular(relative)) !== record.sha256) fail();
    seen.add(relative);
  }
  const pin = JSON.parse(await regular('runtime/neutral-host-release-pin.json'));
  if (pin.contract !== 'hellolynk-neutral-host-release-pin-v1' || pin.manifestSha256 !== expected) fail();
  seen.add('runtime/neutral-host-release-manifest.json'); seen.add('runtime/neutral-host-release-pin.json');
  // The updater's package manifest must pin exactly this verified tree.
  const packBytes = await regular('hellolynk-client-pack-manifest.json');
  const pack = JSON.parse(packBytes), packPin = JSON.parse(await regular('hellolynk-client-pack-pin.json'));
  const metadata = JSON.parse(await regular('package.json'));
  const packPaths = new Set(Array.isArray(pack.files) ? pack.files.map(record => record.path) : []);
  if (pack.contract !== 'hellolynk-client-npm-pack-manifest-v1' || pack.client !== 'claude-code'
    || pack.packageName !== metadata.name || pack.version !== metadata.version
    || packPin.contract !== 'hellolynk-client-npm-pack-pin-v1' || packPin.manifestSha256 !== hash(packBytes)
    || packPaths.size !== pack.files.length || packPaths.size !== seen.size || [...seen].some(relative => !packPaths.has(relative))) fail();
  for (const record of pack.files) if (hash(await regular(record.path)) !== record.sha256) fail();
  seen.add('hellolynk-client-pack-manifest.json'); seen.add('hellolynk-client-pack-pin.json');
  async function walk(directory, prefix = '') {
    for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
      const relative = prefix + entry.name;
      if (entry.isDirectory()) await walk(path.join(directory, entry.name), `${relative}/`);
      else if (!entry.isFile() || !seen.delete(relative)) fail();
    }
  }
  await walk(root);
  if (seen.size) fail();
  if (process.argv.slice(2).join(' ') === '--check') {
    process.stdout.write(`${say('安装包校验通过，没有改动任何设置。', 'Package verified. No settings changed.')}\n`);
  } else {
    const { runClaudeCodeSetup } = await import(pathToFileURL(path.join(root, 'integrations/claude-code/install/setup.mjs')));
    await runClaudeCodeSetup(process.argv.slice(2), { candidateRoot: root, expectedManifestSha256: expected });
  }
} catch (error) {
  const code = /^(?:(?:claude|hellolynk)_[a-z0-9_]+|powershell7_missing)$/.test(error?.code || error?.message || '') ? error.code || error.message : 'claude_code_install_failed';
  const uninstall = process.argv[2] === 'uninstall';
  const detail = hint(code);
  process.stderr.write(`${code}\n${uninstall ? say('卸载没有完成。', 'Uninstall did not complete.') : say('安装没有完成。', 'Installation did not complete.')} ${detail ?? say('处理方法见 README.md。', 'See README.md.')}\n`);
  process.exitCode = 1;
}
