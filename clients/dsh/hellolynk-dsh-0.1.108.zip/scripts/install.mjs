#!/usr/bin/env node
import crypto from "node:crypto";
import { execFile } from "node:child_process";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { withLocalProcessLock } from "./hellolynk-local-process-lock.mjs";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const PACKAGE = path.join(ROOT, "dist", "package");
const RELEASE_DESCRIPTOR = path.join(ROOT, "trusted-release.json");
const RECOVERY_RELEASES = path.join(ROOT, "dist", "recovery");
const RECORD = "hellolynk-dsh-nav-install.json";
const JOURNAL = "hellolynk-dsh-nav-transaction.json";
const TEST_SENTINEL = ".hellolynk-dsh-test-profile";
const LOCK_STALE_MS = 5 * 60_000;
const MANIFEST = "hellolynk-dsh-nav-build.json";
// The only place that names the supported DeepSeek Harness versions; build.mjs
// records this same range in the package manifest.
export const DSH_SUPPORTED_RANGE = ">=0.2.1-rc.1 <1.0.0";
const execFileAsync = (...args) => new Promise((resolve, reject) => execFile(...args, (error, stdout, stderr) => error ? reject(Object.assign(error, { stdout, stderr })) : resolve({ stdout, stderr })));

// This installer also runs from a standalone download, outside the source tree.
export function assertDshNodeVersion(version = process.versions.node) {
  const parts = /^(\d+)\.(\d+)\.(\d+)$/.exec(String(version || ""));
  const supported = parts && (Number(parts[1]) > 22
    || (Number(parts[1]) === 22 && Number(parts[2]) >= 16));
  if (!supported) {
    const error = code("hellolynk_node_22_16_required");
    error.message = `HelloLynk 本地客户端需要 Node.js 22.16.0 或更高版本（当前 ${String(version || "unknown")}）`;
    throw error;
  }
}

// Semver precedence against DSH_SUPPORTED_RANGE. "<1.0.0" also excludes the
// pre-releases of 1.0.0, so only the 0.x line is accepted.
export function isSupportedDshVersion(version) {
  const [, lowest, below] = /^>=(\S+) <(\S+)$/.exec(DSH_SUPPORTED_RANGE);
  const value = parseDshVersion(version);
  return value !== null && compareDshVersions(value, parseDshVersion(lowest)) >= 0
    && compareDshVersions(value, parseDshVersion(`${below}-0`)) < 0;
}
function parseDshVersion(value) {
  const match = /^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-((?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*)(?:\.(?:0|[1-9]\d*|\d*[A-Za-z-][0-9A-Za-z-]*))*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$/.exec(typeof value === "string" ? value : "");
  return match ? { core: match.slice(1, 4).map(Number), pre: match[4] === undefined ? null : match[4].split(".") } : null;
}
function compareDshVersions(a, b) {
  for (let i = 0; i < 3; i++) if (a.core[i] !== b.core[i]) return a.core[i] < b.core[i] ? -1 : 1;
  if (a.pre === null || b.pre === null) return a.pre === b.pre ? 0 : a.pre === null ? 1 : -1;
  for (let i = 0; i < Math.max(a.pre.length, b.pre.length); i++) {
    const x = a.pre[i], y = b.pre[i];
    if (x === undefined || y === undefined) return x === undefined ? -1 : 1;
    const numeric = [/^\d+$/.test(x), /^\d+$/.test(y)];
    if (numeric[0] && numeric[1]) { if (Number(x) !== Number(y)) return Number(x) < Number(y) ? -1 : 1; }
    else if (numeric[0] !== numeric[1]) return numeric[0] ? -1 : 1;
    else if (x !== y) return x < y ? -1 : 1;
  }
  return 0;
}

export async function installDshCandidate(argv = process.argv.slice(2)) {
  assertDshNodeVersion();
  const input = parse(argv); if (input.help) return { help: true };
  const selected = await safeProfile(input.profile, input.liveProfile), profile = selected.profile, dshRoot = await safeDshRoot(input.dshRoot);
  const hostIdentity = await captureDshIdentity(dshRoot, input.harnessRoot !== null), dshVersion = hostIdentity.version;
  const revalidateHost = async () => {
    let current;
    try { current = await captureDshIdentity(dshRoot, input.harnessRoot !== null); }
    catch { throw code("dsh_candidate_host_changed"); }
    if (JSON.stringify(current) !== JSON.stringify(hostIdentity)) throw code("dsh_candidate_host_changed");
  };
  if (!input.apply) return input.upgrade ? inspectUpgrade(profile, dshRoot, dshVersion, selected.mode, input.expectedInstalledManifestSha256) : inspect(profile, selected.mode, input.uninstall, dshVersion);
  return withLocalProcessLock(path.join(profile, ".hellolynk-dsh-nav.lock"), async () => {
    const lock = await acquireLock(profile);
    try {
      await revalidateHost();
      await recover(profile, input.expectedInstalledManifestSha256);
      await revalidateHost();
      const result = input.upgrade ? await upgrade(profile, dshRoot, dshVersion, input.expectedInstalledManifestSha256, revalidateHost) : input.uninstall ? await uninstall(profile) : await install(profile, dshRoot, dshVersion, revalidateHost);
      return { ...result, mode: selected.mode };
    }
    finally { await releaseLock(lock); }
  });
}

// A connect request may precede the first Host. Validate only the DSH surface
// and fixed package here; the embedded native setup owns all Host state.
export async function preflightDshConnect({ profile, dshRoot } = {}) {
  assertDshNodeVersion();
  const selected = await safeProfile(profile, true);
  const checkedRoot = await safeDshRoot(dshRoot);
  await assertDshVersion(checkedRoot);
  if (await exists(profilePaths(selected.profile).journal)) throw code("dsh_candidate_recovery_required");
  const release = await trustedRelease();
  if (!samePath(release.packageRoot, PACKAGE)) throw code("dsh_candidate_connect_release_not_approved");
  const navigationInstalled = await exists(profilePaths(selected.profile).record);
  if (navigationInstalled) {
    const installed = parseRecord(await regular(profilePaths(selected.profile).record));
    if (installed.manifestSha256 !== release.manifestSha256) throw code("dsh_candidate_existing_release_requires_upgrade");
  }
  await inspect(selected.profile, selected.mode, navigationInstalled);
  const setupEntry = path.join(PACKAGE, "runtime", "connect", "bin", "hellolynk-client-setup.mjs");
  await regular(setupEntry);
  return Object.freeze({ setupEntry, navigationInstalled, manifestSha256: release.manifestSha256 });
}

// Preserve the reviewed payload before a normal build replaces dist/package.
// The archive is selected only by the unchanged source trust anchor, never by
// an installed record, journal, command-line path or freshly generated pin.
export async function preserveDshTrustedRelease() {
  const descriptor = await trustedDescriptor();
  const archive = path.join(RECOVERY_RELEASES, descriptor.manifestSha256);
  if (!await exists(PACKAGE) && !await exists(archive)) return Object.freeze({ preserved: false });
  // A prior ordinary build can leave an unapproved candidate here. There is
  // nothing to preserve if the reviewed payload is absent from both locations.
  // Never turn that candidate into the approved recovery payload.
  if (!await exists(archive) && hash(await regular(path.join(PACKAGE, MANIFEST))) !== descriptor.manifestSha256) {
    return Object.freeze({ preserved: false });
  }
  const release = await trustedRelease({ allowRecovery: true });
  if (samePath(release.packageRoot, archive)) return Object.freeze({ preserved: true, packageRoot: archive });
  if (await exists(archive)) {
    await assertSafeDirectory(archive);
    await assertPackageTree(archive, release);
    return Object.freeze({ preserved: true, packageRoot: archive });
  }
  await assertSafeDirectory(ROOT);
  await fs.mkdir(RECOVERY_RELEASES, { recursive: true });
  await assertSafeDirectory(RECOVERY_RELEASES);
  const stage = `${archive}.stage-${process.pid}-${crypto.randomBytes(8).toString("hex")}`;
  await fs.mkdir(stage, { recursive: false });
  try {
    await copyTree(release.packageRoot, stage);
    await assertPackageTree(stage, release);
    await fs.rename(stage, archive);
  } finally { await fs.rm(stage, { recursive: true, force: true }).catch(() => {}); }
  return Object.freeze({ preserved: true, packageRoot: archive });
}

async function install(profile, dshRoot, dshVersion, revalidateHost) {
  const p = profilePaths(profile), [pkg, patch, release] = await Promise.all([profileFile(p.packageJson), readPatch(p.patch), trustedRelease()]);
  assertProfilePackage(pkg); assertPatch(patch.raw);
  if (await exists(p.record)) throw code("dsh_candidate_already_installed");
  if (await exists(p.destination)) throw code("dsh_candidate_destination_exists");
  const nextPatch = mergePatch(text(patch.raw), false);
  await writeJournal(p.journal, journal("install", p, patch, nextPatch, release));
  await fs.mkdir(path.dirname(p.destination), { recursive: true });
  await assertSafeWritePath(profile, p.destination);
  // The final rename must stay on the profile's volume, even when TEMP is on C:
  // and the user's Harness profile is on another drive.
  const staged = await fs.mkdtemp(path.join(path.dirname(p.destination), ".hellolynk-dsh-stage-"));
  try {
    await copyTree(release.packageRoot, path.join(staged, "package")); await assertPackageTree(path.join(staged, "package"), release);
    await failpoint("install-after-stage");
    await revalidateHost();
    await fs.mkdir(path.dirname(p.destination), { recursive: true }); await assertSafeWritePath(profile, p.destination);
    await fs.rename(path.join(staged, "package"), p.destination); await failpoint("install-after-destination");
    await replacePatchCas(p.patch, patch.sha256, Buffer.from(nextPatch)); await failpoint("install-after-patch");
    await assertPackageTree(p.destination, release);
    const installedPackage = await regular(path.join(p.destination, "package.json"));
    const record = { contract: "hellolynk-dsh-nav-install-v4", profile, dshRoot, dshVersion, packageJsonSha256: hash(pkg), patchBeforeSha256: patch.sha256, patchAfterSha256: hash(Buffer.from(nextPatch)), installedPackageJsonSha256: hash(installedPackage), packageFiles: release.manifest.packageFiles, manifestSha256: release.manifestSha256 };
    await atomic(p.record, Buffer.from(`${JSON.stringify(record, null, 2)}\n`)); await failpoint("install-after-record");
    await fs.rm(p.journal, { force: false });
    return { ok: true, installed: true, profile, dshRoot, record: p.record };
  } catch (error) {
    // Host drift is detected before destination/patch mutation. Clear only the
    // authenticated pending transaction; other fault recovery stays unchanged.
    if (error.code === "dsh_candidate_host_changed") {
      try { await recover(profile); } catch (recoveryError) { error.recoveryCode = recoveryError.code || "dsh_candidate_recovery_required"; }
    }
    throw error;
  } finally { await fs.rm(staged, { recursive: true, force: true }).catch(() => {}); }
}

async function uninstall(profile) {
  const p = profilePaths(profile), recordRaw = await regular(p.record), record = parseRecord(recordRaw), patch = await readPatch(p.patch);
  const release = await trustedRelease({ allowRecovery: true, manifestSha256: record.manifestSha256 });
  if (hash(await regular(path.join(p.destination, "package.json"))) !== record.installedPackageJsonSha256 || record.manifestSha256 !== release.manifestSha256) throw code("dsh_candidate_drift_detected");
  await assertPackageTree(p.destination, release);
  const nextPatch = mergePatch(text(patch.raw), true); if (nextPatch === null) throw code("dsh_candidate_drift_detected");
  await writeJournal(p.journal, journal("uninstall", p, patch, nextPatch, release, recordRaw));
  await assertSafeWritePath(profile, p.backup); if (await exists(p.backup)) throw code("dsh_candidate_recovery_required");
  await fs.rename(p.destination, p.backup); await failpoint("uninstall-after-backup");
  await replacePatchCas(p.patch, patch.sha256, Buffer.from(nextPatch)); await failpoint("uninstall-after-patch");
  await fs.rm(p.backup, { recursive: true, force: false }); await failpoint("uninstall-after-remove");
  await fs.rm(p.record, { force: false }); await failpoint("uninstall-after-record");
  await fs.rm(p.journal, { force: false }); return { ok: true, uninstalled: true, profile };
}

// The old release is authenticated in place, including all recorded files.
// The new download need not include a second copy of the old package.
async function recordedRelease(record, manifestRaw, expectedInstalledManifestSha256 = null) {
  const descriptor = await trustedDescriptor();
  // The optional pin comes from the verified installed updater's trust anchor,
  // never from the mutable install record or transaction journal. It permits
  // skipping releases without granting arbitrary records authority.
  if (![descriptor.manifestSha256, descriptor.previousManifestSha256, expectedInstalledManifestSha256].includes(record.manifestSha256)) throw code("dsh_candidate_release_not_approved");
  if (hash(manifestRaw) !== record.manifestSha256) throw code("dsh_candidate_drift_detected");
  let manifest; try { manifest = JSON.parse(text(manifestRaw)); } catch { throw code("dsh_candidate_package_manifest_invalid"); }
  if (manifest?.contract !== "hellolynk-dsh-nav-build-v3") throw code("dsh_candidate_package_manifest_invalid");
  const recorded = recordsMap(record.packageFiles), approved = recordsMap(manifest.packageFiles);
  if (recorded.size !== approved.size || recorded.get("package.json") !== record.installedPackageJsonSha256
    || [...recorded].some(([name, digest]) => approved.get(name) !== digest)) throw code("dsh_candidate_drift_detected");
  return { manifest, manifestSha256: record.manifestSha256 };
}
async function installedRelease(root, record, expectedInstalledManifestSha256) {
  await assertSafeDirectory(root);
  const release = { ...await recordedRelease(record, await regular(path.join(root, MANIFEST)), expectedInstalledManifestSha256), packageRoot: root };
  await assertPackageTree(root, release);
  if (hash(await regular(path.join(root, "package.json"))) !== record.installedPackageJsonSha256) throw code("dsh_candidate_drift_detected");
  return release;
}
async function upgradePreflight(profile, dshRoot, expectedInstalledManifestSha256) {
  const p = profilePaths(profile), recordRaw = await regular(p.record), record = parseRecord(recordRaw);
  if (record.profile && !samePath(record.profile, profile)) {
    const recordedTarget = await fs.realpath(record.profile).catch(() => null);
    if (!recordedTarget || !samePath(recordedTarget, profile)) throw code("dsh_candidate_installed_target_mismatch");
  }
  if (record.dshRoot && !samePath(record.dshRoot, dshRoot)) {
    const recordedTarget = await fs.realpath(record.dshRoot).catch(() => null);
    if (!recordedTarget || !samePath(recordedTarget, dshRoot)) throw code("dsh_candidate_installed_target_mismatch");
  }
  const pkg = await profileFile(p.packageJson), patch = await readPatch(p.patch);
  assertProfilePackage(pkg); assertPatch(patch.raw);
  if (mergePatch(text(patch.raw), true) === null) throw code("dsh_candidate_drift_detected");
  const oldRelease = await installedRelease(p.destination, record, expectedInstalledManifestSha256), release = await trustedRelease();
  return { p, recordRaw, record, pkg, patch, oldRelease, release };
}
async function inspectUpgrade(profile, dshRoot, dshVersion, mode, expectedInstalledManifestSha256) {
  if (await exists(profilePaths(profile).journal)) throw code("dsh_candidate_recovery_required");
  const { record, release } = await upgradePreflight(profile, dshRoot, expectedInstalledManifestSha256);
  return { ok: true, applyRequired: true, mode, plannedMutation: "upgrade", profile, dshRoot, dshVersion, alreadyCurrent: record.manifestSha256 === release.manifestSha256 };
}
async function upgrade(profile, dshRoot, dshVersion, expectedInstalledManifestSha256, revalidateHost) {
  const { p, recordRaw, record, pkg, patch, oldRelease, release } = await upgradePreflight(profile, dshRoot, expectedInstalledManifestSha256);
  if (record.manifestSha256 === release.manifestSha256) return { ok: true, upgraded: false, alreadyCurrent: true, profile, dshRoot };
  if (await exists(p.backup) || await exists(p.stage)) throw code("dsh_candidate_recovery_required");
  await assertSafeWritePath(profile, p.stage);
  const nextRecord = { ...record, profile, dshRoot, dshVersion, packageJsonSha256: hash(pkg), installedPackageJsonSha256: release.manifest.packageFiles.find((item) => item.path === "package.json")?.sha256, packageFiles: release.manifest.packageFiles, manifestSha256: release.manifestSha256 };
  parseRecord(Buffer.from(JSON.stringify(nextRecord)));
  const nextRecordRaw = Buffer.from(`${JSON.stringify(nextRecord, null, 2)}\n`);
  const transaction = { ...journal("upgrade", p, patch, patch.raw.toString("utf8"), release, recordRaw), previousManifest: (await regular(path.join(p.destination, MANIFEST))).toString("utf8"), nextRecord: nextRecordRaw.toString("utf8"), nextRecordSha256: hash(nextRecordRaw), phase: "pending" };
  await writeJournal(p.journal, transaction);
  try {
    await fs.mkdir(p.stage); await copyTree(release.packageRoot, p.stage); await assertPackageTree(p.stage, release); await failpoint("upgrade-after-stage");
    await assertPackageTree(p.destination, oldRelease);
    if (hash(await regular(p.record)) !== hash(recordRaw)) throw code("dsh_candidate_drift_detected");
    await revalidateHost();
    // The existing Cordis entry and other profile settings stay byte-identical.
    await replacePatchCas(p.patch, patch.sha256, patch.raw);
    await fs.rename(p.destination, p.backup); await failpoint("upgrade-after-backup");
    await fs.rename(p.stage, p.destination); await failpoint("upgrade-after-destination");
    await assertPackageTree(p.destination, release);
    if (hash(await regular(p.record)) !== hash(recordRaw)) throw code("dsh_candidate_drift_detected");
    await atomic(p.record, nextRecordRaw); await failpoint("upgrade-after-record");
    // Before this durable commit, recovery restores the previous release.
    // After commit, recovery only finishes cleanup of the successful upgrade.
    await writeJournal(p.journal, { ...transaction, phase: "committed" });
  } catch (error) {
    try { await recover(profile, expectedInstalledManifestSha256); } catch (recoveryError) { error.recoveryCode = recoveryError.code || "dsh_candidate_recovery_required"; }
    throw error;
  }
  let cleanupPending = false;
  try { await recover(profile, expectedInstalledManifestSha256); } catch { cleanupPending = true; }
  return { ok: true, upgraded: true, profile, dshRoot, record: p.record, reloadRequired: true, ...(cleanupPending ? { cleanupPending: true } : {}) };
}

function profilePaths(profile) {
  const destination = path.join(profile, "node_modules", "hellolynk-dsh-nav");
  return Object.freeze({ profile, packageJson: path.join(profile, "package.json"), patch: path.join(profile, "cordis.patch.yml"), record: path.join(profile, RECORD), journal: path.join(profile, JOURNAL), destination, backup: `${destination}.rollback`, stage: `${destination}.upgrade-stage` });
}
function journal(operation, p, patch, nextPatch, release, record = null) {
  const value = { contract: "hellolynk-dsh-nav-transaction-v2", operation, patch: patch.raw.toString("utf8"), patchBeforeSha256: patch.sha256, patchAfterSha256: hash(Buffer.from(nextPatch)), destinationName: "node_modules/hellolynk-dsh-nav", backupName: "node_modules/hellolynk-dsh-nav.rollback", manifestSha256: release.manifestSha256 };
  return record == null ? value : { ...value, record: record.toString("utf8"), recordSha256: hash(record) };
}

async function trustedDescriptor() {
  let descriptor;
  try { descriptor = JSON.parse(text(await regular(RELEASE_DESCRIPTOR))); } catch { throw code("dsh_candidate_package_manifest_invalid"); }
  if (descriptor?.contract !== "hellolynk-dsh-nav-release-v1" || descriptor.packageManifest !== MANIFEST || !isHash(descriptor.manifestSha256)
    || !["contract,manifestSha256,packageManifest", "contract,manifestSha256,packageManifest,previousManifestSha256"].includes(Object.keys(descriptor).sort().join(","))
    || (Object.hasOwn(descriptor, "previousManifestSha256") && (!isHash(descriptor.previousManifestSha256) || descriptor.previousManifestSha256 === descriptor.manifestSha256))) throw code("dsh_candidate_package_manifest_invalid");
  return descriptor;
}
async function trustedRelease({ allowRecovery = false, manifestSha256 = null } = {}) {
  const descriptor = await trustedDescriptor();
  const expected = manifestSha256 || descriptor.manifestSha256;
  const previous = expected !== descriptor.manifestSha256;
  if (previous && (!allowRecovery || expected !== descriptor.previousManifestSha256)) throw code("dsh_candidate_release_not_approved");
  const candidates = previous ? [path.join(RECOVERY_RELEASES, expected)]
    : [PACKAGE, ...(allowRecovery ? [path.join(RECOVERY_RELEASES, expected)] : [])];
  for (const packageRoot of candidates) {
    let manifestRaw;
    try { manifestRaw = await regular(path.join(packageRoot, MANIFEST)); } catch (error) { if (error?.code === "ENOENT") continue; throw error; }
    if (hash(manifestRaw) !== expected) {
      if (!allowRecovery) throw code("dsh_candidate_release_not_approved");
      continue;
    }
    let manifest;
    try { manifest = JSON.parse(text(manifestRaw)); } catch { throw code("dsh_candidate_package_manifest_invalid"); }
    if (manifest?.contract !== "hellolynk-dsh-nav-build-v3" || !Array.isArray(manifest.packageFiles)) throw code("dsh_candidate_package_manifest_invalid");
    const release = Object.freeze({ manifest, manifestSha256: expected, packageRoot });
    await assertSafeDirectory(packageRoot);
    await assertPackageTree(packageRoot, release);
    return release;
  }
  throw code("dsh_candidate_package_manifest_invalid");
}

async function inspect(profile, mode, uninstalling, dshVersion) {
  const p = profilePaths(profile), record = uninstalling ? parseRecord(await regular(p.record)) : null;
  const release = await trustedRelease({ allowRecovery: uninstalling, manifestSha256: record?.manifestSha256 });
  const pkg = await profileFile(p.packageJson), patch = await readPatch(p.patch);
  assertProfilePackage(pkg); assertPatch(patch.raw);
  if (uninstalling) {
    if (record.manifestSha256 !== release.manifestSha256 || hash(await regular(path.join(p.destination, "package.json"))) !== record.installedPackageJsonSha256) throw code("dsh_candidate_drift_detected");
    await assertPackageTree(p.destination, release);
    if (mergePatch(text(patch.raw), true) === null) throw code("dsh_candidate_drift_detected");
  } else {
    if (await exists(p.record)) throw code("dsh_candidate_already_installed");
    if (await exists(p.destination)) throw code("dsh_candidate_destination_exists");
    mergePatch(text(patch.raw), false);
  }
  return { ok: true, applyRequired: true, mode, plannedMutation: uninstalling ? "uninstall" : "install", profile, ...(dshVersion ? { dshVersion } : {}) };
}
async function safeProfile(value, liveProfile) {
  const supplied = path.resolve(String(value || "")); if (!supplied || supplied === path.parse(supplied).root || supplied.includes("\0")) throw code("dsh_candidate_profile_required");
  await assertSafeDirectory(supplied, "dsh_candidate_profile_required");
  const profile = await fs.realpath(supplied).catch(() => { throw code("dsh_candidate_profile_required"); });
  const liveInput = path.resolve(os.homedir(), ".dsh", "profiles"), live = await fs.realpath(liveInput).catch(() => liveInput);
  const expectedLive = path.join(live, "desktop");
  if (liveProfile) {
    // The user's .dsh directory can be a drive-migration junction. The caller
    // must still supply its explicit canonical destination (checked above),
    // and only the current canonical desktop profile is accepted.
    await assertSafeDirectory(live, "dsh_candidate_live_profile_mismatch");
    if (!samePath(profile, expectedLive)) throw code("dsh_candidate_live_profile_mismatch");
    await assertSafeDirectory(profile);
    return Object.freeze({ profile, mode: "live" });
  }
  if (inside(live, profile)) throw code("dsh_candidate_live_profile_forbidden");
  await assertSafeDirectory(profile);
  const sentinel = await regular(path.join(profile, TEST_SENTINEL)).catch((error) => { throw error?.code === "ENOENT" ? code("dsh_candidate_test_profile_sentinel_required") : error; });
  if (text(sentinel).trim() !== "hellolynk-dsh-test-profile-v1") throw code("dsh_candidate_test_profile_sentinel_required");
  return Object.freeze({ profile, mode: "test" });
}
async function safeDshRoot(value) {
  const supplied = path.resolve(String(value || "")); if (!supplied || supplied === path.parse(supplied).root || supplied.includes("\0")) throw code("dsh_candidate_dsh_root_required");
  await assertSafeDirectory(supplied, "dsh_candidate_dsh_root_required");
  const root = await fs.realpath(supplied).catch(() => { throw code("dsh_candidate_dsh_root_required"); }); await assertSafeDirectory(root); return root;
}
function parse(argv) {
  const input = { profile: null, dshRoot: null, harnessRoot: null, apply: false, uninstall: false, upgrade: false, expectedInstalledManifestSha256: null, liveProfile: false, testProfile: false, help: false };
  const values = { "--profile": "profile", "--dsh-root": "dshRoot", "--harness-root": "harnessRoot", "--expected-installed-manifest-sha256": "expectedInstalledManifestSha256" };
  // The user's desktop profile is the default target. --live-profile stays accepted
  // for existing callers; --test-profile selects a marked test directory instead.
  const flags = { "--apply": "apply", "--uninstall": "uninstall", "--upgrade": "upgrade", "--live-profile": "liveProfile", "--test-profile": "testProfile", "--help": "help" };
  for (let i = 0; i < argv.length; i++) {
    const v = argv[i], key = Object.hasOwn(values, v) ? values[v] : null;
    if (key && i + 1 < argv.length && !String(argv[i + 1]).startsWith("--") && input[key] === null) input[key] = argv[++i];
    else if (Object.hasOwn(flags, v) && !input[flags[v]]) input[flags[v]] = true;
    else throw code("dsh_candidate_argument_invalid");
  }
  if (input.harnessRoot !== null) { if (input.dshRoot !== null) throw code("dsh_candidate_argument_invalid"); input.dshRoot = input.harnessRoot; }
  if (input.expectedInstalledManifestSha256 !== null && (!input.upgrade || !isHash(input.expectedInstalledManifestSha256))) throw code("dsh_candidate_argument_invalid");
  if (input.uninstall && input.upgrade) throw code("dsh_candidate_argument_invalid");
  if (input.liveProfile && input.testProfile) throw code("dsh_candidate_argument_invalid");
  input.liveProfile = !input.testProfile;
  if (!input.help && (!input.profile || !input.dshRoot)) throw code("dsh_candidate_installed_target_required");
  return input;
}
export async function assertDshVersion(root) {
  return (await captureDshIdentity(root)).version;
}
async function captureDshIdentity(root, harnessRequired = false) {
  root = await safeDshRoot(root);
  // Existing updater callers keep using --dsh-root. A Desktop root is read from
  // the package.json files in its ASAR; an unpacked root from its own package.json.
  if (harnessRequired || await exists(path.join(root, "resources", "app.asar"))) return inspectHarnessIdentity(root);
  let data, bytes; try { bytes = await regular(path.join(root, "package.json")); data = JSON.parse(text(bytes)); } catch { throw code("dsh_candidate_dsh_package_invalid"); }
  if (data?.name !== "@deepseek-ai/dsh" || !isSupportedDshVersion(data?.version)) throw code("dsh_candidate_dsh_version_unsupported");
  return { kind: "unpacked", root, version: data.version, packageSha256: hash(bytes) };
}
async function readExact(handle, length, position) {
  const bytes = Buffer.alloc(length);
  for (let done = 0; done < length;) {
    const result = await handle.read(bytes, done, length - done, position + done);
    if (!result.bytesRead) throw code("dsh_candidate_harness_package_invalid");
    done += result.bytesRead;
  }
  return bytes;
}
async function assertSameFile(filename, before) {
  const after = await fs.lstat(filename);
  if (!after.isFile() || after.isSymbolicLink() || after.nlink !== 1 || ["dev", "ino", "size", "mtimeMs", "ctimeMs"].some(key => after[key] !== before[key])) throw code("dsh_candidate_harness_changed");
}
export async function assertHarnessVersion(root) {
  return (await inspectHarnessIdentity(root)).version;
}
// The Harness is identified by the name and version in the package.json files
// inside its ASAR (read through the ASAR header), not by file digests.
async function inspectHarnessIdentity(root) {
  await assertSafeDirectory(root);
  const filename = path.join(root, "resources", "app.asar");
  await assertSafeDirectory(path.dirname(filename)).catch((error) => { throw error?.code === "ENOENT" ? code("dsh_candidate_harness_package_invalid") : error; });
  const before = await fs.lstat(filename).catch(() => { throw code("dsh_candidate_harness_package_invalid"); });
  if (!before.isFile() || before.isSymbolicLink() || before.nlink !== 1 || before.size < 16) throw code("dsh_candidate_harness_package_invalid");
  const handle = await fs.open(filename, "r");
  try {
    const opened = await handle.stat();
    if (["dev", "ino", "size"].some(key => opened[key] !== before[key])) throw code("dsh_candidate_harness_changed");
    const prefix = await readExact(handle, 16, 0), headerSize = prefix.readUInt32LE(4), jsonSize = prefix.readUInt32LE(12);
    if (prefix.readUInt32LE(0) !== 4 || headerSize < 8 || headerSize > 16 * 1024 * 1024 || prefix.readUInt32LE(8) !== headerSize - 4 || jsonSize < 2 || jsonSize > headerSize - 8 || 8 + headerSize > before.size) throw code("dsh_candidate_harness_package_invalid");
    const headerBytes = await readExact(handle, jsonSize, 16);
    let header; try { header = JSON.parse(headerBytes.toString("utf8")); } catch { throw code("dsh_candidate_harness_package_invalid"); }
    const packages = [["package.json", "@deepseek-ai/dsh-desktop"], ...["dsh", "dsh-desktop-host", "dsh-web-app"].map(name => [`dsh/node_modules/@deepseek-ai/${name}/package.json`, `@deepseek-ai/${name}`])];
    let version = null;
    for (const [relative, name] of packages) {
      let entry = header;
      for (const part of relative.split("/")) {
        if (entry?.link || !entry?.files || !Object.hasOwn(entry.files, part)) throw code("dsh_candidate_harness_package_invalid");
        entry = entry.files[part];
      }
      const offset = typeof entry?.offset === "string" && /^\d+$/.test(entry.offset) ? Number(entry.offset) : NaN;
      if (entry?.link || entry?.unpacked || entry?.files || !Number.isSafeInteger(offset) || offset < 0 || !Number.isSafeInteger(entry.size) || entry.size < 2 || entry.size > 128 * 1024 || 8 + headerSize + offset + entry.size > before.size || entry.integrity?.algorithm !== "SHA256" || !isHash(entry.integrity.hash)) throw code("dsh_candidate_harness_package_invalid");
      const bytes = await readExact(handle, entry.size, 8 + headerSize + offset);
      if (hash(bytes) !== entry.integrity.hash) throw code("dsh_candidate_harness_package_invalid");
      let data; try { data = JSON.parse(bytes.toString("utf8")); } catch { throw code("dsh_candidate_harness_package_invalid"); }
      if (data === null || typeof data !== "object" || Array.isArray(data)) throw code("dsh_candidate_harness_package_invalid");
      if (data.name !== name) throw code("dsh_candidate_harness_package_invalid");
      if (!isSupportedDshVersion(data.version)) throw code("dsh_candidate_dsh_version_unsupported");
      if (relative === "package.json") version = data.version;
    }
    await assertSameFile(filename, before);
    return { kind: "harness", root, version,
      asarStat: Object.fromEntries(["dev", "ino", "size", "mtimeMs", "ctimeMs"].map(key => [key, before[key]])) };
  } finally { await handle.close(); }
}
function assertProfilePackage(value) { let data; try { data = JSON.parse(text(value)); } catch { throw code("dsh_candidate_profile_package_invalid"); } const bundles = data?.dsh?.profile?.bundles; if (!Array.isArray(bundles) || !bundles.includes("@deepseek-ai/dsh-web-app")) throw code("dsh_candidate_web_profile_required"); }
function assertPatch(value) { parsePatch(text(value)); }
async function regular(target) { const meta = await fs.lstat(target); if (!meta.isFile() || meta.isSymbolicLink()) throw code("dsh_candidate_target_invalid"); return fs.readFile(target); }
// A profile directory without package.json or cordis.patch.yml is not a usable profile.
const profileFile = (target) => regular(target).catch((error) => { throw error?.code === "ENOENT" ? code("dsh_candidate_profile_required") : error; });
async function readPatch(target) { const raw = await profileFile(target); return Object.freeze({ raw, sha256: hash(raw) }); }
async function exists(target) { try { await fs.lstat(target); return true; } catch { return false; } }
async function copyTree(source, target) { for (const entry of await fs.readdir(source, { withFileTypes: true })) { const from = path.join(source, entry.name), to = path.join(target, entry.name), meta = await fs.lstat(from); if (meta.isDirectory() && !meta.isSymbolicLink()) await copyTree(from, to); else if (meta.isFile() && !meta.isSymbolicLink()) { await fs.mkdir(path.dirname(to), { recursive: true }); await fs.copyFile(from, to, fs.constants.COPYFILE_EXCL); } else throw code("dsh_candidate_package_invalid"); } }
async function assertPackageTree(root, release) { await assertSafeDirectory(root); const expected = recordsMap(release.manifest.packageFiles); expected.set(MANIFEST, release.manifestSha256); const actual = await actualTree(root); if (actual.size !== expected.size) throw code("dsh_candidate_drift_detected"); for (const [relative, digest] of expected) if (actual.get(relative) !== digest) throw code("dsh_candidate_drift_detected"); }
function recordsMap(records) { if (!Array.isArray(records) || records.length < 1 || records.length > 4096) throw code("dsh_candidate_package_manifest_invalid"); const map = new Map(); for (const record of records) { if (!record || typeof record.path !== "string" || !/^[A-Za-z0-9._/-]+$/.test(record.path) || record.path.split("/").some((x) => !x || x === "." || x === "..") || !isHash(record.sha256) || record.path === MANIFEST || map.has(record.path)) throw code("dsh_candidate_package_manifest_invalid"); map.set(record.path, record.sha256); } return map; }
async function actualTree(root, prefix = "") { const found = new Map(); for (const entry of await fs.readdir(root, { withFileTypes: true })) { const relative = `${prefix}${entry.name}`, target = path.join(root, entry.name), meta = await fs.lstat(target); if (meta.isSymbolicLink()) throw code("dsh_candidate_reparse_path_rejected"); if (meta.isDirectory()) for (const [name, digest] of await actualTree(target, `${relative}/`)) found.set(name, digest); else if (meta.isFile()) found.set(relative, hash(await fs.readFile(target))); else throw code("dsh_candidate_drift_detected"); } return found; }
async function atomic(target, body) { await assertSafeWritePath(path.dirname(target), target); const temp = `${target}.${process.pid}.${crypto.randomBytes(6).toString("hex")}.tmp`; await fs.writeFile(temp, body, { flag: "wx", mode: 0o600 }); await fs.rename(temp, target); }
async function replacePatchCas(target, expectedHash, next) {
  if (process.platform !== "win32") throw code("dsh_candidate_patch_lock_unavailable");
  const payload = Buffer.from(JSON.stringify({ path: target, expectedHash, next: Buffer.from(next).toString("base64") })).toString("base64");
  const script = `
$Payload = "${payload}"
$r = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($Payload)) | ConvertFrom-Json
$s = $null
function Digest([byte[]]$Value) { $h = [Security.Cryptography.SHA256]::Create(); try { return ([BitConverter]::ToString($h.ComputeHash($Value))).Replace("-", "").ToLowerInvariant() } finally { $h.Dispose() } }
try {
  $s = [IO.File]::Open([string]$r.path, [IO.FileMode]::Open, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
  $m = [IO.MemoryStream]::new(); $s.CopyTo($m); $before = $m.ToArray()
  $actual = Digest $before
  if ($actual -cne [string]$r.expectedHash) { exit 41 }
  if ($env:HELLOLYNK_DSH_CAS_READY_FILE) { [IO.File]::WriteAllText($env:HELLOLYNK_DSH_CAS_READY_FILE, "locked") }
  if ($env:HELLOLYNK_DSH_CAS_PAUSE_MS) { Start-Sleep -Milliseconds ([int]$env:HELLOLYNK_DSH_CAS_PAUSE_MS) }
  $after = [Convert]::FromBase64String([string]$r.next)
  if ((Digest $after) -ceq $actual) { exit 0 }
  $s.Position = 0; $s.SetLength(0); $s.Write($after, 0, $after.Length); $s.Flush($true)
  $s.Position = 0; $m = [IO.MemoryStream]::new(); $s.CopyTo($m)
  if ((Digest $m.ToArray()) -cne (Digest $after)) { exit 42 }
} catch [IO.IOException] { exit 43 } finally { if ($null -ne $s) { $s.Dispose() } }
`;
  try {
    await execFileAsync(process.env.SystemRoot ? path.join(process.env.SystemRoot, "System32", "WindowsPowerShell", "v1.0", "powershell.exe") : "powershell.exe", ["-NoLogo", "-NoProfile", "-NonInteractive", "-EncodedCommand", Buffer.from(script, "utf16le").toString("base64")]);
  } catch (error) {
    if (error?.code === 41 || error?.code === 42) throw code("dsh_candidate_patch_concurrent_modification");
    throw code("dsh_candidate_patch_lock_unavailable");
  }
}
async function writeJournal(target, value) { await atomic(target, Buffer.from(`${JSON.stringify(value, null, 2)}\n`)); }
function parseRecord(raw) { let value; try { value = JSON.parse(text(raw)); } catch { throw code("dsh_candidate_record_invalid"); } if (value?.contract !== "hellolynk-dsh-nav-install-v4" || !isHash(value.installedPackageJsonSha256) || !isHash(value.manifestSha256) || !isHash(value.patchBeforeSha256) || !isHash(value.patchAfterSha256)) throw code("dsh_candidate_record_invalid"); return value; }

async function recover(profile, expectedInstalledManifestSha256) {
  const p = profilePaths(profile); if (!await exists(p.journal)) return;
  let value; try { value = JSON.parse(text(await regular(p.journal))); } catch { throw code("dsh_candidate_journal_invalid"); }
  validateJournal(value, p); const release = await trustedRelease({ allowRecovery: true, manifestSha256: value.manifestSha256 }); if (value.manifestSha256 !== release.manifestSha256) throw code("dsh_candidate_recovery_required");
  if (value.operation === "upgrade") { await recoverUpgrade(p, value, release, expectedInstalledManifestSha256); return; }
  const patch = await readPatch(p.patch); if (patch.sha256 !== value.patchBeforeSha256 && patch.sha256 !== value.patchAfterSha256) throw code("dsh_candidate_patch_concurrent_modification");
  if (value.operation === "install") {
    if (await exists(p.record)) {
      const record = parseRecord(await regular(p.record));
      if (record.manifestSha256 !== release.manifestSha256) throw code("dsh_candidate_recovery_required");
    }
    if (await exists(p.destination)) await assertPartialTree(p.destination, release);
    if (await exists(p.record)) await fs.rm(p.record, { force: false });
    if (await exists(p.destination)) await fs.rm(p.destination, { recursive: true, force: false });
  }
  else await recoverUninstall(p, value, release);
  if (patch.sha256 === value.patchAfterSha256) await replacePatchCas(p.patch, value.patchAfterSha256, Buffer.from(value.patch));
  await fs.rm(p.journal, { force: false });
}
async function assertPartialTree(root, release, allowPartialCopy = false) {
  await assertSafeDirectory(root);
  const expected = recordsMap(release.manifest.packageFiles); expected.set(MANIFEST, release.manifestSha256);
  const actual = await actualTree(root);
  for (const [relative, digest] of actual) {
    if (!expected.has(relative)) throw code("dsh_candidate_drift_detected");
    if (digest === expected.get(relative)) continue;
    // A killed copy may leave the last file partially written. Accept only
    // a byte prefix of the fixed trusted source, never arbitrary stage data.
    if (!allowPartialCopy) throw code("dsh_candidate_drift_detected");
    const bytes = await regular(path.join(root, relative)), source = await regular(path.join(release.packageRoot, relative));
    if (bytes.length > source.length || !bytes.equals(source.subarray(0, bytes.length))) throw code("dsh_candidate_drift_detected");
  }
  return actual;
}
async function recoverUpgrade(p, value, release, expectedInstalledManifestSha256) {
  const oldRecord = parseRecord(Buffer.from(value.record));
  const oldRelease = await recordedRelease(oldRecord, Buffer.from(value.previousManifest), expectedInstalledManifestSha256);
  await recordedRelease(parseRecord(Buffer.from(value.nextRecord)), await regular(path.join(release.packageRoot, MANIFEST)));
  const patch = await readPatch(p.patch);
  // Upgrade never changes the patch, so concurrent unrelated edits remain.
  if (mergePatch(text(patch.raw), true) === null) throw code("dsh_candidate_patch_concurrent_modification");
  const currentRecord = hash(await regular(p.record));
  if (![value.recordSha256, value.nextRecordSha256].includes(currentRecord)) throw code("dsh_candidate_recovery_required");
  if (value.phase === "committed") {
    if (currentRecord !== value.nextRecordSha256) throw code("dsh_candidate_recovery_required");
    await assertPackageTree(p.destination, release);
    if (await exists(p.backup)) { await assertPartialTree(p.backup, oldRelease); await fs.rm(p.backup, { recursive: true, force: false }); }
  } else if (await exists(p.backup)) {
    await assertPackageTree(p.backup, oldRelease);
    if (await exists(p.destination)) { await assertPartialTree(p.destination, release); await fs.rm(p.destination, { recursive: true, force: false }); }
    await assertSafeWritePath(p.profile, p.destination);
    await fs.rename(p.backup, p.destination);
    await atomic(p.record, Buffer.from(value.record));
  } else {
    await assertPackageTree(p.destination, oldRelease);
    if (currentRecord !== value.recordSha256) await atomic(p.record, Buffer.from(value.record));
  }
  if (await exists(p.stage)) { await assertPartialTree(p.stage, release, true); await fs.rm(p.stage, { recursive: true, force: false }); }
  await fs.rm(p.journal, { force: false });
}
async function recoverUninstall(p, value, release) {
  const destination = await exists(p.destination), backup = await exists(p.backup); if (destination && backup) throw code("dsh_candidate_recovery_required");
  if (await exists(p.record) && hash(await regular(p.record)) !== value.recordSha256) throw code("dsh_candidate_recovery_required");
  if (backup) { await assertPartialTree(p.backup, release); await assertSafeWritePath(p.profile, p.destination); await fs.rename(p.backup, p.destination); }
  // Deletion can stop halfway through the owned backup. A previous recovery
  // can also stop mid-copy. Validate every survivor before filling gaps from
  // the pinned release; arbitrary bytes and unlisted files are never repaired.
  const actual = await exists(p.destination) ? await assertPartialTree(p.destination, release, true) : new Map();
  const expected = recordsMap(release.manifest.packageFiles); expected.set(MANIFEST, release.manifestSha256);
  for (const [relative, digest] of expected) {
    if (actual.get(relative) === digest) continue;
    const source = await regular(path.join(release.packageRoot, relative));
    if (hash(source) !== digest) throw code("dsh_candidate_drift_detected");
    const target = path.join(p.destination, relative);
    await fs.mkdir(path.dirname(target), { recursive: true }); await assertSafeWritePath(p.profile, target);
    // Remove the authenticated incomplete entry rather than mutate its inode.
    // Either a missing file or a new partial prefix remains recoverable.
    if (actual.has(relative)) await fs.rm(target, { force: false });
    await fs.writeFile(target, source, { flag: "wx" });
  }
  await assertPackageTree(p.destination, release);
  if (await exists(p.record)) { if (hash(await regular(p.record)) !== value.recordSha256) throw code("dsh_candidate_recovery_required"); } else await atomic(p.record, Buffer.from(value.record));
}
function validateJournal(v, p) {
  if (!v || v.contract !== "hellolynk-dsh-nav-transaction-v2" || !["install", "uninstall", "upgrade"].includes(v.operation) || typeof v.patch !== "string" || !isHash(v.patchBeforeSha256) || !isHash(v.patchAfterSha256) || !isHash(v.manifestSha256) || v.destinationName !== "node_modules/hellolynk-dsh-nav" || v.backupName !== "node_modules/hellolynk-dsh-nav.rollback" || hash(Buffer.from(v.patch)) !== v.patchBeforeSha256) throw code("dsh_candidate_journal_invalid");
  if (["uninstall", "upgrade"].includes(v.operation) && (typeof v.record !== "string" || !isHash(v.recordSha256) || hash(Buffer.from(v.record)) !== v.recordSha256)) throw code("dsh_candidate_journal_invalid");
  if (v.operation === "upgrade") {
    if (!["pending", "committed"].includes(v.phase) || typeof v.previousManifest !== "string" || typeof v.nextRecord !== "string" || !isHash(v.nextRecordSha256) || hash(Buffer.from(v.nextRecord)) !== v.nextRecordSha256 || v.patchBeforeSha256 !== v.patchAfterSha256) throw code("dsh_candidate_journal_invalid");
    const before = parseRecord(Buffer.from(v.record)), after = parseRecord(Buffer.from(v.nextRecord));
    if (before.manifestSha256 === v.manifestSha256 || after.manifestSha256 !== v.manifestSha256 || hash(Buffer.from(v.previousManifest)) !== before.manifestSha256) throw code("dsh_candidate_journal_invalid");
  }
  if (v.operation === "uninstall") {
    let record;
    try { record = parseRecord(Buffer.from(v.record)); } catch { throw code("dsh_candidate_journal_invalid"); }
    if (record.manifestSha256 !== v.manifestSha256) throw code("dsh_candidate_journal_invalid");
  }
  if (!inside(p.profile, p.destination) || !inside(p.profile, p.backup)) throw code("dsh_candidate_journal_invalid");
}
// Cordis accepts a top-level YAML sequence. This deliberately constrained,
// no-code parser preserves every third-party node byte-for-byte and only
// recognizes the exact node emitted below. Unsupported YAML shapes fail closed
// instead of importing executable parser code from the user's DSH installation.
function parsePatch(value) {
  const lines = value.split("\n"); if (lines.at(-1) === "") lines.pop();
  const content = lines.filter((line) => line.trim() && !line.trimStart().startsWith("#"));
  if (!content.length) throw code("dsh_candidate_patch_invalid");
  const emptyAt = lines.findIndex((line) => line.trim() === "[]");
  if (emptyAt >= 0 && content.length !== 1) throw code("dsh_candidate_patch_invalid");
  if (emptyAt < 0 && !content.some((line) => /^-\s+/.test(line))) throw code("dsh_candidate_patch_invalid");
  if (emptyAt < 0 && content.some((line) => !/^-\s+/.test(line) && !/^\s+/.test(line))) throw code("dsh_candidate_patch_invalid");
  const starts = []; for (let index = 0; index < lines.length; index++) if (/^-\s+/.test(lines[index])) starts.push(index);
  if (emptyAt >= 0) return { lines, emptyAt, items: [] };
  if (!starts.length) throw code("dsh_candidate_patch_invalid");
  return { lines, emptyAt: -1, items: starts.map((start, index) => ({ start, end: index + 1 < starts.length ? starts[index + 1] : lines.length })) };
}
function ownPatchItem(lines, item) {
  const body = lines.slice(item.start, item.end).filter((line) => line.trim() && !line.trimStart().startsWith("#")).join("\n").trimEnd();
  return body === "- insert:\n    - id: hellolynk-dsh-nav\n      name: hellolynk-dsh-nav";
}
function mergePatch(value, remove) {
  const doc = parsePatch(value), own = doc.items.filter((item) => ownPatchItem(doc.lines, item));
  if (!remove) {
    if (own.length) throw code("dsh_candidate_patch_entry_exists");
    const node = ["- insert:", "    - id: hellolynk-dsh-nav", "      name: hellolynk-dsh-nav"];
    if (doc.emptyAt >= 0) doc.lines.splice(doc.emptyAt, 1, ...node);
    else doc.lines.push(...node);
    return `${doc.lines.join("\n")}\n`;
  }
  if (own.length !== 1) return null;
  const restoredEmptyAt = own[0].start;
  doc.lines.splice(own[0].start, own[0].end - own[0].start);
  const remainingContent = doc.lines.filter((line) => line.trim() && !line.trimStart().startsWith("#"));
  if (!remainingContent.length) doc.lines.splice(Math.min(restoredEmptyAt, doc.lines.length), 0, "[]");
  return `${doc.lines.join("\n").replace(/\n+$/u, "")}\n`;
}
// Called only inside the OS guard, including stale recovery and release.
async function acquireLock(profile) {
  const target = path.join(profile, ".hellolynk-dsh-nav.lock");
  const ownershipToken = crypto.randomBytes(32).toString("hex");
  const candidate = `${target}.${process.pid}.${ownershipToken}.candidate`;
  const record = { contract: "hellolynk-dsh-nav-lock-v1", pid: process.pid, startedAt: Date.now(), ownershipToken };
  let handle;
  try {
    handle = await fs.open(candidate, "wx", 0o600);
    await handle.writeFile(JSON.stringify(record));
    await handle.sync();
    await handle.close(); handle = null;
    try { await fs.link(candidate, target); }
    catch (error) {
      if (error?.code !== "EEXIST") throw error;
      const meta = await fs.lstat(target);
      if (!meta.isFile() || meta.isSymbolicLink() || meta.size > 4096 || Date.now() - Number(meta.mtimeMs) < LOCK_STALE_MS) {
        throw code("dsh_candidate_concurrent_operation");
      }
      const stale = JSON.parse(text(await regular(target)));
      if (stale?.contract !== "hellolynk-dsh-nav-lock-v1" || !Number.isSafeInteger(stale.pid) || stale.pid < 1
        || !Number.isSafeInteger(stale.startedAt) || stale.startedAt < 1) throw code("dsh_candidate_concurrent_operation");
      try { process.kill(stale.pid, 0); throw code("dsh_candidate_concurrent_operation"); }
      catch (probe) {
        // Access denied and unknown probe failures do not prove an owner dead.
        if (probe?.code !== "ESRCH") throw code("dsh_candidate_concurrent_operation");
      }
      await fs.unlink(target);
      await fs.link(candidate, target);
    }
    return Object.freeze({ target, ownershipToken });
  } finally {
    await handle?.close().catch(() => {});
    // Publication is the commit point; candidate cleanup cannot revoke it.
    await fs.unlink(candidate).catch(() => {});
  }
}
async function releaseLock(lock) {
  if (!lock?.target) return;
  let current;
  try {
    const meta = await fs.lstat(lock.target);
    if (!meta.isFile() || meta.isSymbolicLink() || meta.size > 4096) throw code("dsh_candidate_lock_ownership_lost");
    current = JSON.parse(text(await regular(lock.target)));
  } catch (error) { if (error?.code === "ENOENT") return; throw error; }
  if (current?.ownershipToken !== lock.ownershipToken || current?.pid !== process.pid) throw code("dsh_candidate_lock_ownership_lost");
  await fs.unlink(lock.target);
}
// A directory that does not exist reports missingCode when given, otherwise the raw ENOENT.
async function assertSafeDirectory(target, missingCode = null) { const resolved = path.resolve(target), parsed = path.parse(resolved); let cursor = parsed.root; for (const part of path.relative(parsed.root, resolved).split(path.sep).filter(Boolean)) { cursor = path.join(cursor, part); const meta = await fs.lstat(cursor).catch((error) => { throw missingCode && error?.code === "ENOENT" ? code(missingCode) : error; }); if (!meta.isDirectory() || meta.isSymbolicLink()) throw code("dsh_candidate_reparse_path_rejected"); } }
async function assertSafeWritePath(profile, target) { if (!inside(profile, target)) throw code("dsh_candidate_reparse_path_rejected"); await assertSafeDirectory(path.dirname(target)); }
function inside(root, target) { const a = path.resolve(root).toLowerCase(), b = path.resolve(target).toLowerCase(); return b === a || b.startsWith(`${a}${path.sep}`); }
function samePath(left, right) { return path.resolve(left).toLowerCase() === path.resolve(right).toLowerCase(); }
function isHash(value) { return typeof value === "string" && /^[a-f0-9]{64}$/.test(value); }
async function failpoint(name) { if (process.env.HELLOLYNK_DSH_FAIL_AFTER === name) throw code(`dsh_candidate_fault_${name}`); }
function text(value) { return Buffer.from(value).toString("utf8").replace(/\r\n?/g, "\n"); }
function hash(value) { return crypto.createHash("sha256").update(value).digest("hex"); }
function code(value) { const error = new Error(value); error.code = value; return error; }
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const argv = process.argv.slice(2);
  (argv.length ? installDshCandidate(argv) : Promise.resolve({ help: true }))
    .then((value) => process.stdout.write(value.help ? installHelpText() : `${JSON.stringify(value)}\n`))
    .catch((error) => { process.stderr.write(dshFailureOutput(error)); process.exitCode = 1; });
}

function installHelpText() {
  const run = dshCommand();
  const target = dshText("--profile <profile 目录> --harness-root <Harness 目录>", "--profile <profile folder> --harness-root <Harness folder>");
  return `${[dshText("HelloLynk for DSH（Windows，Node.js 22.16.0+）", "HelloLynk for DSH (Windows, Node.js 22.16.0+)"),
    `${dshText("预览：", "Preview: ")}${run} ${target}`,
    `${dshText("安装：", "Install: ")}${run} ${target} --apply`,
    `${dshText("更新：", "Update: ")}${run} ${target} --upgrade --expected-installed-manifest-sha256 ${dshText("<当前安装摘要>", "<installed digest>")} --apply`,
    `${dshText("卸载：", "Uninstall: ")}${run} ${target} --uninstall --apply`].join("\n")}\n`;
}

export function dshText(zh, en) { return /^zh\b/i.test(Intl.DateTimeFormat().resolvedOptions().locale) ? zh : en; }

export function dshCommand() {
  const script = path.resolve(process.argv[1]), relative = path.relative(process.cwd(), script);
  const shown = relative && !relative.startsWith("..") && !path.isAbsolute(relative) ? relative : script;
  return `node ${/\s/.test(shown) ? `"${shown}"` : shown}`;
}

// A person reads the code, then what to do; a program reads the code alone.
export function dshFailureOutput(error, json = false) {
  const failure = String(error?.code || error?.message || "dsh_setup_failed");
  if (process.stdout.isTTY === true) return `${failure}\n${dshFailureReason(failure)}\n`;
  return json ? `${JSON.stringify({ ok: false, error: failure })}\n` : `${failure}\n`;
}

function dshFailureReason(code) {
  if (code === "hellolynk_node_22_16_required") return dshText("需要 Node.js 22.16 或更高版本。", "Node.js 22.16 or later is required.");
  if (/_argument(?:_value_required|_invalid)$|^dsh_command_invalid$|^dsh_candidate_(?:installed_target|profile|dsh_root)_required$/.test(code)) {
    return dshText("命令或参数不对。运行 --help 查看用法。", "The command or its arguments are not valid. Run --help to see usage.");
  }
  if (code === "dsh_candidate_dsh_version_unsupported") {
    return dshText(`需要 DeepSeek Harness ${DSH_SUPPORTED_RANGE}。`, `DeepSeek Harness ${DSH_SUPPORTED_RANGE} is required.`);
  }
  if (/^dsh_candidate_(?:harness|dsh)_package_invalid$/.test(code)) {
    return dshText("没有找到 DeepSeek Harness。用 --harness-root 指定它的安装目录。", "DeepSeek Harness was not found. Give its folder with --harness-root.");
  }
  if (/^dsh_candidate_(?:concurrent_operation|patch_lock_unavailable|lock_ownership_lost)$/.test(code)) {
    return dshText("另一个安装或卸载正在进行。等它结束后再运行一次。", "Another install or uninstall is running. Run this again when it finishes.");
  }
  if (/^dsh_candidate_(?:already_installed|existing_release_requires_upgrade)$/.test(code)) {
    return dshText("HelloLynk 已经装在 DSH 里，会自动更新。", "HelloLynk is already installed in DSH and updates itself.");
  }
  if (/^dsh_candidate_(?:package_manifest|package|profile_package)_invalid$|_release_not_approved$/.test(code)) {
    return dshText("安装包不完整或被改动过。请重新下载。", "The package is incomplete or was changed. Download it again.");
  }
  if (code === "dsh_candidate_reparse_path_rejected") {
    return dshText("目录是联接点。改用它指向的真实目录。", "A folder is a junction. Use the real folder it points to.");
  }
  if (/^dsh_candidate_(?:host|harness)_changed$|^dsh_candidate_patch_concurrent_modification$/.test(code)) {
    return dshText("运行期间 DSH 的文件被改动了。关闭 DSH 后再运行一次。", "DSH's files changed while this ran. Close DSH, then run this again.");
  }
  return dshText("没有完成。处理方法见 README.md。", "This did not complete. See README.md.");
}
