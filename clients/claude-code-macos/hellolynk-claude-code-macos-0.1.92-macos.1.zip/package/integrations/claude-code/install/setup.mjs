import fs from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { assertClaudeCodePackagePlatform, installClaudeCodeCandidate, verifyClaudeCodeCandidate, verifyClaudeCodePreviousRelease, claudeCodeReleaseRoot, verifyClaudeCodePackage } from './candidate-install.mjs';
import { createHostProtectedStore, defaultClaudeCodeStoreRoot } from '../../../runtime/core/hellolynk-host-protected-store.mjs';
import { resolveClientAccountRoot, assertClientAccountCurrent } from '../../../runtime/core/hellolynk-client-account.mjs';
import runtimeSafety from '../../../runtime/core/hellolynk-runtime-safety.cjs';
import { withLocalProcessLock } from '../../../runtime/core/hellolynk-local-process-lock.mjs';
import { MAC_CLIENT_VERSION } from '../../../runtime/core/hellolynk-client-update.mjs';
import { pruneInstalledReleases, protectRetentionReceipt, removeInstalledReleases } from '../../../runtime/core/hellolynk-release-retention.mjs';
import { switchClaudeNativeTaskService, startRecordedClaudeNativeTaskService, configureClaudeNativeTaskService } from '../server/native-task-service.mjs';
import { readClaudeCodeCurrentRelease } from './stable-entry.mjs';

const execute = promisify(execFile);
const failure = code => Object.assign(new Error(code), { code });
const plain = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const same = (a, b) => a === null ? b === null : b !== null && a.equals(b);
const skillRelative = 'integrations/claude-code/skills/hellolynk-open/SKILL.md';
const entryRelative = 'integrations/claude-code/install/stable-entry.mjs';
const modFiles = ['plugin.json', 'hooks/hooks.json', 'hooks/receive.js'];
const entryPath = currentRoot => path.join(currentRoot, 'claude-code', 'hellolynk-claude-code.mjs');
const currentReleasePath = currentRoot => path.join(currentRoot, 'claude-code', 'current-release.json');
const parsed = bytes => { try { return bytes === null ? undefined : JSON.parse(bytes.toString('utf8').replace(/^\uFEFF/, '')); } catch { return undefined; } };
// Installer output follows the system language.
export const CHINESE = /^zh\b/i.test(Intl.DateTimeFormat().resolvedOptions().locale);

function originalSessionConfig(currentRoot) {
  return Buffer.from(`${JSON.stringify(mcpFor(currentRoot, 'original-session'), null, 2)}\n`);
}
// Installers before the stable entry named the release and its pin here.
function legacyOriginalSessionConfig(currentRoot, pin) {
  const command = legacyMcpFor(currentRoot, pin);
  command.args[1] = 'original-session';
  return Buffer.from(`${JSON.stringify(command, null, 2)}\n`);
}
function stableReceiver(bytes, currentRoot) {
  const server = parsed(bytes);
  return plain(server) && Object.keys(server).sort().join(',') === 'args,command' && stableServer(server, currentRoot, 'original-session');
}
async function prepareOriginalSessionMod({ home, candidateRoot, currentRoot, previous }) {
  // Claude's native skills-dir plugin loader; no extra MCP server or provider.
  const root = path.join(home, '.claude/skills/hellolynk-receive');
  const oldRoot = previous?.release?.releaseRoot;
  // Files there are ours only when the previous release shipped this mod.
  const oldMod = Boolean(oldRoot) && await snapshot(path.join(oldRoot, 'integrations/claude-code/mod/plugin.json')) !== null;
  const changes = [];
  for (const name of modFiles) {
    const target = path.join(root, name === 'plugin.json' ? '.claude-plugin/plugin.json' : name);
    const relative = `integrations/claude-code/mod/${name}`;
    const next = await snapshot(path.join(candidateRoot, relative));
    if (next === null) throw failure('claude_code_install_mod_missing');
    const old = await snapshot(target);
    const owned = oldMod ? await snapshot(path.join(oldRoot, relative)) : null;
    if (old !== null && !same(old, next) && !same(old, owned)) throw failure('claude_code_install_mod_conflict');
    changes.push({ target, old, next });
  }
  const target = path.join(root, 'receiver.json'), old = await snapshot(target);
  // A receiver.json that already names the stable entry keeps the node it was written with.
  const next = stableReceiver(old, currentRoot) ? old : originalSessionConfig(currentRoot);
  if (old !== null && !same(old, next) && !(oldMod && (previous.stable ? stableReceiver(old, previous.currentRoot)
    : same(old, legacyOriginalSessionConfig(previous.currentRoot, previous.release.manifestSha256))))) throw failure('claude_code_install_mod_conflict');
  changes.push({ target, old, next });
  return { root, changes };
}

export async function assertClaudeClosed() {
  if (process.platform === 'darwin') {
    let stdout;
    try {
      ({ stdout } = await execute('/bin/ps', ['-ww', '-x', '-o', 'comm='], { timeout: 15000, maxBuffer: 4 * 1024 * 1024 }));
    } catch { throw failure('claude_code_install_process_check_failed'); }
    if (stdout.split('\n').some(line => /^claude(?:$|[- ]helper\b|-[\w.-]+$)/i.test(path.basename(line.trim())))) {
      throw failure('claude_code_install_close_claude_required');
    }
    return;
  }
  // Return only a boolean. No command lines, environments or credential fields.
  let result;
  try {
    result = await execute('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-Command', "$ErrorActionPreference='Stop'; if (@(Get-Process | Where-Object { $_.ProcessName -match '^claude(?:-.*)?$' }).Count -eq 0) { 'closed' } else { 'running' }"], { windowsHide: true, timeout: 15000, maxBuffer: 1024 });
  } catch { throw failure('claude_code_install_process_check_failed'); }
  if (result.stdout.trim() !== 'closed') throw failure('claude_code_install_close_claude_required');
}

async function safeParents(target) {
  for (let current = path.dirname(target); ; current = path.dirname(current)) {
    const stat = await fs.lstat(current).catch(error => { if (error.code === 'ENOENT') return null; throw error; });
    if (stat && (!stat.isDirectory() || stat.isSymbolicLink())) throw failure('claude_code_install_path_invalid');
    if (path.dirname(current) === current) break;
  }
}
async function snapshot(target) {
  await safeParents(target);
  try {
    const stat = await fs.lstat(target);
    if (!stat.isFile() || stat.isSymbolicLink() || stat.nlink !== 1 || stat.size > 4 * 1024 * 1024) throw failure('claude_code_install_file_invalid');
    return await fs.readFile(target);
  } catch (error) { if (error.code === 'ENOENT') return null; throw error; }
}
async function unchanged(target, previous) {
  if (!same(await snapshot(target), previous)) throw failure('claude_code_install_config_changed');
}
async function replace(target, bytes, previous, checkClosed) {
  await checkClosed();
  await unchanged(target, previous);
  await fs.mkdir(path.dirname(target), { recursive: true });
  await safeParents(target);
  const temporary = `${target}.hellolynk-${crypto.randomUUID()}.tmp`;
  try {
    await fs.writeFile(temporary, bytes, { flag: 'wx', mode: 0o600 });
    await checkClosed();
    await unchanged(target, previous);
    await fs.rename(temporary, target);
  } finally { await fs.unlink(temporary).catch(error => { if (error.code !== 'ENOENT') throw error; }); }
}

export async function discoverClaudeDesktopConfig({ desktopConfig, env = process.env, installedRoot, home = os.homedir(), platform = process.platform } = {}) {
  if (desktopConfig !== undefined) {
    if (!path.isAbsolute(desktopConfig) || path.basename(desktopConfig).toLowerCase() !== 'claude_desktop_config.json') throw failure('claude_code_install_desktop_path_invalid');
    await safeParents(desktopConfig);
    if (!(await fs.lstat(path.dirname(desktopConfig))).isDirectory()) throw failure('claude_code_install_desktop_path_invalid');
    return path.resolve(desktopConfig);
  }
  const directories = platform === 'darwin' ? [path.join(home, 'Library', 'Application Support', 'Claude')]
    : [env.APPDATA && path.join(env.APPDATA, 'Claude'), env.LOCALAPPDATA && path.join(env.LOCALAPPDATA, 'Claude-3p')].filter(Boolean);
  const migrated = new Set();
  // Store-installed Claude keeps its actual roaming config in the MSIX
  // package cache. The normal APPDATA directory may not exist at all.
  if (platform !== 'darwin' && env.LOCALAPPDATA) {
    // New Desktop versions migrate Store profiles into Claude-Data. Discover
    // them without moving data or choosing between multiple live profiles.
    const dataRoot = path.join(env.LOCALAPPDATA, 'Claude-Data');
    const profiles = await fs.readdir(dataRoot, { withFileTypes: true }).catch(error => {
      if (error.code === 'ENOENT') return []; throw error;
    });
    for (const entry of profiles) {
      if (!/^claude_[a-z0-9]+$/i.test(entry.name)) continue;
      if (!entry.isDirectory() || entry.isSymbolicLink()) throw failure('claude_code_install_path_invalid');
      directories.push(path.join(dataRoot, entry.name));
      migrated.add(entry.name.toLowerCase());
    }
    const packages = path.join(env.LOCALAPPDATA, 'Packages');
    const entries = await fs.readdir(packages, { withFileTypes: true }).catch(error => {
      if (error.code === 'ENOENT') return []; throw error;
    });
    for (const entry of entries) {
      if (/^Claude_[a-z0-9]+$/i.test(entry.name)) {
        if (!entry.isDirectory() || entry.isSymbolicLink()) throw failure('claude_code_install_path_invalid');
        const directory = path.join(packages, entry.name, 'LocalCache/Roaming/Claude');
        if (migrated.has(entry.name.toLowerCase())) {
          const marker = await fs.lstat(path.join(directory, `.user-data-left.${entry.name.toLowerCase()}`)).catch(error => {
            if (error.code === 'ENOENT') return null; throw error;
          });
          if (marker?.isFile() && !marker.isSymbolicLink() && await snapshot(path.join(directory, 'claude_desktop_config.json')) === null) continue;
        }
        directories.push(directory);
      }
    }
  }
  const matches = [];
  for (const directory of [...new Map(directories.map(value => [path.resolve(value).toLowerCase(), value])).values()]) {
    const stat = await fs.lstat(directory).catch(error => { if (error.code === 'ENOENT') return null; throw error; });
    if (!stat) continue;
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw failure('claude_code_install_path_invalid');
    const filename = path.join(directory, 'claude_desktop_config.json');
    await safeParents(filename);
    const entries = await fs.readdir(directory, { withFileTypes: true });
    // Empty launch remnants and marker-only migrated directories are not a
    // second live profile. A profile without an MCP config can still be used.
    const empty = entries.every(entry => entry.isFile() && !entry.isSymbolicLink()
      && migrated.has(entry.name.match(/^\.user-data-left\.(claude_[a-z0-9]+)$/i)?.[1].toLowerCase()));
    matches.push({ filename, empty });
  }
  const populated = matches.filter(match => !match.empty);
  const selected = populated.length ? populated : matches;
  if (selected.length > 1 && installedRoot) {
    // The background updater has no --desktop-config: it updates the one profile HelloLynk is in.
    const installed = [];
    for (const { filename } of selected) if (stableServer(parsed(await snapshot(filename))?.mcpServers?.hellolynk, installedRoot)) installed.push(filename);
    if (installed.length === 1) return installed[0];
  }
  if (selected.length !== 1) throw failure(selected.length ? 'claude_code_install_desktop_ambiguous' : 'claude_code_install_desktop_not_found');
  return selected[0].filename;
}

async function prepareMcpConfig(target, currentRoot, verifyPrevious) {
  const old = await snapshot(target);
  let config;
  try { config = old === null ? {} : JSON.parse(old.toString('utf8').replace(/^\uFEFF/, '')); }
  catch { throw failure('claude_code_install_config_invalid'); }
  if (!plain(config) || config.mcpServers !== undefined && !plain(config.mcpServers)) throw failure('claude_code_install_config_invalid');
  const previous = config.mcpServers?.hellolynk;
  const owned = previous === undefined ? null : await previousInstall(previous, verifyPrevious);
  const sameRoot = owned?.currentRoot.toLowerCase() === currentRoot.toLowerCase();
  if (owned && !sameRoot && await snapshot(path.join(owned.currentRoot, 'host/claude-native-service.json')) !== null) {
    // A clean root switch must retire the old receiver first. Never copy its
    // account, history or pending work, or leave two scheduled receivers alive.
    throw failure('claude_code_install_previous_receiver_registered');
  }
  // An entry that already names the stable entry stays exactly as it is.
  const mcp = owned?.stable && sameRoot ? previous : { ...previous, ...mcpFor(currentRoot) };
  const next = JSON.stringify(previous) === JSON.stringify(mcp) ? old
    : Buffer.from(`${JSON.stringify({ ...config, mcpServers: { ...config.mcpServers, hellolynk: mcp } }, null, 2)}\n`);
  return { target, old, next, owned };
}

function binding(candidateRoot, currentRoot, pin) {
  return { adapterId: 'claude-code', region: 'prebind', principalId: 'prebind-principal', delegateId: 'prebind-delegate', hostInstallationId: 'prebind-installation', profileId: 'prebind-claude-code', version: 2, scopes: [], releaseRoot: candidateRoot, releaseManifestSha256: pin, runtimeRoot: path.join(currentRoot, 'host/runtime'), profileManifestPath: path.join(currentRoot, 'host/profile-manifest-v1.json'), runnerRelativePath: 'runtime/neutral-host-bootstrap.mjs' };
}
function mcpFor(currentRoot, role = 'run') {
  return { command: process.execPath, args: [entryPath(currentRoot), role, '--root', path.join(currentRoot, 'host')] };
}
function legacyMcpFor(currentRoot, pin) {
  return { command: process.execPath, args: [path.join(currentRoot, 'releases', `claude-code-${pin}`, 'integrations/claude-code/server/package-bootstrap.mjs'), 'run', '--root', path.join(currentRoot, 'host'), '--expected-manifest-sha256', pin] };
}
// What this installer writes: the stable entry, started by the node.exe of whichever install wrote it.
function stableServer(server, currentRoot, role = 'run') {
  return plain(server) && typeof server.command === 'string' && path.isAbsolute(server.command)
    && /^node(?:\.exe)?$/i.test(path.basename(server.command))
    && JSON.stringify(server.args) === JSON.stringify(mcpFor(currentRoot, role).args);
}
async function previousInstall(server, verify) {
  // `claude mcp add` emits type:stdio and an empty env object. These are the
  // same owned command, not a user override. Nonempty env/unknown keys still
  // require review instead of being silently removed by an update.
  if (!plain(server) || Object.keys(server).some(key => !['args', 'command', 'type', 'env'].includes(key))
    || Object.hasOwn(server, 'type') && server.type !== 'stdio'
    || Object.hasOwn(server, 'env') && (!plain(server.env) || Object.keys(server.env).length !== 0)
    || !Array.isArray(server.args)) throw failure('claude_code_install_mcp_conflict');
  const storeRoot = server.args[3];
  if (!path.isAbsolute(storeRoot || '') || path.basename(storeRoot) !== 'host') throw failure('claude_code_install_mcp_conflict');
  const currentRoot = path.dirname(storeRoot);
  const stable = stableServer(server, currentRoot);
  let release;
  if (stable) {
    // A missing or unverifiable record leaves no earlier files to call ours.
    release = await readClaudeCodeCurrentRelease(currentRoot).catch(() => null);
    if (release) release = await verify(binding(release.releaseRoot, currentRoot, release.manifestSha256)).then(() => release, () => null);
  } else {
    const pin = server.args[5];
    if (server.command !== process.execPath || !/^[a-f0-9]{64}$/.test(pin || '')
      || JSON.stringify(server.args) !== JSON.stringify(legacyMcpFor(currentRoot, pin).args)) throw failure('claude_code_install_mcp_conflict');
    release = { releaseRoot: path.join(currentRoot, 'releases', `claude-code-${pin}`), manifestSha256: pin };
    await verify(binding(release.releaseRoot, currentRoot, pin));
  }
  return { stable, currentRoot, release, skill: release ? await snapshot(path.join(release.releaseRoot, skillRelative)) : null };
}

async function prepareBindingUpgrade(currentRoot, releaseRoot, pin, verify, verifyPrevious, dependencies) {
  const root = resolveClientAccountRoot('claude-code', path.join(currentRoot, 'host'));
  // A package install is not account enrollment. Do not initialize a protected
  // store or mint credentials for a never-bound account.
  if (await snapshot(path.join(root, 'installations-v1.json')) === null) return null;
  const createStore = dependencies.createProtectedStore || createHostProtectedStore;
  const reader = createStore({ root, readOnly: true, followClientAccount: false });
  let previous;
  try { previous = await reader.verifyClaudeCodeNeutralBinding(); }
  catch (error) {
    if (['host_installation_missing', 'neutral_claude_code_binding_configuration_required'].includes(error.code)) return null;
    throw error;
  }
  const { capability, ...previousBinding } = previous;
  const replacementBinding = { ...previousBinding, releaseRoot, releaseManifestSha256: pin };
  const current = previousBinding.releaseRoot === replacementBinding.releaseRoot
    && previousBinding.releaseManifestSha256 === pin;
  // After an uninstall the binding still names a release that is gone; the new one replaces it.
  if (await fs.lstat(previousBinding.releaseRoot).then(() => true, error => { if (error.code === 'ENOENT') return false; throw error; })) {
    await verifyPrevious(previousBinding);
  }
  let committed = null;
  let attempted = false;
  const equalBinding = (value, expected) => Object.keys(expected).every(key =>
    JSON.stringify(value[key]) === JSON.stringify(expected[key]));
  const store = () => createStore({ root, followClientAccount: false });
  return {
    async commit(checkClosed) {
      await checkClosed();
      assertClientAccountCurrent('claude-code', root);
      await verify(replacementBinding);
      await checkClosed();
      if (current) {
        const after = await reader.verifyClaudeCodeNeutralBinding();
        if (!equalBinding(after, previousBinding) || after.capability.capabilityId !== capability.capabilityId) {
          throw failure('claude_code_install_binding_changed');
        }
        return;
      }
      attempted = true;
      const migrated = await store().migrateClaudeCodeNeutralBinding({ previousBinding,
        previousCapabilityId: capability.capabilityId, replacementBinding });
      // The migration rotates only the local adapter capability. Never retain
      // its secret in the install result or diagnostic output.
      committed = { capabilityId: migrated.capability.capabilityId };
      migrated.capability.secretBuffer?.fill(0);
      const after = await reader.verifyClaudeCodeNeutralBinding();
      if (!equalBinding(after, replacementBinding) || after.capability.capabilityId !== committed.capabilityId) {
        throw failure('claude_code_install_binding_changed');
      }
    },
    async rollback(checkClosed) {
      if (!attempted) return;
      await checkClosed();
      assertClientAccountCurrent('claude-code', root);
      const after = await reader.verifyClaudeCodeNeutralBinding();
      if (!committed) {
        if (equalBinding(after, previousBinding) && after.capability.capabilityId === capability.capabilityId) return;
        // An ambiguous migration result or another actor's update must not be
        // overwritten by guessing which credential belongs to this install.
        throw failure('claude_code_install_binding_changed');
      }
      if (!equalBinding(after, replacementBinding) || after.capability.capabilityId !== committed.capabilityId) {
        throw failure('claude_code_install_binding_changed');
      }
      await verifyPrevious(previousBinding);
      const restored = await store().migrateClaudeCodeNeutralBinding({ previousBinding: replacementBinding,
        previousCapabilityId: committed.capabilityId, replacementBinding: previousBinding });
      restored.capability.secretBuffer?.fill(0);
      const final = await reader.verifyClaudeCodeNeutralBinding();
      if (!equalBinding(final, previousBinding) || final.capability.capabilityId !== restored.capability.capabilityId) {
        throw failure('claude_code_install_binding_changed');
      }
    },
  };
}

// Dependency injection is restricted to module callers, never CLI flags. Tests
// use isolated temporary directories and never need a live desktop or account.
async function withClaudeInstallLock(lockPath, operation) {
  try {
    return await withLocalProcessLock(lockPath, async () => {
      const old = await snapshot(lockPath);
      if (old !== null) {
        const text = old.toString('utf8').trim();
        const pid = /^\d+$/.test(text) ? Number(text) : 0;
        if (!Number.isSafeInteger(pid) || pid < 1) throw failure('claude_code_install_busy');
        try { process.kill(pid, 0); throw failure('claude_code_install_busy'); }
        catch (error) { if (error.code !== 'ESRCH') throw failure('claude_code_install_busy'); }
        await unchanged(lockPath, old);
        await fs.unlink(lockPath);
      }
      const lock = await fs.open(lockPath, 'wx', 0o600);
      try { await lock.writeFile(`${process.pid}\n`); return await operation(); }
      finally { await lock.close(); await fs.unlink(lockPath); }
    }, { timeoutMs: 1_000 });
  } catch (error) {
    if (['hellolynk_local_process_lock_busy', 'EEXIST'].includes(error.code)) throw failure('claude_code_install_busy');
    throw error;
  }
}

export async function installClaudeCodeDesktop(options, dependencies = {}) {
  runtimeSafety.assertHelloLynkClientNodeVersion();
  const { candidateRoot, expectedManifestSha256 } = options;
  const currentRoot = path.resolve(options.currentRoot || path.dirname(defaultClaudeCodeStoreRoot()));
  const home = options.home || os.homedir();
  const checkClosed = dependencies.checkClosed || assertClaudeClosed;
  const verify = dependencies.verify || verifyClaudeCodeCandidate;
  const verifyPrevious = dependencies.verifyPrevious || dependencies.verify || verifyClaudeCodePreviousRelease;
  const install = dependencies.install || installClaudeCodeCandidate;
  if (!path.isAbsolute(candidateRoot || '') || options.currentRoot !== undefined && !path.isAbsolute(options.currentRoot) || !path.isAbsolute(home) || currentRoot === path.parse(currentRoot).root || !/^[a-f0-9]{64}$/.test(expectedManifestSha256 || '')) throw failure('claude_code_install_arguments_invalid');
  await verify(binding(candidateRoot, currentRoot, expectedManifestSha256));
  const releaseRoot = await claudeCodeReleaseRoot(currentRoot, candidateRoot);
  const desktopConfig = await discoverClaudeDesktopConfig(options);
  const skillPath = path.join(home, '.claude/skills/hellolynk-open/SKILL.md');
  const lockPath = `${desktopConfig}.hellolynk-install.lock`;
  return withClaudeInstallLock(lockPath, async () => {
  const applied = [];
  let bindingUpgrade = null, receiverSwitched = false, check = checkClosed;
  let result, previousRelease, publishedAt;
  // Scheduler and release checks are injectable for isolated module tests only.
  const nativeService = { storeRoot: path.join(currentRoot, 'host'),
    scheduledTask: dependencies.scheduledTask, verifyRelease: dependencies.verifyNativeRelease };
  try {
    const desktop = await prepareMcpConfig(desktopConfig, currentRoot, verifyPrevious);
    const code = await prepareMcpConfig(path.join(home, '.claude.json'), currentRoot, verifyPrevious);
    // Writing Claude's configuration needs Claude closed. Once both entries name the stable
    // entry, an update changes only HelloLynk's own files, and Claude may stay open.
    const upgrade = same(desktop.old, desktop.next) && same(code.old, code.next);
    if (!upgrade && dependencies.updateOnly) throw failure('claude_code_install_close_claude_required');
    if (upgrade) check = async () => {};
    await check();
    // An update worker of an earlier release cleans up after this setup with its own code, which
    // cannot see what a process started through the stable entry runs. An install on the stable
    // entry changes nothing until its cleanup receipt is v2, which that code does not act on.
    if (upgrade) {
      await protectRetentionReceipt({ releasesRoot: path.join(currentRoot, 'releases'), client: 'claude-code',
        currentRelease: (code.owned.release || desktop.owned.release)?.releaseRoot })
        .catch(() => { throw failure('claude_code_install_cleanup_record_unconfirmed'); });
    }
    const oldSkill = await snapshot(skillPath), newSkill = await snapshot(path.join(candidateRoot, skillRelative));
    if (newSkill === null) throw failure('claude_code_install_skill_missing');
    if (oldSkill !== null && !same(oldSkill, newSkill)
      && ![desktop.owned?.skill, code.owned?.skill].some(value => same(oldSkill, value ?? null))) throw failure('claude_code_install_skill_conflict');
    const originalSession = await prepareOriginalSessionMod({ home, candidateRoot, currentRoot, previous: code.owned || desktop.owned });
    const entry = await snapshot(path.join(candidateRoot, entryRelative));
    if (entry === null) throw failure('claude_code_install_entry_missing');
    const record = Buffer.from(`${JSON.stringify({ contract: 'hellolynk-claude-code-current-release-v1', releaseRoot, manifestSha256: expectedManifestSha256 })}\n`);
    bindingUpgrade = await prepareBindingUpgrade(currentRoot, releaseRoot, expectedManifestSha256, verify, verifyPrevious, dependencies);
    await check();
    const installed = await install({ candidateRoot, currentRoot, expectedManifestSha256 });
    if (installed.releaseRoot !== releaseRoot) throw failure('claude_code_install_release_invalid');
    // Claude rewrites ~/.claude.json while it runs; an update leaves both configurations unread
    // after this point. The stable entry and its record come last, once the release is in place.
    const changes = [{ target: skillPath, old: oldSkill, next: newSkill }, ...upgrade ? [] : [desktop, code], ...originalSession.changes,
      { target: entryPath(currentRoot), old: await snapshot(entryPath(currentRoot)), next: entry },
      { target: currentReleasePath(currentRoot), old: await snapshot(currentReleasePath(currentRoot)), next: record }];
    for (const [index, change] of changes.entries()) {
      await dependencies.beforeWrite?.(index);
      // Detect edits to either destination before making the next mutation.
      for (const c of changes) await unchanged(c.target, applied.find(item => item.target === c.target)?.next ?? c.old);
      if (!same(change.old, change.next)) {
        await replace(change.target, change.next, change.old, check);
        applied.push(change);
      }
    }
    await dependencies.afterWrite?.();
    await check();
    for (const c of changes) await unchanged(c.target, c.next);
    await bindingUpgrade?.commit(check);
    await dependencies.afterBindingUpgrade?.();
    await check();
    for (const c of changes) await unchanged(c.target, c.next);
    // An existing background receiver follows the update with its on/off state.
    // Last step: switching stops the old receiver, and nothing after it checks
    // for Claude processes, which the restarted receiver's CLI could trigger.
    let receiver = { changed: false, status: 'not_installed' };
    if (await snapshot(path.join(nativeService.storeRoot, 'claude-native-service.json')) !== null) {
      receiverSwitched = true;
      receiver = await switchClaudeNativeTaskService({ ...nativeService, root: releaseRoot, expectedManifestSha256 });
    }
    const oldReleases = [...new Set([code, desktop].filter(config => config.owned?.release && config.owned.currentRoot.toLowerCase() === currentRoot.toLowerCase())
      .map(config => config.owned.release.releaseRoot).filter(root => root !== releaseRoot))];
    // Different former Desktop/Code versions remain recoverable; do not guess
    // which is the previous adoption when the two configurations disagree.
    previousRelease = oldReleases.length > 1 ? undefined : oldReleases[0] ?? null;
    result = { installed: true, activated: false, receiverChanged: receiver.changed, desktopConfig, skillPath, previousRelease,
      codeConfig: code.target, originalSessionPlugin: originalSession.root, releaseRoot, manifestSha256: expectedManifestSha256 };
    publishedAt = new Date().toISOString();
    // A failed start keeps the enabled registration; MCP starts it with Claude.
    if (receiver.changed && receiver.enabled && !dependencies.deferReceiverStart) {
      result.receiverStarted = await startRecordedClaudeNativeTaskService(nativeService)
        .then(value => value.status === 'service_started', () => false);
    }
  } catch (error) {
    let rollbackFailed = false;
    try { await bindingUpgrade?.rollback(check); } catch { rollbackFailed = true; }
    for (const change of applied.reverse()) {
      try {
        await check();
        await unchanged(change.target, change.next);
        if (change.old === null) await fs.unlink(change.target);
        else await replace(change.target, change.old, change.next, check);
      } catch { rollbackFailed = true; }
    }
    if (receiverSwitched) {
      // The switch restored the previous registration itself; restart it if enabled.
      if (error.code === 'claude_native_service_switch_rollback_incomplete') rollbackFailed = true;
      else await startRecordedClaudeNativeTaskService(nativeService).catch(() => {});
    }
    if (rollbackFailed) throw failure('claude_code_install_rollback_incomplete');
    throw error;
  } finally {
    // Cleanup is after adoption, outside rollback handling, still under the
    // same installation lock. A cleanup failure never undoes a good install.
    if (result) result.releaseCleanup = dependencies.deferReleaseCleanup
      ? { deferredToReceiver: true } : await cleanupClaudeReleases(currentRoot, result, dependencies.retention);
  }
  // The receiver command asks once, after its own last step.
  if (!dependencies.deferReceiverStart) result.hostHandover = await requestHostHandover(currentRoot, publishedAt, dependencies);
  return result;
  });
}

// Bindings and configuration are committed: ask a Host of an earlier release to
// make room, and start one from the new binding once it has. Any failure is only
// reported and never undoes the installation.
async function requestHostHandover(currentRoot, publishedAt, dependencies) {
  try {
    const root = resolveClientAccountRoot('claude-code', path.join(currentRoot, 'host'));
    if (await snapshot(path.join(root, 'installations-v1.json')) === null) return { status: 'no_host' };
    const reader = (dependencies.createProtectedStore || createHostProtectedStore)({ root, readOnly: true, followClientAccount: false });
    let binding;
    try { binding = await reader.verifyClaudeCodeNeutralBinding(); }
    catch (error) {
      if (['host_installation_missing', 'neutral_claude_code_binding_configuration_required'].includes(error.code)) return { status: 'no_host' };
      throw error;
    }
    binding.capability?.secretBuffer?.fill(0);
    const host = await import('../../../runtime/core/hellolynk-neutral-host-process.mjs');
    const request = { runtimeRoot: binding.runtimeRoot, hostInstallationId: binding.hostInstallationId, publishedAt };
    const result = await (dependencies.requestHostHandover || host.requestHelloLynkNeutralHostHandover)(request);
    // Only a Host that was running and made room is replaced. One started where there was
    // none would have nothing attached to it and never leave.
    if (!['stopped', 'restarted'].includes(result?.status)) return result;
    return { ...result, hostStart: await startHostWhenAbsent(host, binding, dependencies) };
  } catch { return { status: 'unconfirmed' }; }
}

// A Host that left for this release is not started again until some client reconnects.
// Start one from the new binding unless another client has within two seconds.
// "running": a Host answered or another client is starting one; "started": this installer
// started one; "failed": none was started.
async function startHostWhenAbsent(host, binding, dependencies) {
  const discover = dependencies.discoverHost || host.discoverHelloLynkNeutralHost;
  const wait = dependencies.wait || (ms => new Promise(resolve => setTimeout(resolve, ms)));
  const probe = { region: binding.region, principalId: binding.principalId,
    hostInstallationId: binding.hostInstallationId, runtimeRoot: binding.runtimeRoot };
  for (let attempt = 0; attempt < 8; attempt += 1) {
    try { if (await discover(probe)) return 'running'; } catch {}
    await wait(250);
  }
  try {
    const launch = dependencies.launchHost
      || (await import('../../../runtime/core/hellolynk-neutral-host-launcher.mjs')).launchPinnedNeutralHost;
    await launch(binding);
    return 'started';
  } catch (error) {
    return ['neutral_host_already_running', 'neutral_host_release_superseded'].includes(error?.code) ? 'running' : 'failed';
  }
}

// "current" means this release or a newer one already runs. A Host that left was started
// again by this installer ("started") or by another client ("running"), or not at all ("failed").
const HANDOVER_NOTICES = Object.freeze({
  current: ['这台电脑上的 HelloLynk 已在运行这个版本或更新的版本。', 'HelloLynk on this computer already runs this version or a newer one.'],
  started: ['这台电脑上的 HelloLynk 正在以这个版本启动。', 'HelloLynk on this computer is starting with this version.'],
  running: ['这台电脑上的 HelloLynk 正在运行。', 'HelloLynk on this computer is running.'],
  failed: ['这台电脑上的 HelloLynk 已停止。打开 Claude 即可重新启动。', 'HelloLynk on this computer stopped. Open Claude to start it again.'],
  pending: ['这台电脑上的 HelloLynk 还在运行旧版本。请关闭所有使用 HelloLynk 的客户端，再重新打开。', 'HelloLynk on this computer still runs an earlier version. Close every client that uses HelloLynk, then open them again.'],
  unconfirmed: ['无法确认这台电脑上的 HelloLynk 运行的版本。请关闭所有使用 HelloLynk 的客户端，再重新打开。', 'Which version HelloLynk on this computer runs could not be checked. Close every client that uses HelloLynk, then open them again.'],
});
export function handoverNotice(result, chinese = CHINESE) {
  const handover = result?.hostHandover;
  const outcome = ['stopped', 'restarted'].includes(handover?.status) ? handover.hostStart : handover?.status;
  return Object.hasOwn(HANDOVER_NOTICES, String(outcome)) ? `${HANDOVER_NOTICES[outcome][chinese ? 0 : 1]}\n` : '';
}

async function cleanupClaudeReleases(currentRoot, installed, dependencies) {
  try {
    if (installed.previousRelease === undefined) return { complete: false, error: 'release_retention_previous_ambiguous' };
    // The background service can be stopped yet still point to a release it
    // needs on the next login (and even during uninstall). Protect that record
    // as well as running processes; Node does not lock loaded source files.
    // The service belongs to the installation, not a rotated account's data.
    const serviceBytes = await snapshot(path.join(currentRoot, 'host', 'claude-native-service.json'));
    const referencedReleases = [];
    if (serviceBytes) {
      const service = JSON.parse(serviceBytes);
      if (typeof service.root !== 'string' || !path.isAbsolute(service.root)
        || !/^[a-f0-9]{64}$/.test(service.expectedManifestSha256 || '')) throw failure('release_retention_service_invalid');
      if (path.dirname(service.root) === path.join(currentRoot, 'releases')) referencedReleases.push(service.root);
    }
    return await pruneInstalledReleases({ releasesRoot: path.join(currentRoot, 'releases'), client: 'claude-code',
      currentRelease: installed.releaseRoot, previousRelease: installed.previousRelease, referencedReleases }, dependencies);
  } catch { return { complete: false, error: 'release_retention_reference_check_failed' }; }
}

export async function installClaudeCodeReceiver(options, dependencies = {}) {
  runtimeSafety.assertHelloLynkClientNodeVersion();
  const checkClosed = dependencies.checkClosed || assertClaudeClosed;
  if (!path.isAbsolute(options.cliPath || '') || !path.isAbsolute(options.workingDirectory || '')) {
    throw failure('claude_code_install_receiver_arguments_required');
  }
  const currentRoot = path.resolve(options.currentRoot || path.dirname(defaultClaudeCodeStoreRoot()));
  const home = options.home || os.homedir();
  await checkClosed();
  const configFile = await discoverClaudeDesktopConfig(options);
  const recorded = await readClaudeCodeCurrentRelease(currentRoot).catch(() => null);
  if (!stableServer(parsed(await snapshot(configFile))?.mcpServers?.hellolynk, currentRoot)
    || recorded?.manifestSha256 !== options.expectedManifestSha256
    || recorded.releaseRoot !== await claudeCodeReleaseRoot(currentRoot, options.candidateRoot)
    || !same(await snapshot(path.join(home, '.claude/skills/hellolynk-open/SKILL.md')),
      await snapshot(path.join(options.candidateRoot, skillRelative)))) throw failure('claude_code_install_desktop_first');
  // Repair upgrades performed by an older installer before starting a receiver
  // that could otherwise resolve and relaunch the previously pinned Host.
  // The explicit receiver install below reconfigures and starts the receiver.
  const desktop = await installClaudeCodeDesktop(options, { ...dependencies, deferReleaseCleanup: true, deferReceiverStart: true });
  await checkClosed();
  const installed = await (dependencies.install || installClaudeCodeCandidate)({
    candidateRoot: options.candidateRoot, expectedManifestSha256: options.expectedManifestSha256, currentRoot,
    receiver: { enabled: true, executionMode: 'background-cli', cliPath: options.cliPath,
      workingDirectory: options.workingDirectory, startAtLogon: options.startAtLogon === true },
  });
  // The outer receiver adoption must succeed before pruning. Reacquire the
  // install lock and ensure a different install has not replaced either entry.
  let lock, releaseCleanup;
  const lockPath = `${desktop.desktopConfig}.hellolynk-install.lock`;
  try {
    lock = await fs.open(lockPath, 'wx', 0o600);
    for (const file of [desktop.desktopConfig, desktop.codeConfig]) {
      if (!stableServer(parsed(await snapshot(file))?.mcpServers?.hellolynk, currentRoot)) throw failure('release_retention_install_changed');
    }
    if ((await readClaudeCodeCurrentRelease(currentRoot)).releaseRoot !== desktop.releaseRoot) throw failure('release_retention_install_changed');
    releaseCleanup = await cleanupClaudeReleases(currentRoot, desktop, dependencies.retention);
  } catch { releaseCleanup = { complete: false, error: 'release_retention_install_changed' }; }
  finally { if (lock) { await lock.close(); await fs.unlink(lockPath); } }
  const hostHandover = await requestHostHandover(currentRoot, new Date().toISOString(), dependencies);
  return Object.freeze({ ...installed, releaseCleanup, hostHandover });
}

// Uninstall removes only what an installer of this root wrote: the pinned or stable entry,
// unchanged copies of shipped files, and releases no process still uses. host\ keeps the
// account, contacts and history, so a reinstall needs no new connection.
function ownedServer(server, currentRoot) {
  const pin = server?.args?.[5];
  return stableServer(server, currentRoot) || plain(server) && typeof server.command === 'string'
    && /^node(?:\.exe)?$/i.test(path.basename(server.command)) && /^[a-f0-9]{64}$/.test(pin || '')
    && JSON.stringify(server.args) === JSON.stringify(legacyMcpFor(currentRoot, pin).args);
}
function ownedReceiver(bytes, currentRoot) {
  const server = parsed(bytes);
  return stableReceiver(bytes, currentRoot) || plain(server) && Array.isArray(server.args) && server.args[1] === 'original-session'
    && ownedServer({ ...server, args: [server.args[0], 'run', ...server.args.slice(2)] }, currentRoot);
}
export async function uninstallClaudeCode(options = {}, dependencies = {}) {
  runtimeSafety.assertHelloLynkClientNodeVersion();
  const currentRoot = path.resolve(options.currentRoot || path.dirname(defaultClaudeCodeStoreRoot()));
  const home = options.home || os.homedir();
  const check = dependencies.checkClosed || assertClaudeClosed;
  if (options.currentRoot !== undefined && !path.isAbsolute(options.currentRoot) || !path.isAbsolute(home)
    || currentRoot === path.parse(currentRoot).root) throw failure('claude_code_install_arguments_invalid');
  await check();
  const desktopConfig = await discoverClaudeDesktopConfig({ ...options, installedRoot: currentRoot });
  return withClaudeInstallLock(`${desktopConfig}.hellolynk-install.lock`, async () => {
    const releasesRoot = path.join(currentRoot, 'releases');
    const releases = (await fs.readdir(releasesRoot).catch(error => { if (error.code === 'ENOENT') return []; throw error; }))
      .filter(name => /^claude-code-[a-f0-9]{64}$/.test(name)).map(name => path.join(releasesRoot, name));
    const shipped = async relative => {
      const copies = [];
      for (const root of [options.candidateRoot, ...releases].filter(Boolean)) copies.push(await snapshot(path.join(root, relative)));
      return copies.filter(Boolean);
    };
    const configs = [];
    for (const target of [desktopConfig, path.join(home, '.claude.json')]) {
      const old = await snapshot(target), config = parsed(old);
      if (old !== null && (!plain(config) || config.mcpServers !== undefined && !plain(config.mcpServers))) throw failure('claude_code_install_config_invalid');
      if (config?.mcpServers?.hellolynk === undefined) continue;
      if (!ownedServer(config.mcpServers.hellolynk, currentRoot)) throw failure('claude_code_install_mcp_conflict');
      const { hellolynk: _removed, ...servers } = config.mcpServers;
      configs.push({ target, old, next: Buffer.from(`${JSON.stringify({ ...config, mcpServers: servers }, null, 2)}\n`) });
    }
    const receiver = path.join(home, '.claude/skills/hellolynk-receive');
    const files = [];
    for (const [target, relative, code] of [[path.join(home, '.claude/skills/hellolynk-open/SKILL.md'), skillRelative, 'claude_code_install_skill_conflict'],
      ...modFiles.map(name => [path.join(receiver, name === 'plugin.json' ? '.claude-plugin/plugin.json' : name), `integrations/claude-code/mod/${name}`, 'claude_code_install_mod_conflict'])]) {
      const old = await snapshot(target);
      if (old === null) continue;
      if (!(await shipped(relative)).some(copy => same(old, copy))) throw failure(code);
      files.push({ target, old });
    }
    const receiverConfig = path.join(receiver, 'receiver.json'), oldReceiver = await snapshot(receiverConfig);
    if (oldReceiver !== null) {
      if (!ownedReceiver(oldReceiver, currentRoot)) throw failure('claude_code_install_mod_conflict');
      files.push({ target: receiverConfig, old: oldReceiver });
    }
    // The background receiver goes first: its scheduled task runs from a release removed below.
    const storeRoot = path.join(currentRoot, 'host');
    const serviceRecord = await snapshot(path.join(storeRoot, 'claude-native-service.json'));
    if (serviceRecord !== null) {
      const service = parsed(serviceRecord);
      await configureClaudeNativeTaskService({ storeRoot, root: service?.root, expectedManifestSha256: service?.expectedManifestSha256,
        verifyRelease: dependencies.verifyNativeRelease, scheduledTask: dependencies.scheduledTask }, 'Uninstall');
    }
    for (const change of configs) await replace(change.target, change.next, change.old, check);
    for (const file of files) { await unchanged(file.target, file.old); await fs.unlink(file.target); }
    for (const target of [entryPath(currentRoot), currentReleasePath(currentRoot)]) await fs.rm(target, { force: true });
    for (const directory of [path.join(home, '.claude/skills/hellolynk-open'), path.join(receiver, '.claude-plugin'), path.join(receiver, 'hooks'), receiver, path.dirname(entryPath(currentRoot))]) {
      await fs.rmdir(directory).catch(error => { if (!['ENOENT', 'ENOTEMPTY', 'EEXIST'].includes(error.code)) throw error; });
    }
    const releaseCleanup = await removeInstalledReleases({ releasesRoot, client: 'claude-code' }, dependencies.retention);
    return { uninstalled: true, desktopConfig, codeConfig: path.join(home, '.claude.json'), releaseCleanup };
  });
}

// What the background updater asks of an install before and after it updates one. Read-only:
// anything that does not verify throws.
export async function inspectClaudeCodeInstall(options, dependencies = {}) {
  runtimeSafety.assertHelloLynkClientNodeVersion();
  const { candidateRoot, expectedManifestSha256 } = options;
  const currentRoot = path.resolve(options.currentRoot || path.dirname(defaultClaudeCodeStoreRoot()));
  const home = options.home || os.homedir();
  const packageVersion = parsed(await snapshot(path.join(candidateRoot, 'package.json')))?.version;
  const version = process.platform === 'darwin' ? MAC_CLIENT_VERSION : /^\d+\.\d+\.\d+$/;
  if (!version.test(packageVersion || '') || !/^[a-f0-9]{64}$/.test(expectedManifestSha256 || '')) throw failure('claude_code_install_arguments_invalid');
  const result = { ok: true, client: 'claude-code', packageVersion, activated: false,
    stableReleaseVerified: false, exactBindingVerified: false, clientConfigurationVerified: false };
  const root = resolveClientAccountRoot('claude-code', path.join(currentRoot, 'host'));
  if (await snapshot(path.join(root, 'installations-v1.json')) === null) return result;
  const reader = (dependencies.createProtectedStore || createHostProtectedStore)({ root, readOnly: true, followClientAccount: false });
  let bound;
  try { bound = await reader.verifyClaudeCodeNeutralBinding(); }
  catch (error) {
    if (['host_installation_missing', 'neutral_claude_code_binding_configuration_required'].includes(error.code)) return result;
    throw error;
  }
  bound.capability?.secretBuffer?.fill(0);
  const releaseRoot = await claudeCodeReleaseRoot(currentRoot, candidateRoot);
  await (dependencies.verify || verifyClaudeCodeCandidate)(binding(releaseRoot, currentRoot, expectedManifestSha256));
  await verifyClaudeCodePackage(releaseRoot);
  const recorded = await readClaudeCodeCurrentRelease(currentRoot);
  if (recorded.releaseRoot !== releaseRoot || recorded.manifestSha256 !== expectedManifestSha256
    || !same(await snapshot(entryPath(currentRoot)), await snapshot(path.join(candidateRoot, entryRelative)))) throw failure('claude_code_install_release_invalid');
  if (bound.releaseRoot !== releaseRoot || bound.releaseManifestSha256 !== expectedManifestSha256) throw failure('claude_code_install_binding_changed');
  const desktopConfig = await discoverClaudeDesktopConfig({ ...options, installedRoot: currentRoot });
  for (const file of [desktopConfig, path.join(home, '.claude.json')]) {
    if (!stableServer(parsed(await snapshot(file))?.mcpServers?.hellolynk, currentRoot)) throw failure('claude_code_install_config_changed');
  }
  const receiver = path.join(home, '.claude/skills/hellolynk-receive');
  for (const [target, relative] of [[path.join(home, '.claude/skills/hellolynk-open/SKILL.md'), skillRelative],
    ...modFiles.map(name => [path.join(receiver, name === 'plugin.json' ? '.claude-plugin/plugin.json' : name), `integrations/claude-code/mod/${name}`])]) {
    if (!same(await snapshot(target), await snapshot(path.join(candidateRoot, relative)))) throw failure('claude_code_install_config_changed');
  }
  if (!stableReceiver(await snapshot(path.join(receiver, 'receiver.json')), currentRoot)) throw failure('claude_code_install_config_changed');
  const inspected = { ...result, activated: true, stableReleaseVerified: true, exactBindingVerified: true, clientConfigurationVerified: true };
  // The unsigned worker may recover a just-committed bootstrap from its staged
  // copy, but it cannot get an update proof from the active signed release.
  if (options.legacyUpdateProof && !path.relative(await fs.realpath(candidateRoot), await fs.realpath(releaseRoot))) {
    delete inspected.exactBindingVerified;
  }
  return inspected;
}

// bin/hellolynk-client-setup.mjs: the two commands the background updater runs, each answered
// with one JSON line. setup only updates an install whose configuration names the stable entry.
export async function runClaudeCodeClientSetup(args, { packageRoot }, dependencies = {}) {
  await assertClaudeCodePackagePlatform(packageRoot);
  const options = { candidateRoot: packageRoot,
    expectedManifestSha256: parsed(await snapshot(path.join(packageRoot, 'runtime/neutral-host-release-pin.json')))?.manifestSha256 };
  if (args[0] === 'doctor' && (args.length === 1 || (args.length === 2 && args[1] === '--json'))) {
    return inspectClaudeCodeInstall({ ...options, legacyUpdateProof: args.length === 1 && Boolean(process.env.HELLOLYNK_NEUTRAL_STORE_ROOT) }, dependencies);
  }
  if (args.length !== 2 || args[0] !== 'setup' || args[1] !== '--defer-release-cleanup') throw failure('claude_code_install_command_invalid');
  const desktopConfig = await discoverClaudeDesktopConfig({ installedRoot: path.dirname(defaultClaudeCodeStoreRoot()) });
  const installed = await installClaudeCodeDesktop({ ...options, desktopConfig }, { ...dependencies, updateOnly: true, deferReleaseCleanup: true });
  return { ok: true, client: 'claude-code', packageVersion: parsed(await snapshot(path.join(packageRoot, 'package.json'))).version,
    hostHandover: installed.hostHandover };
}

export function claudeCodeHelp(chinese = CHINESE) {
  const mac = process.platform === 'darwin';
  const system = mac ? 'macOS 13+ (Apple Silicon)' : 'Windows';
  const cli = mac ? 'claude' : 'claude.exe';
  return chinese ? `HelloLynk for Claude（${system}，Node.js 22.16.0+）
安装：完全退出 Claude 后运行 node install.mjs
升级：自动完成
启用接收器：node install.mjs receiver --cli-path "<${cli} 的路径>" --working-directory "<工作目录>" [--start-at-logon]
卸载：完全退出 Claude 后运行 node install.mjs uninstall
只检查安装包：node install.mjs --check
有多个 Claude 实例时，以上命令加 --desktop-config "<claude_desktop_config.json 的完整路径>"
` : `HelloLynk for Claude (${system}, Node.js 22.16.0+)
Install: quit Claude completely, then run node install.mjs
Update: automatic
Enable the receiver: node install.mjs receiver --cli-path "<path to ${cli}>" --working-directory "<working directory>" [--start-at-logon]
Uninstall: quit Claude completely, then run node install.mjs uninstall
Check the package only: node install.mjs --check
With more than one Claude instance, add --desktop-config "<full path to claude_desktop_config.json>" to these commands
`;
}
const say = (zh, en) => CHINESE ? zh : en;
export async function runClaudeCodeSetup(args, trusted) {
  runtimeSafety.assertHelloLynkClientNodeVersion();
  if (args.length === 1 && args[0] === '--help') { process.stdout.write(claudeCodeHelp()); return; }
  await assertClaudeCodePackagePlatform(trusted.candidateRoot);
  const receiver = args[0] === 'receiver', uninstall = args[0] === 'uninstall';
  if (receiver || uninstall) args = args.slice(1);
  const options = { ...trusted }, seen = new Set();
  for (let index = 0; index < args.length; index++) {
    const key = args[index];
    if (seen.has(key)) throw failure('claude_code_install_arguments_invalid');
    seen.add(key);
    if (key === '--start-at-logon' && receiver) { options.startAtLogon = true; continue; }
    const names = { '--desktop-config': 'desktopConfig', '--root': 'currentRoot', ...(receiver ? { '--cli-path': 'cliPath', '--working-directory': 'workingDirectory' } : {}) };
    if (!names[key] || !args[index + 1] || !path.isAbsolute(args[index + 1])) throw failure('claude_code_install_arguments_invalid');
    options[names[key]] = args[++index];
  }
  if (uninstall) {
    const result = await uninstallClaudeCode(options);
    process.stdout.write(`${say('HelloLynk 已卸载。账号、联系人和聊天记录留在这台电脑上，重新安装后不用重新连接。',
      'HelloLynk is uninstalled. Your account, contacts and chat history stay on this computer; reinstalling needs no new connection.')}\n${result.releaseCleanup.complete ? ''
      : `${say('有的版本还在使用，下次安装或卸载时删除。', 'Some versions are still in use; they are removed the next time you install or uninstall.')}\n`}`);
  } else if (receiver) {
    const result = await installClaudeCodeReceiver(options);
    process.stdout.write(`${say('后台接收器已启用。', 'The background receiver is enabled.')}\n${handoverNotice(result)}`);
  } else {
    const result = await installClaudeCodeDesktop(options);
    process.stdout.write(`${say('HelloLynk 已安装。打开 Claude，说“打开 HelloLynk”，在卡片里连接账号。',
      'HelloLynk is installed. Open Claude, say "open HelloLynk", and connect your account in the card.')}\n${handoverNotice(result)}`);
  }
}
