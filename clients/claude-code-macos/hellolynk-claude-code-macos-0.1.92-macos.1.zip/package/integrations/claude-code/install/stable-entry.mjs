#!/usr/bin/env node
// Setup copies this file to <currentRoot>/claude-code/hellolynk-claude-code.mjs and Claude's
// configuration names only that copy. It starts the release named in current-release.json, so
// an update never changes Claude's configuration.
import fs from "node:fs/promises";
import { rmSync } from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";

const CONTRACT = "hellolynk-claude-code-current-release-v1";
const invalid = () => Object.assign(new Error("claude_code_entry_release_invalid"), { code: "claude_code_entry_release_invalid" });

export async function readClaudeCodeCurrentRelease(currentRoot) {
  const file = path.join(currentRoot, "claude-code", "current-release.json");
  let record;
  try {
    for (let current = file; path.dirname(current) !== current; current = path.dirname(current)) {
      const stat = await fs.lstat(current);
      if (stat.isSymbolicLink() || (current === file ? !stat.isFile() || stat.nlink !== 1 || stat.size > 1024 : !stat.isDirectory())) throw invalid();
    }
    record = JSON.parse(await fs.readFile(file, "utf8"));
  } catch { throw invalid(); }
  if (record === null || typeof record !== "object" || Array.isArray(record)
    || Object.keys(record).sort().join(",") !== "contract,manifestSha256,releaseRoot" || record.contract !== CONTRACT
    || typeof record.manifestSha256 !== "string" || !/^[a-f0-9]{64}$/.test(record.manifestSha256)
    || typeof record.releaseRoot !== "string" || !path.isAbsolute(record.releaseRoot) || path.resolve(record.releaseRoot) !== record.releaseRoot
    || path.dirname(record.releaseRoot).toLowerCase() !== path.join(currentRoot, "releases").toLowerCase()
    || !/^claude-code-[a-f0-9]{64}$/.test(path.basename(record.releaseRoot))) throw invalid();
  return record;
}

// A command line names only this entry, so release cleanup reads which release this process
// runs from a record kept until it exits (clients/core/hellolynk-release-retention.mjs). Without
// a record cleanup keeps every release, so a failed write only delays it.
export async function recordClaudeCodeProcess(releaseRoot) {
  const file = path.join(path.dirname(releaseRoot), ".claude-code-processes", `${process.pid}.json`);
  try {
    await fs.mkdir(path.dirname(file), { recursive: true });
    await fs.writeFile(file, `${JSON.stringify({ contract: "hellolynk-release-process-v1", pid: process.pid,
      startedAt: Math.round(performance.timeOrigin), release: path.basename(releaseRoot) })}\n`);
    process.once("exit", () => { try { rmSync(file, { force: true }); } catch {} });
  } catch {}
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  readClaudeCodeCurrentRelease(path.dirname(path.dirname(fileURLToPath(import.meta.url)))).then(async (release) => {
    await recordClaudeCodeProcess(release.releaseRoot);
    const { runClaudeCodePackage } = await import(pathToFileURL(path.join(release.releaseRoot, "integrations/claude-code/server/package-bootstrap.mjs")).href);
    await runClaudeCodePackage([...process.argv.slice(2), "--expected-manifest-sha256", release.manifestSha256]);
  }).catch((error) => {
    process.stderr.write(`${error?.code === "claude_code_entry_release_invalid" ? error.code : "claude_code_package_start_failed"}\n`);
    process.exitCode = 1;
  });
}
