#!/usr/bin/env node
import crypto from "node:crypto";
import fs from "node:fs/promises";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { defaultClaudeCodeStoreRoot } from "../../../runtime/core/hellolynk-host-protected-store.mjs";
import { prepareWindowsClientRoot, secureWindowsClientReleaseTree } from "../../../runtime/core/hellolynk-platform-credential-store.mjs";
import { verifyPinnedNeutralHostRuntime } from "../../../runtime/core/hellolynk-neutral-host-launcher.mjs";
import { clientAccountBaseRoot } from "../../../runtime/core/hellolynk-client-account.mjs";
import { verifyClientUpdatePackage } from "../../../runtime/core/hellolynk-client-update-runtime.mjs";

// These reviewed 0.1.5-0.1.7 releases predate the indexed local message store.
// Pinning their exact manifests prevents compatibility from approving new code.
const PRE_INDEXED_RELEASES = new Set([
  "931a6b42f3d877d174f5751b6ab7d72e7a02941442432514741208786ce2f9a8", // 0.1.5
  "9b52a4e6e996c8a223df00ad01780494441e457568eb73d29f20241f9d82af64", // 0.1.6
  "398ab2bd59277e3bd680fa60caa96b6c0287db035b35b96b5ebea63a7448513c", // 0.1.7
]);
const RELEASE_FILE = /^(?:[A-Za-z0-9][A-Za-z0-9._-]*\/)*[A-Za-z0-9][A-Za-z0-9._-]*\.(?:cjs|cs|css|html|js|json|md|mjs|ps1|vbs)$/;
const RELATIVE_IMPORT = /(?:\bfrom\s*|\bimport\s*\(\s*|\bimport\s+)["'](\.{1,2}\/[^"']+)["']/g;

// Explicit installer entry only. It retains a verified immutable candidate and
// returns a config fragment; it never edits Claude, CC Switch, model providers,
// user authorization, enrollment, or another client. Receiver configuration is
// written only when the caller explicitly enables the chosen execution route.
export async function installClaudeCodeCandidate({ candidateRoot, currentRoot = path.dirname(defaultClaudeCodeStoreRoot()), expectedManifestSha256, receiver } = {}) {
  if (receiver !== undefined && (receiver?.enabled !== true || (receiver.startAtLogon !== undefined && typeof receiver.startAtLogon !== "boolean")
    || receiver.executionMode !== 'background-cli' || !path.isAbsolute(receiver.cliPath || '')
    || !path.isAbsolute(receiver.workingDirectory || ''))) throw new Error("claude_code_install_receiver_invalid");
  if (!path.isAbsolute(candidateRoot || "") || !path.isAbsolute(currentRoot || "") || path.resolve(currentRoot) === path.parse(currentRoot).root || !/^[a-f0-9]{64}$/.test(expectedManifestSha256 || "")) throw new Error("claude_code_install_arguments_invalid");
  candidateRoot = path.resolve(candidateRoot); currentRoot = path.resolve(currentRoot);
  await assertClaudeCodePackagePlatform(candidateRoot);
  const root = path.join(currentRoot, "host");
  const binding = { adapterId: "claude-code", region: "prebind", principalId: "prebind-principal", delegateId: "prebind-delegate", hostInstallationId: "prebind-installation", profileId: "prebind-claude-code", version: 2, scopes: [], releaseRoot: candidateRoot, releaseManifestSha256: expectedManifestSha256, runtimeRoot: path.join(root, "runtime"), profileManifestPath: path.join(root, "profile-manifest-v1.json"), runnerRelativePath: "runtime/neutral-host-bootstrap.mjs" };
  await verifyClaudeCodeCandidate(binding);
  await assertRegularTree(candidateRoot);
  await verifyClaudeCodePackage(candidateRoot);
  await prepareWindowsClientRoot(currentRoot);
  const destination = await claudeCodeReleaseRoot(currentRoot, candidateRoot);
  const id = path.basename(destination);
  let exists = false;
  try { await fs.lstat(destination); exists = true; } catch (error) { if (error.code !== "ENOENT") throw error; }
  if (exists) {
    await secureWindowsClientReleaseTree(currentRoot, id, { verifyOnly: true });
    await verifyClaudeCodeCandidate({ ...binding, releaseRoot: destination });
  } else {
    const stageId = `.claude-code-stage-${crypto.randomUUID()}`;
    const stage = path.join(currentRoot, "releases", stageId);
    try {
      await fs.cp(candidateRoot, stage, { recursive: true, force: false, errorOnExist: true });
      await verifyClaudeCodeCandidate({ ...binding, releaseRoot: stage });
      await secureWindowsClientReleaseTree(currentRoot, stageId);
      await fs.rename(stage, destination);
    } finally {
      if (path.dirname(stage) !== path.join(currentRoot, "releases") || !path.basename(stage).startsWith(".claude-code-stage-")) throw new Error("claude_code_install_stage_invalid");
      await fs.rm(stage, { recursive: true, force: true });
    }
  }
  await verifyClaudeCodePackage(destination);
  let nativeService = null;
  if (receiver?.enabled === true) {
    const { configureClaudeNativeTaskWorker } = await import(pathToFileURL(path.join(destination, "integrations/claude-code/server/native-task-worker.mjs")).href);
    const { configureClaudeNativeTaskService } = await import(pathToFileURL(path.join(destination, "integrations/claude-code/server/native-task-service.mjs")).href);
    await configureClaudeNativeTaskWorker({ storeRoot: root, enabled: true, projectName: receiver.projectName,
      executionMode: receiver.executionMode, cliPath: receiver.cliPath, workingDirectory: receiver.workingDirectory });
    const service = { root: destination, storeRoot: root, expectedManifestSha256, enabled: true, startAtLogon: receiver.startAtLogon === true };
    await configureClaudeNativeTaskService(service, "Install");
    nativeService = await configureClaudeNativeTaskService(service, "Start");
  }
  return Object.freeze({ installed: true, activated: false, nativeTasksEnabled: receiver?.enabled === true, nativeService, root, releaseRoot: destination, manifestSha256: expectedManifestSha256 });
}
// Releases are named after their package manifest, the name the background updater gives them.
export async function claudeCodeReleaseRoot(currentRoot, packageRoot) {
  const bytes = await readLegacyFile(path.join(packageRoot, "hellolynk-client-pack-manifest.json"), 2 * 1024 * 1024)
    .catch(() => { throw new Error("claude_code_install_package_invalid"); });
  return path.join(currentRoot, "releases", `claude-code-${digest(bytes)}`);
}
export async function assertClaudeCodePackagePlatform(root) {
  const pkg = JSON.parse(await fs.readFile(path.join(root, "package.json"), "utf8"));
  if (pkg.os?.[0] === "darwin") {
    if (process.platform !== "darwin" || process.arch !== "arm64" || pkg.cpu?.[0] !== "arm64") {
      throw new Error("claude_code_install_macos_arm64_required");
    }
  } else if (process.platform !== "win32") {
    throw new Error("claude_code_install_windows_required");
  }
}
// The updater starts only from a release whose package files verify.
export async function verifyClaudeCodePackage(root) {
  try {
    const { version } = JSON.parse(await fs.readFile(path.join(root, "package.json"), "utf8"));
    await verifyClientUpdatePackage(root, "claude-code", version);
  } catch { throw new Error("claude_code_install_package_invalid"); }
}
export async function verifyClaudeCodeCandidate(binding) {
  await verifyPinnedNeutralHostRuntime(binding);
  await verifyClaudeCodeAssets(binding.releaseRoot);
}

// Only an already installed, exactly pinned pre-indexed release may use this path.
// Check its whole recorded closure before reading any old package asset; no old
// package code is imported or executed during compatibility verification.
export async function verifyClaudeCodePreviousRelease(binding) {
  if (!PRE_INDEXED_RELEASES.has(binding.releaseManifestSha256)) {
    return verifyClaudeCodeCandidate(binding);
  }
  await verifyPreIndexedRelease(binding);
  await verifyClaudeCodeAssets(binding.releaseRoot);
}

async function verifyClaudeCodeAssets(releaseRoot) {
  await assertRegularTree(releaseRoot);
  const manifest = JSON.parse(await fs.readFile(path.join(releaseRoot, "runtime/neutral-host-release-manifest.json"), "utf8"));
  const workbenchPath = "workbench/hellolynk-workbench-build.json";
  // Older candidates did not pin the asset manifest; keep their existing
  // primitive installation contract, while all new distributions require it.
  if (!manifest.files.some(record => record.path === `release/runtime/${workbenchPath}`)) return;
  const workbench = JSON.parse(await fs.readFile(path.join(releaseRoot, "runtime", workbenchPath), "utf8"));
  if (workbench.contract !== "hellolynk-shared-workbench-build-v1" || !Array.isArray(workbench.files)) throw new Error("claude_code_install_assets_invalid");
  for (const record of workbench.files) {
    if (!/^(?:[A-Za-z0-9][A-Za-z0-9._-]*\/)*[A-Za-z0-9][A-Za-z0-9._-]*$/.test(record.path) || !/^[a-f0-9]{64}$/.test(record.sha256)) throw new Error("claude_code_install_assets_invalid");
    const body = await fs.readFile(path.join(releaseRoot, "runtime/workbench", record.path));
    if (crypto.createHash("sha256").update(body).digest("hex") !== record.sha256) throw new Error("claude_code_install_assets_invalid");
  }
}

async function verifyPreIndexedRelease(binding) {
  const fail = () => { const error = new Error("neutral_host_runner_integrity_invalid"); error.code = error.message; throw error; };
  const pin = binding.releaseManifestSha256;
  const releaseRoot = path.resolve(String(binding.releaseRoot || ""));
  const runtimeRoot = String(binding.runtimeRoot || "");
  const hostRoot = path.dirname(runtimeRoot);
  const currentRoot = path.dirname(clientAccountBaseRoot(hostRoot));
  if (binding.adapterId !== "claude-code" || binding.runnerRelativePath !== "runtime/neutral-host-bootstrap.mjs"
    || binding.releaseRoot !== releaseRoot || !PRE_INDEXED_RELEASES.has(pin)
    || path.basename(runtimeRoot).toLowerCase() !== "runtime" || path.resolve(runtimeRoot) !== runtimeRoot
    || binding.profileManifestPath !== path.join(hostRoot, "profile-manifest-v1.json")
    || releaseRoot !== path.join(currentRoot, "releases", `claude-code-${pin}`)) fail();
  const releaseRuntime = path.join(releaseRoot, "runtime");
  const pinBytes = await readLegacyFile(path.join(releaseRuntime, "neutral-host-release-pin.json"), 16 * 1024);
  const manifestBytes = await readLegacyFile(path.join(releaseRuntime, "neutral-host-release-manifest.json"), 256 * 1024);
  let descriptor, manifest;
  try { descriptor = JSON.parse(pinBytes); manifest = JSON.parse(manifestBytes); } catch { fail(); }
  if (!exactKeys(descriptor, ["contract", "manifestSha256"])
    || descriptor.contract !== "hellolynk-neutral-host-release-pin-v1" || descriptor.manifestSha256 !== pin
    || digest(manifestBytes) !== pin || !exactKeys(manifest, ["contract", "entry", "files"])
    || manifest.contract !== "hellolynk-neutral-host-release-manifest-v1"
    || manifest.entry !== "neutral-host-release-entry.mjs"
    || !Array.isArray(manifest.files) || manifest.files.length < 3 || manifest.files.length > 256) fail();
  const files = new Map();
  const paths = new Set();
  for (const record of manifest.files) {
    if (!exactKeys(record, ["path", "sha256"]) || !RELEASE_FILE.test(record.path)
      || !/^[a-f0-9]{64}$/.test(record.sha256) || files.has(record.path)) fail();
    const external = record.path.startsWith("release/");
    const base = external ? releaseRoot : releaseRuntime;
    const relative = external ? record.path.slice("release/".length) : record.path;
    const filename = path.resolve(base, ...relative.split("/"));
    if (!inside(base, filename) || paths.has(filename.toLowerCase())) fail();
    const bytes = await readLegacyFile(filename, 2 * 1024 * 1024);
    if (digest(bytes) !== record.sha256) fail();
    files.set(record.path, { filename, bytes });
    paths.add(filename.toLowerCase());
  }
  if (!files.has(manifest.entry)
    || files.get("neutral-host-bootstrap.mjs")?.filename !== path.join(releaseRuntime, "neutral-host-bootstrap.mjs")) fail();
  for (const { filename, bytes } of files.values()) {
    if (!filename.endsWith(".mjs")) continue;
    RELATIVE_IMPORT.lastIndex = 0;
    for (const match of bytes.toString("utf8").matchAll(RELATIVE_IMPORT)) {
      const imported = path.resolve(path.dirname(filename), ...match[1].split("/"));
      if (!inside(releaseRoot, imported) || !paths.has(imported.toLowerCase())) fail();
    }
  }
}

async function readLegacyFile(filename, maximum) {
  const fail = () => { const error = new Error("neutral_host_runner_integrity_invalid"); error.code = error.message; throw error; };
  const parsed = path.parse(filename);
  let cursor = parsed.root;
  for (const part of path.relative(parsed.root, filename).split(path.sep).filter(Boolean)) {
    cursor = path.join(cursor, part);
    const stat = await fs.lstat(cursor).catch(() => fail());
    if (stat.isSymbolicLink()) fail();
  }
  const handle = await fs.open(filename, "r").catch(() => fail());
  try {
    const before = await handle.stat({ bigint: true });
    if (!before.isFile() || before.nlink !== 1n || before.size > BigInt(maximum)) fail();
    const bytes = await handle.readFile();
    const after = await handle.stat({ bigint: true });
    if (before.ino !== after.ino
      || (before.dev !== after.dev && !(process.platform === "win32" && (before.dev === 0n || after.dev === 0n)))
      || before.size !== after.size
      || before.mtimeNs !== after.mtimeNs || before.nlink !== after.nlink) fail();
    return bytes;
  } finally { await handle.close(); }
}

function digest(bytes) { return crypto.createHash("sha256").update(bytes).digest("hex"); }
function exactKeys(value, expected) { return value && typeof value === "object" && !Array.isArray(value)
  && Object.keys(value).sort().join(",") === [...expected].sort().join(","); }
function inside(root, filename) { const relative = path.relative(root, filename); return relative && relative !== ".."
  && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative); }
async function assertRegularTree(directory) {
  const metadata = await fs.lstat(directory);
  if (!metadata.isDirectory() || metadata.isSymbolicLink()) throw new Error("claude_code_install_source_invalid");
  for (const entry of await fs.readdir(directory, { withFileTypes: true })) {
    const file = path.join(directory, entry.name), stat = await fs.lstat(file);
    if (stat.isSymbolicLink() || (!stat.isDirectory() && (!stat.isFile() || stat.nlink !== 1))) throw new Error("claude_code_install_source_invalid");
    if (stat.isDirectory()) await assertRegularTree(file);
  }
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  if (process.argv.length !== 5) { process.stderr.write("Usage: candidateRoot currentRoot expectedManifestSha256\n"); process.exitCode = 1; }
  else installClaudeCodeCandidate({ candidateRoot: process.argv[2], currentRoot: process.argv[3], expectedManifestSha256: process.argv[4] }).then((result) => process.stdout.write(`${JSON.stringify(result)}\n`), (error) => { process.stderr.write(`${error.code || "claude_code_install_failed"}\n`); process.exitCode = 1; });
}
