import { execFile } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import fs from "node:fs/promises";
import { homedir } from "node:os";
import path from "node:path";
import { promisify } from "node:util";
import { checkDarwinPath } from "../../../runtime/core/hellolynk-darwin-vault.mjs";

const execute = promisify(execFile);
const failure = code => Object.assign(new Error(code), { code });
const xml = value => value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");

export function claudeDarwinTaskName(storeRoot) {
  return `org.hellolynk.claude-native-${createHash("sha256").update(storeRoot).digest("hex").slice(0, 24)}`;
}

function launchAgent(options, label) {
  const entry = path.join(options.root, "integrations/claude-code/server/package-bootstrap.mjs");
  const args = [options.nodePath, entry, "receive", "--root", options.storeRoot, "--expected-manifest-sha256", options.expectedManifestSha256];
  return `<?xml version="1.0" encoding="UTF-8"?>
<plist version="1.0"><dict>
<key>Label</key><string>${label}</string>
<key>ProgramArguments</key><array>${args.map(arg => `<string>${xml(arg)}</string>`).join("")}</array>
<key>RunAtLoad</key><true/>
</dict></plist>
`;
}

async function hasDefinition(filename, expected) {
  const stat = await fs.lstat(filename).catch(error => {
    if (error.code === "ENOENT") return null;
    throw error;
  });
  if (!stat) return false;
  checkDarwinPath(filename, { privateMode: true });
  if (stat.size !== Buffer.byteLength(expected) || await fs.readFile(filename, "utf8") !== expected) {
    throw failure("claude_native_service_task_conflict");
  }
  return true;
}

async function writeDefinition(filename, body) {
  if (await hasDefinition(filename, body)) return false;
  const temp = `${filename}.${randomUUID()}.tmp`;
  try {
    await fs.writeFile(temp, body, { flag: "wx", mode: 0o600 });
    await fs.rename(temp, filename);
  } finally {
    await fs.rm(temp, { force: true });
  }
  return true;
}

async function launchctl(args, { absentAllowed = false } = {}) {
  try {
    await execute("/bin/launchctl", args, { timeout: 15000, maxBuffer: 128 * 1024 });
    return true;
  } catch (error) {
    if (absentAllowed && /Could not find service/i.test(error.stderr || "")) return false;
    throw failure("claude_native_service_launchctl_failed");
  }
}

export async function runClaudeDarwinTask(options, command) {
  const { storeRoot } = options;
  const taskName = claudeDarwinTaskName(storeRoot);
  if (options.taskName && options.taskName !== taskName) throw failure("claude_native_service_record_mismatch");
  const domain = `gui/${process.getuid()}`, service = `${domain}/${taskName}`;
  const definition = path.join(storeRoot, "claude-native-service.plist");
  const logonFile = path.join(homedir(), "Library", "LaunchAgents", `${taskName}.plist`);
  const body = launchAgent(options, taskName);
  if (command === "Install") {
    await writeDefinition(definition, body);
  } else if (command === "Stop" || command === "Uninstall") {
    const installed = await hasDefinition(definition, body);
    if (await hasDefinition(logonFile, body)) await fs.unlink(logonFile);
    if (await launchctl(["print", service], { absentAllowed: true })) await launchctl(["bootout", service]);
    if (command === "Uninstall" && installed) await fs.unlink(definition);
  } else {
    if (!(await hasDefinition(definition, body))) throw failure("claude_native_service_task_missing");
    if (command === "Start") {
      const loaded = await launchctl(["print", service], { absentAllowed: true });
      let addedLogon = false;
      if (options.startAtLogon) {
        checkDarwinPath(path.dirname(logonFile), { directory: true, create: true });
        addedLogon = await writeDefinition(logonFile, body);
      }
      try {
        if (loaded) await launchctl(["kickstart", service]);
        else await launchctl(["bootstrap", domain, definition]);
      } catch (error) {
        if (addedLogon) await fs.unlink(logonFile);
        throw error;
      }
    }
  }
  return { ok: true, operation: command, taskName };
}
